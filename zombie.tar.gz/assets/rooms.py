"""Комнаты школы. У каждого этажа своя тема: фон, мебель (на неё можно запрыгнуть) и добыча.

Чтобы добавить новую комнату (столовая? спортзал?):
  1. напиши build_xxx()  — список мебели [(Rect, "вид"), ...]
  2. напиши back_xxx(s)  — рисует фон
  3. добавь запись в ROOMS внизу.
"""
import math

import pygame

from settings import FLOOR, H, INK, W


def box(s, rect, fill, border=3):
    """Прямоугольник с чёрной обводкой."""
    rect = pygame.Rect(rect)
    pygame.draw.rect(s, INK, rect)
    pygame.draw.rect(s, fill, rect.inflate(-border * 2, -border * 2))


def floor(s, color, line, step=32):
    pygame.draw.rect(s, color, (0, FLOOR, W, H - FLOOR))
    for tx in range(0, W, step):
        pygame.draw.rect(s, line, (tx, FLOOR + 4, 4, H - FLOOR))
    for ty in range(FLOOR + 36, H, 36):
        pygame.draw.rect(s, line, (0, ty, W, 4))
    pygame.draw.rect(s, INK, (0, FLOOR, W, 4))


def window(s, x, y=116, w=90, h=110):
    pygame.draw.rect(s, INK, (x - 4, y - 4, w + 8, h + 8))
    pygame.draw.rect(s, (150, 200, 230), (x, y, w, h))
    pygame.draw.rect(s, INK, (x + w // 2 - 3, y, 6, h))
    pygame.draw.rect(s, INK, (x, y + h // 2 - 3, w, 6))


# ---------------------------------------------------------------- КЛАСС
def build_class(variant=0):
    layouts = [
        [(pygame.Rect(120, 410, 120, 14), "desk"), (pygame.Rect(330, 410, 120, 14), "desk"),
         (pygame.Rect(560, 410, 120, 14), "desk"), (pygame.Rect(440, 320, 140, 14), "shelf")],
        [(pygame.Rect(90, 410, 120, 14), "desk"), (pygame.Rect(260, 410, 120, 14), "desk"),
         (pygame.Rect(430, 350, 150, 14), "shelf"), (pygame.Rect(640, 410, 120, 14), "desk"),
         (pygame.Rect(780, 330, 130, 14), "shelf")],
        [(pygame.Rect(60, 340, 140, 14), "shelf"), (pygame.Rect(300, 400, 260, 14), "bigdesk"),
         (pygame.Rect(700, 340, 150, 14), "shelf")],
    ]
    return layouts[variant % len(layouts)]


CLASS_WALLS = [((245, 225, 170), (225, 200, 140)), ((226, 240, 205), (200, 220, 175)),
               ((242, 216, 214), (222, 190, 190))]


def back_class(s, variant=0):
    wall, panel = CLASS_WALLS[variant % len(CLASS_WALLS)]
    s.fill(wall)
    pygame.draw.rect(s, panel, (0, 330, W, FLOOR - 330))  # нижняя панель стены
    pygame.draw.rect(s, INK, (0, 330, W, 4))
    window(s, 40)
    window(s, 770)
    box(s, (250, 100, 420, 150), (110, 75, 45))  # доска
    pygame.draw.rect(s, (45, 90, 65), (262, 112, 396, 126))
    for i, w in enumerate((200, 140, 260, 90)):  # каракули мелом
        pygame.draw.rect(s, (235, 235, 235), (282, 132 + i * 24, w, 4))
    floor(s, (150, 110, 80), (125, 90, 65))


# ---------------------------------------------------------------- ТУАЛЕТ
def build_toilet(variant=0):
    return [
        (pygame.Rect(150, 360, 120, 14), "stall"),
        (pygame.Rect(310, 360, 120, 14), "stall"),
        (pygame.Rect(470, 360, 120, 14), "stall"),
        (pygame.Rect(640, 410, 90, 14), "sink"),
        (pygame.Rect(770, 410, 90, 14), "sink"),
    ]


def back_toilet(s, variant=0):
    s.fill((205, 230, 240))
    for x in range(0, W, 40):
        pygame.draw.rect(s, (180, 210, 225), (x, 0, 2, FLOOR))
    for y in range(0, FLOOR, 40):
        pygame.draw.rect(s, (180, 210, 225), (0, y, W, 2))
    pygame.draw.rect(s, INK, (0, 38, W, 20))  # труба под потолком
    pygame.draw.rect(s, (150, 155, 165), (0, 42, W, 12))
    window(s, 60, y=90, w=70, h=70)
    for mx in (640, 770):  # зеркала над раковинами
        box(s, (mx - 6, 190, 102, 120), (225, 242, 255))
        pygame.draw.rect(s, (255, 255, 255), (mx + 8, 204, 10, 40))
    # пол: шахматные плитки
    pygame.draw.rect(s, (175, 190, 200), (0, FLOOR, W, H - FLOOR))
    for i, tx in enumerate(range(0, W, 48)):
        for j, ty in enumerate(range(FLOOR, H, 36)):
            if (i + j) % 2:
                pygame.draw.rect(s, (150, 168, 180), (tx, ty, 48, 36))
    pygame.draw.rect(s, INK, (0, FLOOR, W, 4))


# ---------------------------------------------------------------- КАБИНЕТ ДИРЕКТОРА
def build_office(variant=0):
    return [
        (pygame.Rect(60, 350, 150, 14), "bookshelf"),
        (pygame.Rect(330, 400, 260, 14), "bigdesk"),
        (pygame.Rect(720, 330, 150, 14), "bookshelf"),
    ]


def portrait(s, x, y):
    box(s, (x, y, 90, 120), (220, 175, 60))
    pygame.draw.rect(s, (200, 185, 150), (x + 8, y + 8, 74, 104))
    pygame.draw.circle(s, (250, 215, 180), (x + 45, y + 48), 18)
    pygame.draw.rect(s, (60, 60, 90), (x + 20, y + 70, 50, 42))
    pygame.draw.rect(s, (80, 80, 90), (x + 28, y + 28, 34, 8))  # причёска


def back_office(s, variant=0):
    s.fill((125, 72, 66))
    for x in range(0, W, 60):
        pygame.draw.rect(s, (108, 60, 55), (x, 0, 30, FLOOR))
    pygame.draw.rect(s, (85, 48, 44), (0, 410, W, FLOOR - 410))  # деревянная панель внизу
    pygame.draw.rect(s, INK, (0, 410, W, 4))
    portrait(s, 230, 110)
    portrait(s, 640, 110)
    window(s, 410, y=90, w=130, h=170)
    pygame.draw.rect(s, INK, (366, 80, 218, 10))  # карниз и шторы
    for cx in (378, 540):
        box(s, (cx, 84, 36, 190), (230, 190, 70))
    floor(s, (95, 40, 55), (75, 30, 42))


# ---------------------------------------------------------------- МЕБЕЛЬ
def draw_furniture(s, rect, kind):
    r = rect
    if kind == "desk":
        box(s, r, (205, 160, 100))
        for lx in (r.x + 8, r.right - 16):
            box(s, (lx, r.bottom, 8, FLOOR - r.bottom), (120, 85, 55), border=2)
    elif kind == "shelf":
        box(s, r, (170, 120, 70))
        for lx in (r.x + 10, r.right - 16):
            box(s, (lx, r.bottom, 6, 16), (120, 85, 55), border=2)
    elif kind == "bigdesk":
        box(s, r, (130, 85, 50))
        box(s, (r.x + 12, r.bottom, r.w - 24, FLOOR - r.bottom), (105, 68, 40))
        for dy in (22, 62):
            pygame.draw.rect(s, (230, 190, 70), (r.centerx - 8, r.bottom + dy, 16, 6))
    elif kind == "bookshelf":
        box(s, r, (120, 80, 45))
        box(s, (r.x + 6, r.bottom, r.w - 12, 72), (90, 55, 35))
        colors = [(200, 60, 60), (60, 120, 200), (230, 190, 60), (70, 160, 90), (170, 90, 190)]
        for i, bx in enumerate(range(r.x + 14, r.right - 20, 14)):
            pygame.draw.rect(s, INK, (bx, r.bottom + 12, 12, 52))
            pygame.draw.rect(s, colors[i % len(colors)], (bx + 2, r.bottom + 14, 8, 48))
    elif kind == "stall":
        pygame.draw.rect(s, INK, r)
        pygame.draw.rect(s, (235, 235, 245), r.inflate(-4, -4))
        box(s, (r.x + 4, r.bottom, r.w - 8, FLOOR - r.bottom - 18), (225, 215, 235))
        box(s, (r.x + 24, r.bottom + 30, r.w - 48, FLOOR - r.bottom - 48), (200, 190, 220), border=2)
        pygame.draw.rect(s, (230, 200, 60), (r.right - 36, r.bottom + 80, 8, 8))  # ручка
    elif kind == "table":
        box(s, r, (226, 206, 160))
        for lx in (r.x + 14, r.right - 22):
            box(s, (lx, r.bottom, 8, FLOOR - r.bottom), (140, 105, 70), border=2)
        pygame.draw.rect(s, INK, (r.x + 8, FLOOR - 28, r.w - 16, 9))   # скамейка под столом
        pygame.draw.rect(s, (170, 130, 90), (r.x + 10, FLOOR - 27, r.w - 20, 6))
    elif kind == "counter":
        box(s, r, (205, 208, 220))
        box(s, (r.x + 8, r.bottom, r.w - 16, FLOOR - r.bottom), (170, 175, 192))
        for i in range(3):
            pygame.draw.rect(s, INK, (r.x + 22 + i * 44, r.bottom + 20, 34, 44))
            pygame.draw.rect(s, (232, 238, 248), (r.x + 25 + i * 44, r.bottom + 23, 28, 38))
    elif kind == "bench":
        box(s, r, (190, 140, 80))
        for lx in (r.x + 10, r.right - 18):
            box(s, (lx, r.bottom, 8, FLOOR - r.bottom), (120, 85, 55), border=2)
    elif kind == "vault":
        box(s, r, (140, 80, 50))
        box(s, (r.x + 6, r.bottom, r.w - 12, FLOOR - r.bottom), (196, 150, 104), border=3)
        for y in range(r.bottom + 12, FLOOR - 6, 18):
            pygame.draw.rect(s, (150, 106, 70), (r.x + 9, y, r.w - 18, 4))
    elif kind == "beam":
        box(s, r, (220, 180, 120))
        for lx in (r.x + 16, r.right - 24):
            box(s, (lx, r.bottom, 8, FLOOR - r.bottom), (110, 110, 125), border=2)
    elif kind == "sink":
        box(s, r, (240, 245, 250))
        box(s, (r.centerx - 10, r.bottom, 20, FLOOR - r.bottom), (220, 225, 230), border=2)
        pygame.draw.rect(s, INK, (r.centerx - 5, r.top - 16, 10, 16))  # кран
        pygame.draw.rect(s, (170, 175, 185), (r.centerx - 3, r.top - 14, 6, 14))


# ---------------------------------------------------------------- СТОЛОВАЯ (бонус: еда)
def build_canteen(variant=0):
    return [
        (pygame.Rect(90, 410, 170, 14), "table"),
        (pygame.Rect(330, 410, 170, 14), "table"),
        (pygame.Rect(560, 340, 160, 14), "counter"),
        (pygame.Rect(770, 410, 120, 14), "table"),
    ]


def back_canteen(s, variant=0):
    s.fill((248, 232, 198))
    pygame.draw.rect(s, (236, 240, 242), (0, 300, W, FLOOR - 300))   # белая плитка внизу
    for x in range(0, W, 40):
        pygame.draw.rect(s, (205, 212, 218), (x, 300, 2, FLOOR - 300))
    for y in range(300, FLOOR, 40):
        pygame.draw.rect(s, (205, 212, 218), (0, y, W, 2))
    pygame.draw.rect(s, INK, (0, 300, W, 4))
    box(s, (50, 90, 240, 130), (95, 70, 45))                          # доска с меню
    pygame.draw.rect(s, (40, 70, 60), (62, 102, 216, 106))
    for i, wd in enumerate((150, 110, 170, 90)):
        pygame.draw.rect(s, (235, 235, 235), (78, 118 + i * 22, wd, 4))
    pygame.draw.circle(s, INK, (410, 120), 36)                        # часы
    pygame.draw.circle(s, (250, 250, 245), (410, 120), 31)
    pygame.draw.line(s, INK, (410, 120), (410, 96), 4)
    pygame.draw.line(s, INK, (410, 120), (428, 128), 4)
    box(s, (600, 110, 290, 150), (110, 80, 55))                       # окно раздачи: за ним кухня
    pygame.draw.rect(s, (255, 214, 130), (612, 122, 266, 126))
    for x in (700, 790):
        pygame.draw.rect(s, INK, (x, 122, 6, 126))
    for cx in (645, 745, 835):                                        # кастрюли на кухне
        pygame.draw.rect(s, INK, (cx - 26, 196, 52, 50))
        pygame.draw.rect(s, (150, 156, 168), (cx - 23, 199, 46, 44))
    floor(s, (214, 190, 150), (186, 160, 120))


# ---------------------------------------------------------------- СПОРТЗАЛ (бонус: спортивное оружие)
def build_gym(variant=0):
    return [
        (pygame.Rect(80, 420, 140, 14), "bench"),
        (pygame.Rect(320, 385, 120, 14), "vault"),
        (pygame.Rect(540, 335, 160, 14), "beam"),
        (pygame.Rect(760, 420, 120, 14), "bench"),
    ]


def back_gym(s, variant=0):
    s.fill((205, 222, 240))
    pygame.draw.rect(s, (60, 100, 165), (0, 330, W, FLOOR - 330))     # синие маты на стене
    for x in range(0, W, 80):
        pygame.draw.rect(s, (45, 80, 140), (x, 330, 4, FLOOR - 330))
    pygame.draw.rect(s, INK, (0, 330, W, 4))
    window(s, 330, y=60, w=90, h=60)
    window(s, 560, y=60, w=90, h=60)
    box(s, (20, 80, 100, 250), (196, 156, 104))                       # шведская стенка
    for y in range(96, 320, 28):
        pygame.draw.rect(s, INK, (20, y, 100, 6))
    for x in (46, 70, 94):
        pygame.draw.rect(s, (150, 112, 70), (x, 80, 5, 250))
    box(s, (700, 110, 110, 80), (245, 245, 250))                      # баскетбольный щит
    pygame.draw.rect(s, (220, 60, 60), (735, 140, 40, 30), 4)
    pygame.draw.rect(s, INK, (722, 188, 66, 10))
    pygame.draw.rect(s, (245, 120, 40), (725, 190, 60, 6))
    for x in range(730, 790, 12):                                     # сетка кольца
        pygame.draw.line(s, (240, 240, 240), (x, 196), (x + 6, 224), 2)
    pygame.draw.rect(s, INK, (276, 50, 12, 250))                      # канат
    pygame.draw.rect(s, (205, 175, 105), (279, 50, 6, 250))
    for y in (110, 170, 230):
        pygame.draw.rect(s, (160, 130, 80), (277, y, 10, 8))
    pygame.draw.rect(s, (212, 168, 104), (0, FLOOR, W, H - FLOOR))    # паркет
    for x in range(0, W, 70):
        pygame.draw.rect(s, (176, 132, 80), (x, FLOOR + 4, 3, H - FLOOR))
    for y in range(FLOOR + 36, H, 36):
        pygame.draw.rect(s, (176, 132, 80), (0, y, W, 3))
    pygame.draw.rect(s, (250, 250, 250), (0, FLOOR + 22, W, 5))       # линия площадки
    pygame.draw.rect(s, INK, (0, FLOOR, W, 4))


# ---------------------------------------------------------------- ШКОЛЬНЫЙ ДВОР (завязка)
def build_yard(variant=0):
    return []


def back_yard(s, variant=0):
    s.fill((160, 205, 235))
    pygame.draw.circle(s, (255, 240, 170), (110, 100), 42)  # солнце
    box(s, (690, 80, 290, FLOOR - 80), (206, 140, 104))      # кирпичная стена школы
    for wy in (120, 250):
        for wx in (720, 870):
            window(s, wx, y=wy, w=60, h=80)
    box(s, (790, FLOOR - 130, 90, 130), (104, 66, 46))       # школьная дверь
    pygame.draw.rect(s, (250, 220, 60), (798, FLOOR - 66, 8, 8))
    for x in range(0, 680, 34):                              # забор
        box(s, (x, FLOOR - 78, 28, 78), (200, 178, 138), border=2)
    pygame.draw.rect(s, (118, 160, 92), (0, FLOOR, W, H - FLOOR))
    pygame.draw.rect(s, (190, 178, 150), (0, FLOOR + 14, W, 40))  # асфальтовая дорожка
    pygame.draw.rect(s, INK, (0, FLOOR, W, 4))


# ---------------------------------------------------------------- ФИНАЛ: школа-рот
def build_final(variant=0):
    return [
        (pygame.Rect(100, 400, 120, 14), "desk"),
        (pygame.Rect(250, 350, 120, 14), "desk"),
        (pygame.Rect(590, 350, 120, 14), "desk"),
        (pygame.Rect(740, 400, 120, 14), "desk"),
    ]


def back_final(s, variant=0):
    """Школа стала огромным ртом: красное горло, зубы сверху и снизу, розовый язык вместо пола."""
    t = pygame.time.get_ticks() / 1000
    s.fill((72, 12, 30))
    for x in range(0, W, 80):  # «мышцы» горла
        pygame.draw.rect(s, (96, 18, 40), (x, 0, 40, FLOOR))
    open_ = 10 + int(math.sin(t * 1.6) * 8)
    for x in range(-30, W, 60):  # верхние зубы
        pts = [(x, 0), (x + 60, 0), (x + 30, 70 + open_)]
        pygame.draw.polygon(s, (242, 240, 228), pts)
        pygame.draw.polygon(s, INK, pts, 4)
    floor(s, (196, 84, 108), (166, 60, 88))
    for x in range(0, W, 60):  # нижние зубы — над языком
        pts = [(x, FLOOR), (x + 60, FLOOR), (x + 30, FLOOR - 34 - open_ // 2)]
        pygame.draw.polygon(s, (242, 240, 228), pts)
        pygame.draw.polygon(s, INK, pts, 4)


# loot — что тут чаще лежит (число = насколько часто, пирожки есть везде)
THEMES = {
    "class": {"build": build_class, "back": back_class,
              "beams": [([(40, 120), (130, 120), (400, FLOOR), (250, FLOOR)], (255, 240, 190, 44)),
                        ([(770, 120), (860, 120), (620, FLOOR), (470, FLOOR)], (255, 240, 190, 38))],
              "loot": {"pie": 22, "ruler": 8, "pointer": 8, "chair": 8, "chalk": 10, "textbook": 8,
                       "notebook": 8, "plane": 8, "slingshot": 6, "club": 5, "bell": 3}},
    "toilet": {"build": build_toilet, "back": back_toilet,
               "beams": [([(60, 90), (130, 90), (390, FLOOR), (300, FLOOR)], (215, 238, 255, 40))],
               "loot": {"pie": 26, "mop": 10, "trash": 10, "watergun": 10, "slipper": 8, "foamgun": 6,
                        "acid": 6, "extinguisher": 6, "club": 4, "chalk": 4, "plane": 3, "bell": 3}},
    "office": {"build": build_office, "back": back_office,
               "beams": [([(410, 90), (540, 90), (620, FLOOR), (340, FLOOR)], (255, 226, 160, 48))],
               "loot": {"pie": 22, "club": 8, "extinguisher": 8, "slingshot": 6, "textbook": 8, "bell": 5,
                        "piebomb": 8, "slipper": 6, "pointer": 5, "notebook": 8, "acid": 5, "foamgun": 5,
                        "chair": 6}},
    "canteen": {"build": build_canteen, "back": back_canteen,
                "beams": [([(600, 110), (890, 110), (760, FLOOR), (480, FLOOR)], (255, 232, 160, 40))],
                "loot": {"pie": 55, "piebomb": 8, "watergun": 8, "mop": 6, "club": 4, "slingshot": 4, "bell": 3}},
    "gym": {"build": build_gym, "back": back_gym,
            "beams": [([(330, 60), (420, 60), (560, FLOOR), (400, FLOOR)], (255, 245, 210, 40)),
                      ([(560, 60), (650, 60), (760, FLOOR), (600, FLOOR)], (255, 245, 210, 34))],
            "loot": {"dumbbell": 12, "jumprope": 12, "ball": 14, "pie": 20, "mop": 6, "slipper": 5, "bell": 4,
                     "textbook": 4, "foamgun": 4}},
    "yard": {"build": build_yard, "back": back_yard,
             "beams": [([(110, 100), (170, 100), (600, FLOOR), (330, FLOOR)], (255, 242, 190, 34))], "loot": {"pie": 1}},
    "final": {"build": build_final, "back": back_final,
              "loot": {"pie": 26, "club": 6, "textbook": 8, "piebomb": 10, "foamgun": 6, "acid": 6,
                       "extinguisher": 6, "slingshot": 6, "watergun": 8, "notebook": 8, "bell": 2}},
}
