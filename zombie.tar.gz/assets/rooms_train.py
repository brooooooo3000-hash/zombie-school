"""Глава 3 «Поезд»: вагоны скоростного поезда Сеул — Пусан и перрон для катсцен.

Всё как в rooms.py: build_xxx — мебель (на неё можно запрыгнуть), back_xxx — фон.
За окнами вагона убегают назад столбы и огоньки, поэтому фон рисуется заново каждый кадр.
"""
import pygame

import rooms
from pixelfont import pixel_font
from rooms import box
from settings import FLOOR, H, INK, W

TRAIN_KINDS = ("seats", "cafe", "sleeper", "luggage", "cab")
KINDS_TRAIN = ("seat", "rack", "tablet", "counter_t", "bunk", "crate_t", "console")

ROOMS_TRAIN = [
    {"id": "seats", "name": "Вагон 1", "kind": "seats"},
    {"id": "cafe", "name": "Вагон-кафе", "kind": "cafe"},
    {"id": "sleeper", "name": "Спальный вагон", "kind": "sleeper"},
    {"id": "luggage", "name": "Багажный вагон", "kind": "luggage"},
    {"id": "cab", "name": "Кабина машиниста", "kind": "cab"},
]
ROOM_TRAIN_BY_ID = {r["id"]: r for r in ROOMS_TRAIN}
ORDER_TRAIN = [r["id"] for r in ROOMS_TRAIN]

LEVER_ZONE = pygame.Rect(W - 150, FLOOR - 120, 110, 120)   # стоп-кран у двери справа


def train_window(s, x, y, w, h, day=False):
    """Окно поезда: за стеклом убегают назад столбы и огоньки."""
    t = pygame.time.get_ticks() / 1000
    pygame.draw.rect(s, INK, (x - 4, y - 4, w + 8, h + 8))
    pygame.draw.rect(s, (130, 175, 225) if day else (18, 24, 54), (x, y, w, h))
    pygame.draw.rect(s, (60, 90, 70) if day else (10, 14, 30), (x, y + h - 22, w, 22))   # холмы
    for k in range(4):   # столбы
        px = x + w - int((t * 170 + k * w / 4) % w)
        pygame.draw.rect(s, (40, 40, 50) if day else (6, 8, 20), (px, y + 8, 4, h - 28))
    if not day:
        for k in range(5):   # далёкие огоньки
            px = x + w - int((t * 55 + k * w / 5) % w)
            pygame.draw.rect(s, (255, 225, 120), (px, y + h - 40 - (k * 7) % 30, 3, 3))
    pygame.draw.rect(s, INK, (x + w // 2 - 3, y, 6, h))


def carpet(s, color, stripe):
    pygame.draw.rect(s, color, (0, FLOOR, W, H - FLOOR))
    for tx in range(0, W, 64):
        pygame.draw.rect(s, stripe, (tx, FLOOR + 6, 32, H - FLOOR - 12))
    pygame.draw.rect(s, INK, (0, FLOOR, W, 4))


def wall(s, top, panel):
    s.fill(top)
    pygame.draw.rect(s, panel, (0, 330, W, FLOOR - 330))
    pygame.draw.rect(s, INK, (0, 330, W, 4))
    pygame.draw.rect(s, (230, 230, 240), (0, 30, W, 6))   # светильник-полоса под потолком
    pygame.draw.rect(s, INK, (0, 36, W, 3))


def door_right(s):
    """Автоматическая дверь в следующий вагон (справа)."""
    box(s, (W - 70, FLOOR - 150, 70, 150), (90, 100, 120))
    pygame.draw.rect(s, (30, 34, 44), (W - 56, FLOOR - 136, 20, 120))
    pygame.draw.rect(s, (30, 34, 44), (W - 32, FLOOR - 136, 20, 120))


def lever(s):
    """Красный стоп-кран на стене у двери."""
    z = LEVER_ZONE
    box(s, (z.x + 36, z.y + 14, 38, 70), (210, 50, 50))
    pygame.draw.rect(s, (255, 235, 235), (z.x + 44, z.y + 30, 22, 8))
    pygame.draw.rect(s, (255, 235, 235), (z.x + 44, z.y + 46, 22, 8))
    t = pixel_font(16).render("СТОП", True, (255, 255, 255))
    s.blit(t, t.get_rect(center=(z.x + 55, z.y + 100)))


# ---------------------------------------------------------------- ВАГОН 1: места
def build_seats(variant=0):
    return [
        (pygame.Rect(110, 410, 110, 14), "seat"), (pygame.Rect(320, 410, 110, 14), "seat"),
        (pygame.Rect(540, 410, 110, 14), "seat"), (pygame.Rect(200, 330, 170, 12), "rack"),
        (pygame.Rect(620, 335, 160, 12), "rack"),
    ]


def back_seats(s, variant=0):
    wall(s, (176, 186, 208), (140, 152, 178))
    for x in (60, 330, 600):
        train_window(s, x, 90, 170, 120)
    door_right(s)
    lever(s)
    carpet(s, (70, 64, 110), (84, 78, 128))


# ---------------------------------------------------------------- ВАГОН-КАФЕ
def build_cafe(variant=0):
    return [
        (pygame.Rect(90, 412, 130, 14), "tablet"), (pygame.Rect(300, 412, 130, 14), "tablet"),
        (pygame.Rect(520, 340, 190, 14), "counter_t"), (pygame.Rect(760, 395, 100, 12), "tablet"),
    ]


def back_cafe(s, variant=0):
    wall(s, (222, 196, 156), (196, 164, 120))
    for x in (50, 300):
        train_window(s, x, 90, 170, 120)
    box(s, (540, 80, 220, 56), (40, 60, 52))   # меню на доске
    t = pixel_font(24).render("КАФЕ", True, (236, 236, 232))
    s.blit(t, t.get_rect(center=(650, 108)))
    door_right(s)
    lever(s)
    carpet(s, (110, 70, 54), (130, 86, 66))


# ---------------------------------------------------------------- СПАЛЬНЫЙ ВАГОН
def build_sleeper(variant=0):
    return [
        (pygame.Rect(80, 400, 150, 14), "bunk"), (pygame.Rect(80, 320, 150, 14), "bunk"),
        (pygame.Rect(400, 400, 150, 14), "bunk"), (pygame.Rect(400, 320, 150, 14), "bunk"),
        (pygame.Rect(700, 410, 110, 14), "seat"),
    ]


def back_sleeper(s, variant=0):
    wall(s, (96, 90, 120), (78, 72, 102))
    for x in (260, 600):
        train_window(s, x, 90, 110, 120)
    door_right(s)
    lever(s)
    carpet(s, (60, 44, 70), (74, 56, 86))


# ---------------------------------------------------------------- БАГАЖНЫЙ ВАГОН
def build_luggage(variant=0):
    return [
        (pygame.Rect(90, 410, 120, 14), "crate_t"), (pygame.Rect(280, 410, 120, 14), "crate_t"),
        (pygame.Rect(300, 340, 100, 14), "crate_t"), (pygame.Rect(520, 410, 120, 14), "crate_t"),
        (pygame.Rect(690, 350, 140, 14), "crate_t"),
    ]


def back_luggage(s, variant=0):
    wall(s, (100, 106, 112), (82, 88, 94))
    for x in (180, 470):
        train_window(s, x, 100, 90, 70)
    for gx in range(30, W - 100, 60):   # решётки вентиляции
        pygame.draw.rect(s, INK, (gx, 60, 40, 10))
    door_right(s)
    lever(s)
    carpet(s, (70, 74, 78), (84, 88, 92))


# ---------------------------------------------------------------- КАБИНА МАШИНИСТА
def build_cab(variant=0):
    return [
        (pygame.Rect(90, 400, 190, 14), "console"), (pygame.Rect(400, 405, 110, 14), "seat"),
        (pygame.Rect(600, 340, 140, 12), "rack"),
    ]


def back_cab(s, variant=0):
    wall(s, (60, 66, 84), (46, 52, 70))
    train_window(s, 120, 70, 700, 160)   # лобовое стекло: бесконечный чёрный тоннель и рельсы вдали
    pygame.draw.polygon(s, (30, 34, 44), [(470, 230), (440, 230), (330, 70), (610, 70)])
    for i in range(5):
        pygame.draw.rect(s, (230, 90, 70) if i % 2 else (90, 220, 120), (140 + i * 40, 250, 14, 14))
    carpet(s, (40, 42, 56), (52, 54, 70))


# ---------------------------------------------------------------- ПЕРРОН (для катсцен)
def back_station(s, variant=0):
    morning = variant == 1
    top, bot = ((110, 150, 220), (255, 190, 130)) if morning else ((18, 22, 52), (60, 44, 84))
    for y in range(0, FLOOR, 6):
        k = y / FLOOR
        pygame.draw.rect(s, tuple(int(top[i] + (bot[i] - top[i]) * k) for i in range(3)), (0, y, W, 6))
    for bx, bw, bh in ((0, 120, 220), (140, 100, 170), (270, 130, 250), (430, 90, 190), (850, 110, 230)):
        pygame.draw.rect(s, INK, (bx - 3, FLOOR - bh - 3, bw + 6, bh + 3))
        pygame.draw.rect(s, (46, 50, 74) if not morning else (130, 120, 150), (bx, FLOOR - bh, bw, bh))
        for wy in range(FLOOR - bh + 14, FLOOR - 70, 34):
            for wx in range(bx + 12, bx + bw - 18, 28):
                pygame.draw.rect(s, (255, 220, 120) if (wx + wy) % 3 else (30, 34, 56), (wx, wy, 12, 16))
    # поезд у перрона: синяя полоса с окнами
    pygame.draw.rect(s, INK, (520, FLOOR - 160, 440, 164))
    pygame.draw.rect(s, (225, 232, 245), (524, FLOOR - 156, 432, 156))
    pygame.draw.rect(s, (30, 80, 170), (524, FLOOR - 70, 432, 18))
    for wx in range(540, 940, 80):
        pygame.draw.rect(s, INK, (wx - 3, FLOOR - 136, 66, 52))
        pygame.draw.rect(s, (255, 235, 160) if not morning else (160, 200, 235), (wx, FLOOR - 133, 60, 46))
    # табло станции
    box(s, (330, 150, 260, 70), (30, 40, 70))   # ниже: сверху его закрывает рамка с репликами
    t = pixel_font(32).render("ПУСАН" if morning else "СЕУЛ", True, (255, 220, 100))
    s.blit(t, t.get_rect(center=(460, 185)))
    pygame.draw.rect(s, (96, 100, 112), (0, FLOOR, W, H - FLOOR))
    pygame.draw.rect(s, (250, 220, 60), (0, FLOOR + 14, W, 6))   # жёлтая линия безопасности
    pygame.draw.rect(s, INK, (0, FLOOR, W, 4))


def build_station(variant=0):
    return []


# ---------------------------------------------------------------- мебель
def draw_furniture_train(s, r, kind):
    if kind == "seat":
        box(s, r, (60, 96, 170))
        box(s, (r.x, r.y - 60, 24, 60), (54, 84, 150))   # спинка
        box(s, (r.x + 8, r.bottom, r.w - 16, FLOOR - r.bottom), (70, 72, 92), border=2)
    elif kind == "rack":
        box(s, r, (170, 176, 190))
        for lx in (r.x + 10, r.right - 16):
            box(s, (lx, r.bottom, 6, 14), (110, 116, 130), border=2)
        box(s, (r.x + 20, r.y - 30, 56, 30), (180, 90, 60), border=2)   # чемодан на полке
        box(s, (r.x + 90, r.y - 22, 44, 22), (70, 130, 90), border=2)
    elif kind == "tablet":
        box(s, r, (228, 214, 184))
        for lx in (r.x + 14, r.right - 22):
            box(s, (lx, r.bottom, 8, FLOOR - r.bottom), (130, 100, 70), border=2)
        pygame.draw.rect(s, INK, (r.x + 40, r.y - 18, 12, 18))   # чашка
        pygame.draw.rect(s, (255, 255, 255), (r.x + 42, r.y - 16, 8, 14))
    elif kind == "counter_t":
        box(s, r, (205, 208, 220))
        box(s, (r.x + 8, r.bottom, r.w - 16, FLOOR - r.bottom), (170, 175, 192))
        pygame.draw.rect(s, INK, (r.x + 30, r.y - 26, 46, 26))
        pygame.draw.rect(s, (230, 120, 60), (r.x + 33, r.y - 23, 40, 20))   # кофемашина
    elif kind == "bunk":
        box(s, (r.x, r.y - 18, r.w, 32), (200, 210, 235))   # матрас
        box(s, (r.x + 6, r.y - 30, 44, 16), (240, 240, 250), border=2)   # подушка
        pygame.draw.rect(s, INK, (r.x - 4, r.y - 18, 8, 120 if r.y > 360 else 0))
    elif kind == "crate_t":
        box(s, r, (150, 112, 70))
        for lx in (r.x + 10, r.right - 18):
            box(s, (lx, r.bottom, 8, FLOOR - r.bottom), (110, 82, 50), border=2)
        pygame.draw.line(s, INK, (r.x + 4, r.y + 4), (r.right - 4, r.bottom - 4), 3)
    elif kind == "console":
        box(s, r, (40, 46, 62))
        for i in range(6):
            pygame.draw.rect(s, (90, 220, 120) if i % 2 else (230, 90, 70), (r.x + 14 + i * 28, r.y - 10, 14, 10))
        box(s, (r.x + 10, r.bottom, r.w - 20, FLOOR - r.bottom), (32, 36, 50), border=2)


THEMES_TRAIN = {
    "seats": {"build": build_seats, "back": back_seats, "beams": [],
              "loot": {"pie": 22, "textbook": 8, "chair": 8, "slipper": 6, "notebook": 6}, "tint": 0},
    "cafe": {"build": build_cafe, "back": back_cafe, "beams": [],
             "loot": {"pie": 40, "piebomb": 10, "trash": 8, "extinguisher": 6, "watergun": 8}, "tint": 0},
    "sleeper": {"build": build_sleeper, "back": back_sleeper, "beams": [],
                "loot": {"pie": 16, "notebook": 8, "mop": 8, "slingshot": 6, "slipper": 6}, "tint": 0},
    "luggage": {"build": build_luggage, "back": back_luggage, "beams": [],
                "loot": {"pie": 14, "club": 8, "chair": 6, "cart": 8, "dumbbell": 6}, "tint": 0},
    "cab": {"build": build_cab, "back": back_cab, "beams": [],
            "loot": {"pie": 14, "extinguisher": 8, "foamgun": 6}, "tint": 0},
    "station": {"build": build_station, "back": back_station, "beams": [], "loot": {"pie": 1}, "tint": 0},
}
rooms.THEMES.update(THEMES_TRAIN)
