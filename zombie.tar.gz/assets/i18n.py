"""Языки игры: русский (основной), English и 한국어.

Как это работает: игра написана по-русски, а когда какой-то русский текст рисуется на экране,
pixelfont.py спрашивает у tr() «а как это сказать на выбранном языке?». Ответы лежат в translations.py.
Если перевода нет, рисуется русский текст, и в MISSING запоминается, что его забыли (смотри tests/test_lang.py).

Язык выбирается в меню (кнопка слева вверху и «Настройки → Язык») и запоминается.
"""
import re

from translations import TEXT

LANGS = [("ru", "Русский"), ("en", "English"), ("ko", "한국어")]
LANG = "ru"
MISSING = set()   # русские тексты, у которых нет перевода на выбранный язык

_CYR = re.compile(r"[А-Яа-яЁё]")
_SLOT = re.compile(r"\{\d+\}")
_templates = []


def _build():
    """Шаблоны: тексты с {0}, {1}... превращаем в регулярные выражения, самые точные сначала."""
    items = []
    for key in TEXT:
        if _SLOT.search(key):
            parts = _SLOT.split(key)
            regex = re.compile("^" + "(.+?)".join(re.escape(p) for p in parts) + "$", re.S)
            items.append((sum(len(p) for p in parts), regex, key))
    items.sort(key=lambda it: -it[0])
    _templates[:] = [(rx, key) for _, rx, key in items]


_build()


def set_lang(code):
    global LANG
    LANG = code if code in dict(LANGS) else "ru"


def next_lang(code=None):
    """Следующий язык по кругу."""
    codes = [c for c, _ in LANGS]
    cur = codes.index(code or LANG) if (code or LANG) in codes else 0
    return codes[(cur + 1) % len(codes)]


def tr(text):
    """Перевод русского текста на выбранный язык. Для русского и неизвестных текстов возвращает текст как есть."""
    if LANG == "ru" or not text:
        return text
    col = 0 if LANG == "en" else 1
    entry = TEXT.get(text)
    if entry is not None:
        return entry[col]
    for rx, key in _templates:
        m = rx.match(text)
        if m:
            return TEXT[key][col].format(*[tr(g) for g in m.groups()])
    if _CYR.search(text):
        MISSING.add(text)
    return text
