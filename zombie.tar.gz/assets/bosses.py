"""Своя механика у каждого босса (раньше у всех было одно и то же: ходит, кидает, таранит).

  boss    — директор: классика (двойки, таран, «ты против школы»), его правила в game.py
  queen   — королева червей: плюёт кислотой дугой (остаются лужи), ЗАРЫВАЕТСЯ и вылезает прямо под героем
  driver  — зомби-машинист: пускает пар из люков в полу и разгоняется «экспрессом» через весь вагон (с гудком)
  mascot  — зомби-талисман: прыгает и бьёт по полу волнами, сбрасывает на героя воздушные шарики

Каждый босс — маленькая цепочка состояний (b.state), как у директора. Опасные места на полу
(лужи, пар, шарики) живут в game.bhaz и предупреждают о себе: сначала метка, потом удар.
Хочешь босса со своими приёмами? Добавь его вид в AI, функцию состояний и рисование в draw_hazards.
"""
import math
import random
import sys

import pygame

from settings import FLOOR, INK, W

HIDDEN = ("burrow", "warn")        # королева под землёй: бить нельзя
VENT_WARN, VENT_LIFE = 1.0, 0.8    # метка пара и сколько он бьёт
BALLOON_WARN = 0.9                 # метка шарика
PUDDLE_LIFE = 3.5


def player_cx(g):
    p = g.player
    return p.x + p.w / 2


def add_hazard(g, kind, x, **kw):
    g.bhaz.append(dict(kind=kind, x=float(x), t=0.0, **kw))


# ---------------------------------------------------------------- королева червей
def lob_acid(g, b, target_x):
    """Кислотный плевок дугой: падает на пол и оставляет лужу."""
    x0, y0, T, grav = b.x + b.w / 2 + b.face * 40, b.y + 20, 0.9, 1100.0
    vy0 = ((FLOOR - 8 - y0) - 0.5 * grav * T * T) / T
    g.projectiles.append({"x": x0, "y": y0, "vx": (target_x - x0) / T, "vy": vy0, "grav": grav, "t": 0.0, "lob": True})


def queen(g, b, dt, to_p, slow):
    d, pc = b.data, player_cx(g)
    if b.state == "walk":
        b.face = to_p
        b.x += to_p * b.speed * slow * dt
        b.anim += b.speed * slow * dt
        b.throw_cd -= dt
        d["walk"] = d.get("walk", 0.0) + dt
        if b.throw_cd <= 0 and not g.decoy:
            b.set_state("throw")
        elif d["walk"] >= (3.0 if b.phase2 else 4.5):   # пора под землю
            d["walk"] = 0.0
            b.set_state("dive")
            g.msg = ["Королева ныряет под землю!", 2.0]
    elif b.state == "throw":     # плюёт дугой: замах, потом плевок в то место, где ты стоишь
        b.face = to_p
        if b.t >= 0.5:
            lob_acid(g, b, pc)
            if b.phase2:
                lob_acid(g, b, pc + random.choice((-140, 140)))
            b.throw_cd = 2.2 if b.phase2 else 3.0
            b.set_state("walk")
    elif b.state == "dive":      # уходит в землю
        if b.t >= 0.5:
            g.puff(b.x + b.w / 2, FLOOR - 6, 12, (120, 85, 55))
            b.set_state("burrow")
    elif b.state == "burrow":    # под землёй едет к герою (виден только бугор)
        want = pc - b.w / 2
        b.x += max(-1.0, min(1.0, (want - b.x) / 25)) * 340 * dt
        if int(b.t * 14) % 2 == 0:
            g.puff(b.x + b.w / 2, FLOOR - 4, 1, (120, 85, 55))
        if b.t >= (1.2 if b.phase2 else 1.6):
            b.set_state("warn")
    elif b.state == "warn":      # замерла: земля трясётся, пора отходить!
        if b.t >= 0.7:
            erupt(g, b, pc)
    elif b.state == "tired":     # вылезла и выдохлась: самое время бить
        if b.t >= (1.5 if b.phase2 else 2.0):
            b.throw_cd = 1.0
            b.set_state("walk")
    else:
        b.set_state("walk")


def erupt(g, b, pc):
    """Королева вылезает из-под земли: если ты стоял над ней, тебя подбрасывает."""
    p = g.player
    bc = b.x + b.w / 2
    if abs(pc - bc) < 85 and p.y + p.h > FLOOR - 70:
        g.hurt_player(2, bc)
        p.vy = -650
        p.on_ground = False
    g.add_shake(7, 0.4)
    g.puff(bc, FLOOR - 6, 18, (120, 85, 55))
    Zombie = sys.modules[type(g).__module__].Zombie   # класс врага из того же game.py, что и g
    alive = sum(1 for z in g.zombies if z.kind == "worm")
    for k in range(min(2 if b.phase2 else 1, max(0, 4 - alive))):   # червяков не больше четырёх одновременно
        g.zombies.append(Zombie(max(20, min(g.ww - 80, bc + (-1) ** k * (80 + 30 * k))), "worm"))
    b.set_state("tired")


# ---------------------------------------------------------------- зомби-машинист
def start_vents(g, b):
    pc = player_cx(g)
    for off in (-170, 0, 170):
        x = max(60, min(g.ww - 60, pc + off + random.randint(-30, 30)))
        add_hazard(g, "vent", x, warn=VENT_WARN, life=VENT_LIFE)
    g.msg = ["Пар из люков! Не стой на месте", 2.0]


def driver(g, b, dt, to_p, slow):
    d = b.data
    if b.state == "walk":
        b.face = to_p
        b.x += to_p * b.speed * slow * dt
        b.anim += b.speed * slow * dt
        d["att"] = d.get("att", 0.0) + dt
        if d["att"] >= (2.0 if b.phase2 else 2.8) and not g.decoy:
            d["att"] = 0.0
            d["n"] = d.get("n", 0) + 1
            if d["n"] % 2:    # то пар, то экспресс
                start_vents(g, b)
                b.set_state("throw")
            else:
                b.face = to_p
                b.set_state("windup")
                g.msg = ["Гудок! Уйди с рельсов!", 2.0]
    elif b.state == "throw":     # дёргает рычаг, люки открываются
        if b.t >= 2.1:
            b.set_state("walk")
    elif b.state == "windup":    # гудит и разгоняется: у героя секунда, чтобы встать повыше
        if b.t >= (0.8 if b.phase2 else 1.1):
            b.dir = b.face
            b.set_state("charge")
    elif b.state == "charge":    # экспресс несётся до самой стенки (быстрее обычного тарана)
        b.x += b.dir * 800 * dt
        if b.t >= 1.8 or b.x <= 0 or b.x + b.w >= g.ww:
            b.set_state("tired")
    elif b.state == "tired":
        if b.t >= (0.9 if b.phase2 else 1.3):
            b.set_state("walk")
    else:
        b.set_state("walk")
    if b.phase2 and g.train is not None and g.train.cfg.get("tunnel") and g.train.dark_left <= 0:
        d["dark"] = d.get("dark", 0.0) + dt   # во второй половине боя в кабине гаснет свет
        if d["dark"] >= 9.0:
            d["dark"] = 0.0
            g.train.dark_left = 3.0
            g.msg = ["Свет погас!", 1.5]


# ---------------------------------------------------------------- зомби-талисман
def start_balloons(g, b):
    pc = player_cx(g)
    for i, off in enumerate((-140, 0, 140)):
        x = max(40, min(g.ww - 40, pc + off))
        add_hazard(g, "balloon", x, warn=BALLOON_WARN + i * 0.3, color=i)
    g.msg = ["Шарики! Смотри на метки на полу", 2.0]


def mascot(g, b, dt, to_p, slow):
    d, pc = b.data, player_cx(g)
    if b.state == "walk":
        b.face = to_p
        b.x += to_p * b.speed * slow * dt
        b.anim += b.speed * slow * dt
        d["att"] = d.get("att", 0.0) + dt
        if d["att"] >= (1.6 if b.phase2 else 2.2) and not g.decoy:
            d["att"] = 0.0
            d["n"] = d.get("n", 0) + 1
            if d["n"] % 2:
                start_balloons(g, b)
                b.set_state("throw")
            else:
                b.face = to_p
                b.set_state("windup")
    elif b.state == "throw":     # поднял руку с шариками
        if b.t >= 1.6:
            b.set_state("walk")
    elif b.state == "windup":    # присел перед прыжком
        if b.t >= 0.6:
            d["x0"], d["x1"] = b.x, max(0.0, min(g.ww - b.w, pc - b.w / 2))
            b.set_state("jump")
            g.msg = ["Талисман прыгает!", 1.2]
    elif b.state == "jump":      # летит по дуге к тому месту, где ты стоял
        u = min(1.0, b.t / 0.8)
        b.x = d["x0"] + (d["x1"] - d["x0"]) * u
        b.y = FLOOR - b.h - math.sin(u * math.pi) * 210
        if u >= 1.0:
            slam(g, b)
    elif b.state == "tired":
        if b.t >= (0.8 if b.phase2 else 1.2):
            b.set_state("walk")
    else:
        b.set_state("walk")


def slam(g, b):
    """Приземлился: по полу в обе стороны бегут волны (их надо перепрыгнуть)."""
    b.y = float(FLOOR - b.h)
    bc = b.x + b.w / 2
    for sign in (-1, 1):
        g.projectiles.append({"x": bc + sign * 50, "y": FLOOR - 18.0, "vx": sign * 330.0, "t": 0.0, "kind": "wave"})
    if b.rect.colliderect(g.player.rect):
        g.hurt_player(2, bc)
    g.add_shake(8, 0.45)
    g.puff(bc, FLOOR - 6, 18, (230, 180, 220))
    b.set_state("tired")


AI = {"queen": queen, "driver": driver, "mascot": mascot}


def update(g, b, dt, to_p, slow):
    """Один кадр приёмов босса. Возвращает True, если у босса своя механика (game.py тогда не берёт общую)."""
    fn = AI.get(b.kind)
    if fn is None:
        return False
    fn(g, b, dt, to_p, slow)
    return True


# ---------------------------------------------------------------- опасные места на полу
def update_hazards(g, dt):
    p = g.player
    for h in g.bhaz:
        h["t"] += dt
        kind, x = h["kind"], h["x"]
        if kind == "puddle":
            if h["t"] > PUDDLE_LIFE:
                h["dead"] = True
            elif p.hurt_cd == 0 and p.shield_t <= 0 and abs(player_cx(g) - x) < 46 and p.y + p.h > FLOOR - 14:
                g.hurt_player(1, x)
        elif kind == "vent":
            if h["t"] > h["warn"] + h["life"]:
                h["dead"] = True
            elif h["t"] > h["warn"] and abs(player_cx(g) - x) < 34 + p.w / 2:
                g.hurt_player(1, x)
        elif kind == "balloon":
            drop = h["warn"] + 0.25
            if h["t"] >= drop:
                if abs(player_cx(g) - x) < 46 and p.y + p.h > FLOOR - 120:
                    g.hurt_player(1, x)
                g.particles.emit(x, FLOOR - 40, 14, [(230, 60, 70), (245, 215, 70), (90, 160, 235), (110, 210, 150)],
                                 speed=(60, 260), life=(0.3, 0.7), size=(3, 6), grav=300)
                h["dead"] = True
    g.bhaz = [h for h in g.bhaz if not h.get("dead")]


def draw_hazards(g, s):
    tick = pygame.time.get_ticks()
    for h in g.bhaz:
        x, t = int(h["x"]), h["t"]
        if h["kind"] == "puddle":
            fade = 1.0 if t < PUDDLE_LIFE - 0.8 else (PUDDLE_LIFE - t) / 0.8
            w = int(86 * min(1.0, t / 0.2))
            pygame.draw.ellipse(s, INK, (x - w // 2 - 3, FLOOR - 14, w + 6, 20))
            pygame.draw.ellipse(s, (120, 230, 70) if fade > 0.5 or (tick // 120) % 2 else (70, 150, 40),
                                (x - w // 2, FLOOR - 12, w, 16))
            pygame.draw.circle(s, (200, 255, 150), (x - w // 5, FLOOR - 6), 3)
        elif h["kind"] == "vent":
            if t < h["warn"]:   # метка: решётка светится и клубится пар
                k = t / h["warn"]
                pygame.draw.rect(s, INK, (x - 34, FLOOR - 8, 68, 12))
                pygame.draw.rect(s, (255, int(220 - 150 * k), 70), (x - 30, FLOOR - 6, 60, 8))
                for i in range(3):
                    pygame.draw.circle(s, (235, 240, 250), (x - 14 + i * 14, FLOOR - 20 - int(k * 22) - i * 4), 4 + i)
            else:               # столб пара
                pygame.draw.rect(s, INK, (x - 38, FLOOR - 236, 76, 236))
                pygame.draw.rect(s, (240, 244, 252), (x - 32, FLOOR - 232, 64, 232))
                pygame.draw.rect(s, (255, 255, 255), (x - 12, FLOOR - 232, 12, 232))
        elif h["kind"] == "balloon":
            col = ((230, 60, 70), (245, 215, 70), (90, 160, 235))[h["color"] % 3]
            if t < h["warn"]:   # тень растёт на полу
                k = t / h["warn"]
                r = int(14 + 30 * k)
                pygame.draw.ellipse(s, INK, (x - r, FLOOR - 8, r * 2, 14))
                pygame.draw.ellipse(s, col, (x - r + 3, FLOOR - 6, r * 2 - 6, 10))
                by = 60 + int(math.sin(tick / 160 + x) * 6)   # шарик качается над головой
                pygame.draw.line(s, INK, (x, by + 16), (x, by + 40), 2)
                pygame.draw.circle(s, INK, (x, by), 17)
                pygame.draw.circle(s, col, (x, by), 14)
                pygame.draw.circle(s, (255, 255, 255), (x - 5, by - 6), 4)
            else:               # падает
                k = min(1.0, (t - h["warn"]) / 0.25)
                by = 60 + int((FLOOR - 70) * k)
                pygame.draw.circle(s, INK, (x, by), 17)
                pygame.draw.circle(s, col, (x, by), 14)
                pygame.draw.circle(s, (255, 255, 255), (x - 5, by - 6), 4)


def draw_burrow(g, s, b):
    """Королева под землёй: виден только бугор (перед вылетом трясётся и над ним «!»)."""
    cx = b.rect.centerx
    shake = random.choice((-3, 3)) if b.state == "warn" else 0
    pygame.draw.ellipse(s, INK, (cx - 52 + shake, FLOOR - 28, 104, 34))
    pygame.draw.ellipse(s, (130, 92, 58), (cx - 48 + shake, FLOOR - 26, 96, 28))
    pygame.draw.ellipse(s, (160, 118, 78), (cx - 30 + shake, FLOOR - 26, 50, 12))
    if b.state == "warn":
        pygame.draw.rect(s, INK, (cx - 8, FLOOR - 190, 16, 54))
        pygame.draw.rect(s, (255, 90, 80), (cx - 5, FLOOR - 187, 10, 34))
        pygame.draw.rect(s, INK, (cx - 8, FLOOR - 128, 16, 16))
        pygame.draw.rect(s, (255, 90, 80), (cx - 5, FLOOR - 125, 10, 10))
