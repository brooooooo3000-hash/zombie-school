"""Картинки главы 2 «Мегамаркет»: мутанты, мясные зомби, мимик, королева червей, пони и тележка.

Рисуются кодом на маленькой картинке и увеличиваются в 4 раза (получаются пиксели, как у остальной игры).
Каждый враг — словарь кадров: {"a": ..., "b": ..., "a_flash": ..., "b_flash": ...} (a и b — шаги, flash — белая вспышка при ударе).
Все враги смотрят вправо (как зомби), игра сама разворачивает их влево.
"""
import pygame

INK = (30, 30, 40)
SCALE = 4


def _finish(small, flash=False):
    """Добавляем чёрный контур, при flash закрашиваем всё белым, увеличиваем."""
    mask = pygame.mask.from_surface(small)
    sil = mask.to_surface(setcolor=INK, unsetcolor=(0, 0, 0, 0))
    out = pygame.Surface((small.get_width() + 2, small.get_height() + 2), pygame.SRCALPHA)
    for dx, dy in ((0, 1), (2, 1), (1, 0), (1, 2)):
        out.blit(sil, (dx, dy))
    body = mask.to_surface(setcolor=(255, 255, 255, 255), unsetcolor=(0, 0, 0, 0)) if flash else small
    out.blit(body, (1, 1))
    return pygame.transform.scale(out, (out.get_width() * SCALE, out.get_height() * SCALE))


def _pair(draw, w, h):
    """Два шага ходьбы и их вспышки."""
    frames = {}
    for name, step in (("a", 0), ("b", 1)):
        small = pygame.Surface((w, h), pygame.SRCALPHA)
        draw(small, step)
        frames[name] = _finish(small)
        frames[name + "_flash"] = _finish(small, flash=True)
    return frames


def _dot(s, color, x, y, w=1, h=1):
    pygame.draw.rect(s, color, (x, y, w, h))


# ---------------------------------------------------------------- червяк-мутант
def draw_worm(s, step):
    body, dark, belly = (140, 215, 90), (90, 165, 60), (235, 150, 165)
    h = s.get_height()
    ys = (h - 5, h - 4, h - 5, h - 4) if step == 0 else (h - 4, h - 5, h - 4, h - 5)
    for i, x in enumerate((3, 6, 9, 12)):  # бугорки тела
        pygame.draw.circle(s, body if i % 2 == 0 else dark, (x, ys[i]), 3)
        _dot(s, belly, x - 1, ys[i] + 2, 3, 1)
    pygame.draw.circle(s, body, (16, h - 6), 4)          # голова
    _dot(s, (255, 255, 255), 16, h - 9, 2, 2)           # глаз
    _dot(s, (200, 40, 50), 17, h - 9, 1, 1)
    _dot(s, (120, 30, 50), 18, h - 5, 3, 2)             # пасть
    _dot(s, (255, 255, 255), 19, h - 5, 1, 1)


# ---------------------------------------------------------------- курица-зомби
def draw_chicken(s, step):
    white, grey, red, yellow = (225, 235, 215), (150, 190, 140), (210, 50, 60), (240, 200, 60)
    pygame.draw.ellipse(s, white, (1, 3, 9, 6))         # тело
    pygame.draw.ellipse(s, grey, (2, 4, 5, 3))          # крыло
    pygame.draw.rect(s, white, (8, 1, 3, 5))            # шея
    pygame.draw.circle(s, white, (10, 2), 2)            # голова
    _dot(s, red, 9, -1 + 1, 2, 1)                       # гребень
    _dot(s, yellow, 12, 2, 2, 1)                        # клюв
    _dot(s, (230, 60, 60), 10, 2, 1, 1)                 # глаз
    leg = (4, 6) if step == 0 else (6, 4)
    _dot(s, yellow, leg[0], 9, 1, 2)
    _dot(s, yellow, leg[1], 9, 1, 2)
    _dot(s, white, 0, 4, 2, 2)                          # хвост


# ---------------------------------------------------------------- корова-зомби
def draw_cow(s, step):
    skin, patch, dark = (225, 235, 225), (110, 150, 105), (70, 90, 70)
    pygame.draw.rect(s, skin, (2, 3, 12, 6))            # тело
    _dot(s, patch, 4, 4, 3, 3)
    _dot(s, patch, 9, 3, 3, 2)
    pygame.draw.rect(s, skin, (13, 2, 4, 5))            # голова
    _dot(s, (200, 180, 120), 14, 1, 1, 2)               # рога
    _dot(s, (200, 180, 120), 16, 1, 1, 2)
    _dot(s, (235, 150, 165), 16, 5, 2, 2)               # морда
    _dot(s, (230, 60, 60), 15, 3, 1, 1)                 # глаз
    _dot(s, dark, 1, 4, 1, 3)                           # хвост
    legs = (3, 6, 10, 12) if step == 0 else (4, 7, 9, 12)
    for x in legs:
        _dot(s, dark if x in (6, 7, 12) else skin, x, 9, 2, 3)


# ---------------------------------------------------------------- барашек-зомби
def draw_lamb(s, step):
    wool, grey, face = (235, 235, 230), (170, 190, 170), (60, 80, 60)
    for cx, cy in ((3, 5), (6, 4), (9, 5), (5, 7), (8, 7)):
        pygame.draw.circle(s, wool, (cx, cy), 3)
    _dot(s, grey, 5, 6, 3, 2)
    pygame.draw.rect(s, face, (10, 3, 4, 5))            # морда
    _dot(s, (230, 60, 60), 12, 4, 1, 1)                 # глаз
    _dot(s, face, 9, 2, 2, 2)                           # ухо
    legs = (3, 9) if step == 0 else (4, 8)
    for x in legs:
        _dot(s, face, x, 9, 1, 2)
        _dot(s, face, x + 2, 9, 1, 2)


# ---------------------------------------------------------------- мимик: пирожок с зубами
def draw_mimic(s, step):
    crust, fill = (225, 160, 70), (255, 225, 160)
    pygame.draw.ellipse(s, crust, (0, 2, 12, 9))
    pygame.draw.ellipse(s, fill, (2, 4, 8, 4))
    _dot(s, (255, 255, 255), 3, 3 + step, 2, 2)         # глаза
    _dot(s, (255, 255, 255), 7, 3 + step, 2, 2)
    _dot(s, (200, 40, 50), 4, 3 + step, 1, 1)
    _dot(s, (200, 40, 50), 8, 3 + step, 1, 1)
    pygame.draw.rect(s, (120, 30, 50), (2, 7 - step, 8, 2 + step))   # пасть
    for x in (3, 5, 7, 9):
        _dot(s, (255, 255, 255), x, 7 - step, 1, 1)
    _dot(s, crust, 2, 11, 2, 1 + step)                  # ножки
    _dot(s, crust, 8, 11, 2, 1 + (1 - step))


# ---------------------------------------------------------------- королева червей (босс)
def draw_queen_frame(s, name, step):
    body, dark, belly = (140, 215, 90), (90, 165, 60), (235, 150, 165)
    gold = (245, 205, 70)
    h = s.get_height()
    lean = 2 if name == "charge" else 0
    bob = step if name.startswith("walk") else 0
    for i, (x, r) in enumerate(((5, 5), (11, 6), (17, 6))):   # три толстых сегмента
        y = h - r - 1 - (bob if i % 2 == 0 else 0)
        pygame.draw.circle(s, body if i % 2 == 0 else dark, (x, y), r)
        pygame.draw.rect(s, belly, (x - 3, y + r - 3, 6, 2))
    hx, hy = 22 + lean, h - 13 - bob
    pygame.draw.circle(s, body, (hx, hy), 7)
    pygame.draw.polygon(s, gold, [(hx - 6, hy - 6), (hx - 4, hy - 11), (hx - 2, hy - 7), (hx, hy - 12),
                                  (hx + 2, hy - 7), (hx + 4, hy - 11), (hx + 6, hy - 6)])   # корона
    _dot(s, (255, 255, 255), hx - 1, hy - 3, 3, 3)
    _dot(s, (210, 40, 60), hx, hy - 2, 1, 2)
    _dot(s, (255, 255, 255), hx - 5, hy - 2, 2, 2)
    _dot(s, (210, 40, 60), hx - 5, hy - 2, 1, 1)
    open_mouth = 4 if name in ("throw", "charge") else 2
    pygame.draw.rect(s, (120, 30, 50), (hx - 1, hy + 2, 8, open_mouth))                 # пасть
    for x in range(hx - 1, hx + 7, 2):
        _dot(s, (255, 255, 255), x, hy + 2, 1, 1)
    if name == "throw":
        pygame.draw.circle(s, (120, 230, 70), (hx + 9, hy + 3), 2)                       # плюёт кислотой


def make_queen():
    frames = {}
    specs = [("walk0", 0), ("walk1", 1), ("walk2", 0), ("walk3", 1), ("throw", 0), ("charge", 0)]
    for name, step in specs:
        small = pygame.Surface((32, 22), pygame.SRCALPHA)
        draw_queen_frame(small, name, step)
        frames[name] = _finish(small)
        frames[name + "_flash"] = _finish(small, flash=True)
    return frames


# ---------------------------------------------------------------- игрушка пони (отвлекает всех)
def draw_pony(s, step):
    pink, mane = (250, 150, 200), [(230, 60, 70), (250, 160, 50), (245, 225, 70), (90, 200, 100), (80, 140, 230)]
    pygame.draw.rect(s, pink, (2, 3, 8, 4))                 # тело
    pygame.draw.rect(s, pink, (9, 1, 3, 4))                 # шея
    pygame.draw.rect(s, pink, (11, 0, 3, 3))                # голова
    _dot(s, (30, 30, 40), 12, 1, 1, 1)                      # глаз
    for i, c in enumerate(mane):                            # радужная грива
        _dot(s, c, 8, i, 1, 1)
    for i, c in enumerate(mane[:3]):                        # хвост
        _dot(s, c, 1, 3 + i, 1, 1)
        _dot(s, c, 0, 4 + i, 1, 1)
    legs = (3, 5, 8, 10) if step == 0 else (2, 6, 7, 9)
    for x in legs:
        _dot(s, (230, 120, 175), x, 7, 1, 2)


def make_pony():
    frames = {}
    for name, step in (("a", 0), ("b", 1)):
        small = pygame.Surface((15, 10), pygame.SRCALPHA)
        draw_pony(small, step)
        frames[name] = _finish(small)
    return frames


def make_cart_icon():
    small = pygame.Surface((13, 10), pygame.SRCALPHA)
    metal, dark = (190, 195, 205), (110, 115, 130)
    pygame.draw.polygon(small, metal, [(1, 1), (12, 1), (10, 6), (3, 6)])
    for x in (3, 5, 7, 9):
        _dot(small, dark, x, 2, 1, 4)
    _dot(small, dark, 0, 0, 1, 1)
    pygame.draw.line(small, dark, (0, 0), (2, 0))
    pygame.draw.circle(small, INK, (4, 8), 1)
    pygame.draw.circle(small, INK, (9, 8), 1)
    return _finish(small)


def make_apple():
    small = pygame.Surface((7, 7), pygame.SRCALPHA)
    pygame.draw.circle(small, (215, 50, 55), (3, 4), 3)
    _dot(small, (255, 140, 140), 2, 3, 1, 1)
    _dot(small, (60, 140, 60), 4, 0, 2, 1)
    _dot(small, (110, 70, 40), 3, 0, 1, 2)
    return _finish(small)


def make_wallet():
    small = pygame.Surface((9, 7), pygame.SRCALPHA)
    pygame.draw.rect(small, (150, 95, 55), (0, 1, 9, 6))
    pygame.draw.rect(small, (110, 65, 35), (0, 1, 9, 2))
    pygame.draw.circle(small, (245, 205, 70), (6, 4), 2)
    return _finish(small)


# ---------------------------------------------------------------- всё сразу
ENEMY_DRAW = {"worm": (draw_worm, 22, 10), "chicken": (draw_chicken, 15, 12), "cow": (draw_cow, 19, 13),
              "lamb": (draw_lamb, 15, 12), "mimic": (draw_mimic, 13, 13)}


def make_all():
    """Все картинки главы 2 одним словарём (SpriteSet кладёт его в sp.market)."""
    out = {kind: _pair(fn, w, h) for kind, (fn, w, h) in ENEMY_DRAW.items()}
    out["queen"] = make_queen()
    out["pony"] = make_pony()
    out["cart"] = make_cart_icon()
    out["apple"] = make_apple()
    out["wallet"] = make_wallet()
    return out
