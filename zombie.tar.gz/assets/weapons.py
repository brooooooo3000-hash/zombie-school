"""Всё оружие игры — это просто таблица. Хочешь новое оружие — добавь строку.

type:
  melee  — бьёт вплотную (reach — дальность в пикселях)
  shot   — стреляет по прямой (speed — скорость, range — как далеко летит)
  throw  — кидает по дуге (speed вперёд, vy вверх (минус), grav — тяжесть)
  shield — поднимает щит: пока он поднят, урона нет
  bell   — оглушает всех зомби на экране
  decoy  — игрушка скачет по комнате и отвлекает всех врагов (dur — сколько секунд)

Общие поля:
  dmg   — урон (у зомби 3 здоровья, у босса 40)
  cd    — пауза между действиями, секунд
  uses  — сколько раз можно использовать (None — без ограничений)
Особые эффекты:
  kb — отбрасывание в пикселях, slow — замедление (сек), stun — оглушение (сек),
  dot — горит/плавится столько секунд (1 урон каждые 0.5 сек), area — радиус взрыва
"""


def _w(key, name, kind, **kw):
    data = {"key": key, "name": name, "type": kind, "dmg": 1, "cd": 0.4, "uses": None}
    data.update(kw)
    return data


FISTS = _w("fists", "Кулаки", "melee", dmg=1, reach=45, cd=0.35)

# --- бить ---
CLUB = _w("club", "Дубина", "melee", dmg=2, reach=80, cd=0.5)
RULER = _w("ruler", "Линейка", "melee", dmg=1, reach=70, cd=0.2)            # быстрая
MOP = _w("mop", "Швабра", "melee", dmg=2, reach=100, cd=0.65)               # длинная
EXTINGUISHER = _w("extinguisher", "Огнетушитель", "melee", dmg=3, reach=90, cd=0.9, slow=3.0)
POINTER = _w("pointer", "Указка", "melee", dmg=1, reach=125, cd=0.4)        # самая длинная
CHAIR = _w("chair", "Стул", "melee", dmg=2, reach=75, cd=0.45, uses=6)      # ломается
SLIPPER = _w("slipper", "Тапок учителя", "melee", dmg=1, reach=60, cd=0.3, kb=150)

# --- защищаться ---
NOTEBOOK = _w("notebook", "Тетрадь-щит", "shield", cd=0.6, dur=0.7, uses=6)

# --- стрелять ---
SLINGSHOT = _w("slingshot", "Рогатка", "shot", dmg=1, cd=0.35, speed=700, range=650, uses=20)
WATERGUN = _w("watergun", "Водяной пистолет", "shot", dmg=0.5, cd=0.1, speed=620, range=380, uses=60)
FOAMGUN = _w("foamgun", "Пена-пушка", "shot", dmg=1, cd=0.8, speed=480, range=450, kb=130, slow=2.0, uses=10)

# --- кидать ---
CHALK = _w("chalk", "Мел", "throw", dmg=1, cd=0.25, speed=600, vy=-260, grav=1200, uses=25)
TEXTBOOK = _w("textbook", "Учебник", "throw", dmg=3, cd=0.8, speed=460, vy=-320, grav=1300, uses=8)
PLANE = _w("plane", "Бумажный самолётик", "throw", dmg=1, cd=0.3, speed=540, vy=-40, grav=180, uses=18, spin=False)
TRASH = _w("trash", "Мусорка", "throw", dmg=0, cd=1.2, speed=480, vy=-380, grav=1300, stun=2.5, uses=4)
ACID = _w("acid", "Кислота комара", "throw", dmg=1, cd=1.0, speed=520, vy=-350, grav=1300, dot=3.0, uses=5)
PIEBOMB = _w("piebomb", "Пирожок-бомба", "throw", dmg=3, cd=1.0, speed=460, vy=-350, grav=1300, area=110, uses=3)

# --- из спортзала ---
DUMBBELL = _w("dumbbell", "Гантель", "melee", dmg=3, reach=60, cd=0.8)          # тяжёлая: бьёт сильно, медленно
JUMPROPE = _w("jumprope", "Скакалка", "melee", dmg=1, reach=80, cd=0.25)        # длинная и быстрая
BALL = _w("ball", "Мяч", "throw", dmg=2, cd=0.5, speed=560, vy=-180, grav=900, uses=12)

# --- глава 2: мегамаркет ---
TOYGUN = _w("toygun", "Игрушечный пистолет", "shot", dmg=1, cd=0.3, speed=640, range=430, kb=70, stun=0.3,
            uses=30)

PONY = _w("pony", "Игрушка пони", "decoy", dmg=0, cd=1.0, dur=6.0, uses=3)          # скачет по карте и отвлекает всех
CART = _w("cart", "Тележка", "melee", dmg=3, reach=85, cd=0.7, kb=170, uses=8)      # таран из магазина

# --- странное ---
BELL = _w("bell", "Школьный звонок", "bell", cd=1.0, uses=1)

WEAPONS = {w["key"]: w for w in (
    CLUB, RULER, MOP, EXTINGUISHER, POINTER, CHAIR, SLIPPER,
    NOTEBOOK, SLINGSHOT, WATERGUN, FOAMGUN,
    CHALK, TEXTBOOK, PLANE, TRASH, ACID, PIEBOMB, BELL,
    DUMBBELL, JUMPROPE, BALL,
    TOYGUN, PONY, CART,
)}
