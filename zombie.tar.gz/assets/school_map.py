"""Карта школы — как на рисунке Вовы: два коридора, комнаты вдоль них.

Сверху: Туалет, Классы 1-4, Столовая.  Снизу: Спортзал, Финал, Кабинет директора, Классы 5-7.
Комнату выбираешь мышкой или стрелками и Enter.
"""
import math

import pygame

from pixelfont import pixel_font
from settings import H, INK, W

# Порядок = порядок выбора стрелками (сначала верхний ряд слева направо, потом нижний)
MAP_ROOMS = [
    {"id": "toilet", "name": "Туалет", "kind": "toilet", "rect": pygame.Rect(54, 130, 132, 120)},
    {"id": "c1", "name": "Класс 1", "kind": "class", "num": 1, "rect": pygame.Rect(198, 130, 132, 120)},
    {"id": "c2", "name": "Класс 2", "kind": "class", "num": 2, "rect": pygame.Rect(342, 130, 132, 120)},
    {"id": "c3", "name": "Класс 3", "kind": "class", "num": 3, "rect": pygame.Rect(486, 130, 132, 120)},
    {"id": "c4", "name": "Класс 4", "kind": "class", "num": 4, "rect": pygame.Rect(630, 130, 132, 120)},
    {"id": "canteen", "name": "Столовая", "kind": "canteen", "rect": pygame.Rect(774, 130, 132, 120)},
    {"id": "gym", "name": "Спортзал", "kind": "gym", "rect": pygame.Rect(35, 330, 132, 120)},
    {"id": "school", "name": "Школа (финал)", "kind": "final", "rect": pygame.Rect(179, 330, 132, 120)},
    {"id": "office", "name": "Кабинет директора", "kind": "office", "rect": pygame.Rect(323, 330, 170, 120)},
    {"id": "c5", "name": "Класс 5", "kind": "class", "num": 5, "rect": pygame.Rect(505, 330, 132, 120)},
    {"id": "c6", "name": "Класс 6", "kind": "class", "num": 6, "rect": pygame.Rect(649, 330, 132, 120)},
    {"id": "c7", "name": "Класс 7", "kind": "class", "num": 7, "mini": True, "rect": pygame.Rect(793, 330, 132, 120)},
]
ORDER = [r["id"] for r in MAP_ROOMS]
ROOM_BY_ID = {r["id"]: r for r in MAP_ROOMS}
TOP_ROW = ORDER[:6]       # туалет, классы 1-4, столовая
BOTTOM_ROW = ORDER[6:]    # спортзал, школа (финал), кабинет директора, классы 5-7

KIND_COLOR = {"class": (245, 225, 170), "toilet": (170, 215, 235), "office": (215, 100, 100),
              "final": (170, 70, 150), "canteen": (248, 196, 130), "gym": (150, 205, 190)}
LOCKED_COLOR = (72, 78, 100)
DONE_COLOR = (130, 205, 140)
YELLOW = (255, 230, 90)

_fonts = {}


def _font(size):
    if size not in _fonts:
        _fonts[size] = pixel_font(size)
    return _fonts[size]


def room_at(pos):
    """Какая комната под мышкой (или None)."""
    for r in MAP_ROOMS:
        if r["rect"].collidepoint(pos):
            return r["id"]
    return None


def move_selection(selected, key):
    """Стрелки: по ряду влево-вправо и между рядами вверх-вниз."""
    row = TOP_ROW if selected in TOP_ROW else BOTTOM_ROW
    i = row.index(selected)
    if key == pygame.K_LEFT:
        return row[max(0, i - 1)]
    if key == pygame.K_RIGHT:
        return row[min(len(row) - 1, i + 1)]
    if key in (pygame.K_UP, pygame.K_DOWN):
        other = BOTTOM_ROW if row is TOP_ROW else TOP_ROW
        if (key == pygame.K_DOWN) == (row is TOP_ROW):  # вниз из верхнего ряда или вверх из нижнего
            cx = ROOM_BY_ID[selected]["rect"].centerx
            return min(other, key=lambda rid: abs(ROOM_BY_ID[rid]["rect"].centerx - cx))
    return selected


def _lock(s, cx, cy):
    pygame.draw.rect(s, INK, (cx - 11, cy - 20, 22, 20), 4)          # дужка
    pygame.draw.rect(s, INK, (cx - 15, cy - 6, 30, 22))              # корпус
    pygame.draw.rect(s, (230, 190, 70), (cx - 12, cy - 3, 24, 16))
    pygame.draw.rect(s, INK, (cx - 2, cy + 2, 4, 6))                 # замочная скважина


def _check(s, cx, cy):
    pts = [(cx - 20, cy), (cx - 6, cy + 16), (cx + 22, cy - 18)]
    pygame.draw.lines(s, (25, 100, 45), False, pts, 10)


def _draw_room(s, room, status, selected, tick):
    r = room["rect"]
    top_row = room["id"] in TOP_ROW
    fill = {"locked": LOCKED_COLOR, "done": DONE_COLOR}.get(status, KIND_COLOR[room["kind"]])
    bob = int(math.sin(tick / 180) * 3) if selected else 0
    box = r.move(0, -bob if top_row else bob)
    pygame.draw.rect(s, INK, box.inflate(8, 8))
    pygame.draw.rect(s, fill, box)
    if selected:
        pygame.draw.rect(s, YELLOW, box.inflate(12, 12), 6)
    # дверь в коридор
    door_color = YELLOW if status == "open" else (110, 115, 135)
    door = pygame.Rect(box.centerx - 16, box.bottom - 6 if top_row else box.top - 2, 32, 8)
    pygame.draw.rect(s, door_color, door)

    ink = (30, 30, 40) if status != "locked" else (150, 155, 175)
    if room["kind"] == "class":
        label = _font(18).render("КЛАСС", True, ink)
        s.blit(label, label.get_rect(midtop=(box.centerx, box.y + 10)))
        num = _font(56).render(str(room["num"]), True, ink)
        s.blit(num, num.get_rect(center=(box.centerx, box.centery + 8)))
        if room.get("mini"):
            tag = _font(14).render("МИНИ-БОСС", True, (170, 40, 40) if status != "locked" else ink)
            s.blit(tag, tag.get_rect(midbottom=(box.centerx - 12, box.bottom - 6)))
    elif room["kind"] == "toilet":
        label = _font(26).render("ТУАЛЕТ", True, ink)
        s.blit(label, label.get_rect(center=(box.centerx, box.centery - 6)))
        small = _font(15).render("бонус: лут", True, ink)
        s.blit(small, small.get_rect(center=(box.centerx, box.centery + 22)))
    elif room["kind"] in ("canteen", "gym"):
        title, tag = ("СТОЛОВАЯ", "бонус: еда") if room["kind"] == "canteen" else ("СПОРТЗАЛ", "бонус: оружие")
        label = _font(19).render(title, True, ink)
        s.blit(label, label.get_rect(center=(box.centerx, box.centery - 6)))
        small = _font(15).render(tag, True, ink)
        s.blit(small, small.get_rect(center=(box.centerx, box.centery + 22)))
    else:
        words = ("ФИНАЛ", "ШКОЛА") if room["kind"] == "final" else ("КАБИНЕТ", "ДИРЕКТОРА")
        for i, word in enumerate(words):
            label = _font(24).render(word, True, (255, 255, 255) if status != "locked" else ink)
            s.blit(label, label.get_rect(center=(box.centerx, box.centery - 18 + i * 28)))
        small = _font(15).render("БОСС", True, (255, 235, 120) if status != "locked" else ink)
        s.blit(small, small.get_rect(center=(box.centerx, box.bottom - 18)))
    if status == "locked":
        _lock(s, box.right - 28, box.bottom - 30)
    elif status == "done":
        _check(s, box.right - 34, box.bottom - 30)


def draw_map(s, status_of, selected, done_count, msg, weapon_text, hp, sprites, has_key=False, max_hp=5):
    s.fill((26, 34, 60))
    for x in range(0, W, 40):
        pygame.draw.line(s, (36, 46, 78), (x, 0), (x, H))
    for y in range(0, H, 40):
        pygame.draw.line(s, (36, 46, 78), (0, y), (W, y))

    title = _font(36).render("КАРТА ШКОЛЫ", True, (255, 255, 255))
    s.blit(title, title.get_rect(midtop=(W // 2, 18)))

    # коридоры — две толстые линии, как на рисунке
    for y in (250, 330):
        pygame.draw.rect(s, (235, 230, 210), (10, y - 3, W - 20, 6))
    hint = _font(17).render("Классы по порядку. Столовая — после 3-го, спортзал — после 5-го. Ключ — в 7-м классе.",
                            True, (170, 185, 220))
    s.blit(hint, hint.get_rect(center=(W // 2, 290)))

    tick = pygame.time.get_ticks()
    for room in MAP_ROOMS:
        _draw_room(s, room, status_of(room["id"]), room["id"] == selected, tick)

    # низ: сердца, оружие, подсказка
    for i in range(max_hp):
        img = sprites.heart if i < hp else sprites.heart_empty
        s.blit(img, (20 + i * 32, H - 62))
    info = _font(20).render(f"Оружие: {weapon_text}      Зачищено: {done_count}/{len(MAP_ROOMS)}", True, (255, 255, 255))
    s.blit(info, (max(190, 20 + max_hp * 32 + 16), H - 60))
    if has_key:  # ключ от кабинета директора
        s.blit(sprites.key, (W - 150, H - 62))
        label = _font(16).render("ключ у тебя", True, (255, 230, 120))
        s.blit(label, (W - 100, H - 58))
    tip = _font(17).render("Мышка или стрелки + Enter — выбрать комнату", True, (170, 185, 220))
    s.blit(tip, tip.get_rect(midbottom=(W // 2, H - 10)))

    if msg:
        txt = _font(22).render(msg, True, (255, 255, 255))
        box = txt.get_rect(center=(W // 2, 290)).inflate(28, 14)
        pygame.draw.rect(s, (160, 50, 60), box, border_radius=8)
        pygame.draw.rect(s, INK, box, 3, border_radius=8)
        s.blit(txt, txt.get_rect(center=box.center))
