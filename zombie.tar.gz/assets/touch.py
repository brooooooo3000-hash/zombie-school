"""Сенсорное управление для телефонов: стрелки ◀ ▶ слева, кнопки справа.

Включается само в веб-версии (iPhone/Android) или флагом `python game.py --touch`.
Работает через события пальцев (FINGER*), поэтому можно держать джойстик и жать кнопки одновременно.
Мышь (только настоящая, не «эмуляция» от пальца) тоже умеет нажимать эти кнопки — удобно проверять на компьютере.
"""
import math
import sys

import pygame

from pixelfont import pixel_font
from settings import H, INK, W

ENABLED = sys.platform == "emscripten" or "--touch" in sys.argv

# кнопки: имя -> (центр, радиус, подпись)
BUTTONS = {
    "left": ((85, 440), 58, "<"),
    "right": ((225, 440), 58, ">"),
    "attack": ((850, 405), 66, "УДАР"),
    "jump": ((725, 462), 50, "ПРЫЖОК"),
    "take": ((850, 275), 46, "ВЗЯТЬ"),
    "run": ((725, 345), 40, "БЕГ"),
}
ARROWS = ("left", "right")
MAP_RECT = pygame.Rect(W - 128, 50, 120, 44)       # «Карта» справа под строкой оружия
SKIP_RECT = pygame.Rect(W - 190, 8, 182, 44)      # «Пропустить» в катсцене
RESTART_RECT = pygame.Rect(W // 2 - 150, 340, 300, 70)   # «Заново» после поражения


class Touch:
    def __init__(self):
        self.enabled = ENABLED
        self.fingers = {}         # id пальца -> имя кнопки
        self.held = set()         # зажатые кнопки
        self.pending = []         # одноразовые нажатия: "take", "map"

    # ---- события ----
    def handle(self, e, playing):
        """Кнопки и джойстик в бою. Касания «пальцем» приходят как FINGER*, мышиные копии от пальца (e.touch) не берём."""
        if not self.enabled:
            return False
        if e.type in (pygame.FINGERDOWN, pygame.FINGERMOTION, pygame.FINGERUP):
            pos = (e.x * W, e.y * H)
            fid = ("f", e.finger_id)
        elif e.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEMOTION, pygame.MOUSEBUTTONUP) and not getattr(e, "touch", False):
            if e.type == pygame.MOUSEMOTION and not e.buttons[0]:
                return False
            if e.type != pygame.MOUSEMOTION and e.button != 1:
                return False
            pos = e.pos
            fid = ("m", 0)
        else:
            return False
        down = e.type in (pygame.FINGERDOWN, pygame.MOUSEBUTTONDOWN)
        up = e.type in (pygame.FINGERUP, pygame.MOUSEBUTTONUP)
        if down:
            if not playing:
                return False  # вне боя нажатие обрабатывает сама игра (карта, катсцены...)
            self._press(fid, pos)
        elif up:
            self._release(fid)
        else:
            self._move(fid, pos)
        return True

    def _press(self, fid, pos):
        if MAP_RECT.collidepoint(pos):
            self.pending.append("map")
            return
        name = self._button_at(pos)
        if name:
            self.fingers[fid] = name
            if name == "take":
                self.pending.append("take")
            else:
                self.held.add(name)

    @staticmethod
    def _button_at(pos):
        for name, (c, r, _) in BUTTONS.items():
            if math.hypot(pos[0] - c[0], pos[1] - c[1]) <= r * (1.3 if name in ARROWS else 1.2):
                return name
        return None

    def _move(self, fid, pos):
        """Палец можно вести со стрелки на стрелку: направление меняется на лету."""
        cur = self.fingers.get(fid)
        if cur in ARROWS:
            new = self._button_at(pos)
            new = new if new in ARROWS else None
            if new != cur:
                self.held.discard(cur)
                if new:
                    self.fingers[fid] = new
                    self.held.add(new)
                else:
                    self.fingers[fid] = "off"   # палец ушёл со стрелок

    def _release(self, fid):
        what = self.fingers.pop(fid, None)
        if what:
            self.held.discard(what)

    def reset(self):
        self.fingers.clear()
        self.held.clear()

    def take_pending(self):
        out, self.pending = self.pending, []
        return out

    # ---- что нажато (для игры) ----
    def pressed(self, key):
        if not self.enabled:
            return False
        if key == pygame.K_LEFT:
            return "left" in self.held and "right" not in self.held
        if key == pygame.K_RIGHT:
            return "right" in self.held and "left" not in self.held
        if key == pygame.K_SPACE:
            return "jump" in self.held
        if key == pygame.K_j:
            return "attack" in self.held
        if key == pygame.K_LSHIFT:
            return "run" in self.held
        return False

    # ---- рисование ----
    def draw(self, s, state, over):
        if not self.enabled:
            return
        font = pixel_font(20)
        big = pixel_font(48)
        if state == "play" and not over:
            for name, (c, r, label) in BUTTONS.items():
                self._circle(s, c, r, 210 if name in self.held else 130, label, big if name in ARROWS else font)
            self._rect(s, MAP_RECT, "КАРТА", font)
        elif state == "play" and over:
            self._rect(s, RESTART_RECT, "ЗАНОВО", pixel_font(32))
        elif state == "cutscene":
            self._rect(s, SKIP_RECT, "ПРОПУСТИТЬ", font)

    @staticmethod
    def _circle(s, c, r, alpha, label=None, font=None):
        surf = pygame.Surface((r * 2 + 4, r * 2 + 4), pygame.SRCALPHA)
        pygame.draw.circle(surf, (*INK, alpha), (r + 2, r + 2), r)
        pygame.draw.circle(surf, (255, 255, 255, 190), (r + 2, r + 2), r, 3)
        s.blit(surf, (c[0] - r - 2, c[1] - r - 2))
        if label in ("<", ">"):  # стрелка-треугольник
            k = -1 if label == "<" else 1
            cx, cy = int(c[0]), int(c[1])
            pts = [(cx + k * 22, cy), (cx - k * 16, cy - 26), (cx - k * 16, cy + 26)]
            pygame.draw.polygon(s, INK, [(x + 2, y + 2) for x, y in pts])
            pygame.draw.polygon(s, (255, 255, 255), pts)
        elif label:
            t = font.render(label, True, (255, 255, 255))
            sh = font.render(label, True, INK)
            rect = t.get_rect(center=(int(c[0]), int(c[1])))
            s.blit(sh, rect.move(2, 2))
            s.blit(t, rect)

    @staticmethod
    def _rect(s, rect, label, font):
        surf = pygame.Surface(rect.size, pygame.SRCALPHA)
        pygame.draw.rect(surf, (30, 30, 40, 190), surf.get_rect(), border_radius=10)
        pygame.draw.rect(surf, (255, 255, 255, 220), surf.get_rect(), 3, border_radius=10)
        s.blit(surf, rect)
        t = font.render(label, True, (255, 255, 255))
        s.blit(t, t.get_rect(center=rect.center))


touch = Touch()


class MergedKeys:
    """Клавиши с клавиатуры + то, что нажато на экране."""

    def __init__(self, real):
        self.real = real

    def __getitem__(self, k):
        return bool(self.real[k]) or touch.pressed(k)
