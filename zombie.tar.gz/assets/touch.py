"""Сенсорное управление для телефонов: стрелки ◀ ▶ слева, кнопки справа.

Включается при первом касании пальцем в веб-версии (iPhone/Android) или флагом `python game.py --touch`.
Работает через события пальцев (FINGER*), поэтому можно держать джойстик и жать кнопки одновременно.
Мышь (только настоящая, не «эмуляция» от пальца) тоже умеет нажимать эти кнопки — удобно проверять на компьютере.
"""
import math
import sys

import pygame

from pixelfont import pixel_font
from settings import H, INK, W

ENABLED = "--touch" in sys.argv   # в вебе кнопки включаются при первом касании пальцем (на компьютере их нет)

# кнопки: имя -> (центр, радиус, подпись)
BUTTONS = {
    "left": ((85, 440), 58, "<"),
    "right": ((225, 440), 58, ">"),
    "attack": ((850, 405), 66, "УДАР"),
    "jump": ((725, 462), 50, "ПРЫЖОК"),
    "take": ((850, 275), 46, "ВЗЯТЬ"),
    "run": ((725, 345), 40, "БЕГ"),
    "swap": ((735, 238), 36, "СМЕНА"),   # только у Приколиста: второе оружие
}
ALPHA_IDLE = 85    # прозрачность кнопок (0 — не видно, 255 — сплошные)
ALPHA_HELD = 190   # когда кнопка нажата
ARROWS = ("left", "right")
MAP_RECT = pygame.Rect(W - 128, 50, 120, 44)       # «Карта» справа под строкой оружия
SKIP_RECT = pygame.Rect(W - 190, 8, 182, 44)      # «Пропустить» в катсцене
MENU_RECT = pygame.Rect(W - 128, 98, 120, 44)     # «Меню» под «Картой»
RESTART_RECT = pygame.Rect(W // 2 - 150, 330, 300, 70)   # «Ещё раз» / «Заново» после поражения
MENU_OVER_RECT = pygame.Rect(W // 2 - 150, 414, 300, 56)  # «В меню» после поражения


class Touch:
    def __init__(self):
        self.enabled = ENABLED
        self.fingers = {}         # id пальца -> имя кнопки
        self.held = set()         # зажатые кнопки
        self.pending = []         # одноразовые нажатия: "take", "map", "menu"
        self.two_slots = False    # есть ли кнопка «смена оружия»

    # ---- события ----
    def handle(self, e, playing):
        """Кнопки и джойстик в бою. Касания «пальцем» приходят как FINGER*, мышиные копии от пальца (e.touch) не берём."""
        if not self.enabled:
            return False
        if e.type in (pygame.FINGERDOWN, pygame.FINGERMOTION, pygame.FINGERUP):
            pos = (e.x * W, e.y * H)
            fid = ("f", e.finger_id)
        elif e.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEMOTION, pygame.MOUSEBUTTONUP) and not getattr(e, "touch", False):
            if e.type == pygame.MOUSEMOTION and not e.buttons[0]:
                return False
            if e.type != pygame.MOUSEMOTION and e.button != 1:
                return False
            pos = e.pos
            fid = ("m", 0)
        else:
            return False
        down = e.type in (pygame.FINGERDOWN, pygame.MOUSEBUTTONDOWN)
        up = e.type in (pygame.FINGERUP, pygame.MOUSEBUTTONUP)
        if down:
            if not playing:
                return False  # вне боя нажатие обрабатывает сама игра (карта, катсцены...)
            self._press(fid, pos)
        elif up:
            self._release(fid)
        else:
            self._move(fid, pos)
        return True

    def _press(self, fid, pos):
        if MAP_RECT.collidepoint(pos):
            self.pending.append("map")
            return
        if MENU_RECT.collidepoint(pos):
            self.pending.append("menu")
            return
        name = self._button_at(pos)
        if name:
            self.fingers[fid] = name
            if name in ("take", "swap"):
                self.pending.append(name)
            self.held.add(name)  # «взять» ещё и держится: в главе 2 им «затаивают дыхание"

    def _button_at(self, pos):
        for name, (c, r, _) in BUTTONS.items():
            if name == "swap" and not self.two_slots:
                continue
            if math.hypot(pos[0] - c[0], pos[1] - c[1]) <= r * (1.3 if name in ARROWS else 1.2):
                return name
        return None

    def _move(self, fid, pos):
        """Палец можно вести со стрелки на стрелку: направление меняется на лету."""
        cur = self.fingers.get(fid)
        if cur in ARROWS:
            new = self._button_at(pos)
            new = new if new in ARROWS else None
            if new != cur:
                self.held.discard(cur)
                if new:
                    self.fingers[fid] = new
                    self.held.add(new)
                else:
                    self.fingers[fid] = "off"   # палец ушёл со стрелок

    def _release(self, fid):
        what = self.fingers.pop(fid, None)
        if what:
            self.held.discard(what)

    def reset(self):
        self.fingers.clear()
        self.held.clear()

    def take_pending(self):
        out, self.pending = self.pending, []
        return out

    # ---- что нажато (для игры) ----
    def pressed(self, key):
        if not self.enabled:
            return False
        if key == pygame.K_LEFT:
            return "left" in self.held and "right" not in self.held
        if key == pygame.K_RIGHT:
            return "right" in self.held and "left" not in self.held
        if key == pygame.K_SPACE:
            return "jump" in self.held
        if key == pygame.K_j:
            return "attack" in self.held
        if key == pygame.K_LSHIFT:
            return "run" in self.held
        if key == pygame.K_e:
            return "take" in self.held
        return False

    # ---- рисование ----
    def draw(self, s, state, over, retry_label="ЗАНОВО"):
        if not self.enabled:
            return
        font = pixel_font(20)
        big = pixel_font(48)
        if state == "play" and not over:
            for name, (c, r, label) in BUTTONS.items():
                if name == "swap" and not self.two_slots:
                    continue
                self._circle(s, c, r, name in self.held, label, big if name in ARROWS else
                             (pixel_font(16) if len(label) > 6 else font))
            self._rect(s, MAP_RECT, "КАРТА", font)
            self._rect(s, MENU_RECT, "МЕНЮ", font)
        elif state == "play" and over:
            self._rect(s, RESTART_RECT, retry_label, pixel_font(32))
            self._rect(s, MENU_OVER_RECT, "В МЕНЮ", pixel_font(24))
        elif state == "cutscene":
            self._rect(s, SKIP_RECT, "ПРОПУСТИТЬ", font)

    @staticmethod
    def _circle(s, c, r, held, label=None, font=None):
        """Кнопка рисуется на своём слое, а слой делаем полупрозрачным, чтобы игра была видна сквозь кнопки."""
        size = r * 2 + 4
        surf = pygame.Surface((size, size), pygame.SRCALPHA)
        m = (r + 2, r + 2)
        pygame.draw.circle(surf, (*INK, 200), m, r)
        pygame.draw.circle(surf, (255, 255, 255, 255), m, r, 3)
        if label in ("<", ">"):  # стрелка-треугольник
            k = -1 if label == "<" else 1
            pts = [(m[0] + k * 22, m[1]), (m[0] - k * 16, m[1] - 26), (m[0] - k * 16, m[1] + 26)]
            pygame.draw.polygon(surf, (255, 255, 255), pts)
        elif label:
            t = font.render(label, True, (255, 255, 255))
            surf.blit(t, t.get_rect(center=m))
        surf.set_alpha(ALPHA_HELD if held else ALPHA_IDLE)
        s.blit(surf, (c[0] - r - 2, c[1] - r - 2))

    @staticmethod
    def _rect(s, rect, label, font):
        surf = pygame.Surface(rect.size, pygame.SRCALPHA)
        pygame.draw.rect(surf, (*INK, 200), surf.get_rect(), border_radius=10)
        pygame.draw.rect(surf, (255, 255, 255, 255), surf.get_rect(), 3, border_radius=10)
        t = font.render(label, True, (255, 255, 255))
        surf.blit(t, t.get_rect(center=surf.get_rect().center))
        surf.set_alpha(ALPHA_IDLE + 30)
        s.blit(surf, rect)


touch = Touch()


class MergedKeys:
    """Клавиши с клавиатуры + то, что нажато на экране."""

    def __init__(self, real):
        self.real = real

    def __getitem__(self, k):
        return bool(self.real[k]) or touch.pressed(k)
