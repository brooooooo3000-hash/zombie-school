"""Карта главы 3 («Поезд»): вагоны по порядку в один ряд, как карты глав 1 и 2.

Выбираешь вагон или комнату мышкой или стрелками + Enter. Следующая открывается, когда пройдена предыдущая.
Хочешь другую раскладку или цвета? Правь CFG.
"""
import math

import pygame

from market import _check, _lock
from pixelfont import pixel_font
from rooms_park import ORDER_PARK, ROOMS_PARK, ferris
from rooms_train import ORDER_TRAIN, ROOMS_TRAIN
from settings import H, INK, W

YELLOW = (255, 230, 90)
LOCKED_COLOR = (72, 78, 100)
DONE_COLOR = (130, 205, 140)

CFG = {
    3: {"title": "ПЛАН ПОЕЗДА", "rooms": ROOMS_TRAIN, "order": ORDER_TRAIN, "bg": (22, 30, 52), "grid": (32, 42, 70),
        "hint": "Вагоны по порядку. Кабина машиниста открывается последней.", "boss": "cab", "train": True,
        "color": {"seats": (170, 190, 235), "cafe": (235, 205, 150), "sleeper": (175, 165, 225),
                  "luggage": (195, 195, 170), "cab": (245, 165, 95)}},
    4: {"title": "КАРТА ПАРКА", "rooms": ROOMS_PARK, "order": ORDER_PARK, "bg": (24, 18, 50), "grid": (36, 28, 70),
        "hint": "Аттракционы по порядку. Шатёр талисмана открывается последним.", "boss": "ptent", "train": False,
        "park": True,
        "color": {"pgate": (245, 150, 190), "pcarousel": (250, 215, 110), "pcoaster": (240, 120, 110),
                  "phouse": (180, 150, 235), "ptent": (245, 165, 95)}},
}
CAR_W, CAR_GAP, CAR_Y, CAR_H = 164, 12, 160, 170


def rects(chapter):
    """Где на карте каждая комната: {id: Rect}."""
    order = CFG[chapter]["order"]
    total = len(order) * CAR_W + (len(order) - 1) * CAR_GAP
    x0 = (W - total) // 2
    return {rid: pygame.Rect(x0 + i * (CAR_W + CAR_GAP), CAR_Y, CAR_W, CAR_H) for i, rid in enumerate(order)}


def room_at(chapter, pos):
    for rid, r in rects(chapter).items():
        if r.collidepoint(pos):
            return rid
    return None


def move_selection(chapter, selected, key):
    order = CFG[chapter]["order"]
    i = order.index(selected) if selected in order else 0
    if key == pygame.K_LEFT:
        return order[max(0, i - 1)]
    if key == pygame.K_RIGHT:
        return order[min(len(order) - 1, i + 1)]
    return selected


def status_of(chapter, rid, cleared):
    """done — пройдена, open — можно идти, locked — закрыта (идут по порядку)."""
    if rid in cleared:
        return "done"
    order = CFG[chapter]["order"]
    i = order.index(rid)
    return "open" if i == 0 or order[i - 1] in cleared else "locked"


def lock_name(chapter, rid):
    """Название комнаты, которую надо пройти раньше."""
    order = CFG[chapter]["order"]
    prev = order[order.index(rid) - 1]
    return next(r["name"] for r in CFG[chapter]["rooms"] if r["id"] == prev)


def _draw_car(s, cfg, room, r, status, selected, tick, num):
    bob = int(math.sin(tick / 180) * 3) if selected else 0
    box = r.move(0, -bob)
    fill = {"locked": LOCKED_COLOR, "done": DONE_COLOR}.get(status, cfg["color"][room["id"]])
    pygame.draw.rect(s, INK, box.inflate(8, 8), border_radius=10)
    pygame.draw.rect(s, fill, box, border_radius=8)
    if selected:
        pygame.draw.rect(s, YELLOW, box.inflate(14, 14), 6, border_radius=12)
    ink = (30, 30, 40) if status != "locked" else (150, 155, 175)
    win = (255, 245, 190) if status == "open" else ((235, 245, 235) if status == "done" else (96, 102, 124))
    if cfg["train"]:   # окна, колёса и сцепка
        for k in range(3):
            pygame.draw.rect(s, INK, (box.x + 14 + k * 46, box.y + 14, 38, 30))
            pygame.draw.rect(s, win, (box.x + 17 + k * 46, box.y + 17, 32, 24))
        for wx in (box.x + 28, box.right - 52):
            pygame.draw.circle(s, INK, (wx + 12, box.bottom + 6), 15)
            pygame.draw.circle(s, (170, 175, 190), (wx + 12, box.bottom + 6), 8)
        if room["id"] != cfg["order"][-1]:
            pygame.draw.rect(s, INK, (box.right, box.centery + 30, CAR_GAP + 2, 10))
    else:   # окошки-двери комнат
        pygame.draw.rect(s, INK, (box.centerx - 22, box.y + 12, 44, 40))
        pygame.draw.rect(s, win, (box.centerx - 19, box.y + 15, 38, 34))
    name = pixel_font(18).render(room["name"], True, ink)
    if name.get_width() > box.w - 12:
        name = pixel_font(14).render(room["name"], True, ink)
    s.blit(name, name.get_rect(center=(box.centerx, box.centery + 14)))
    if room["id"] == cfg["boss"]:
        small = pixel_font(16).render("БОСС", True, (170, 40, 40) if status != "locked" else ink)
        s.blit(small, small.get_rect(center=(box.centerx, box.centery + 44)))
    else:
        n = pixel_font(36).render(str(num), True, ink)
        s.blit(n, n.get_rect(center=(box.centerx, box.centery + 50)))
    if status == "locked":
        _lock(s, box.right - 28, box.bottom - 30)
    elif status == "done":
        _check(s, box.right - 34, box.bottom - 30)


def draw_story_map(s, chapter, status, selected, done_count, msg, weapon_text, hp, sprites, max_hp=5):
    cfg = CFG[chapter]
    s.fill(cfg["bg"])
    for x in range(0, W, 40):
        pygame.draw.line(s, cfg["grid"], (x, 0), (x, H))
    for y in range(0, H, 40):
        pygame.draw.line(s, cfg["grid"], (0, y), (W, y))
    title = pixel_font(36).render(cfg["title"], True, (255, 255, 255))
    s.blit(title, title.get_rect(midtop=(W // 2, 18)))
    if cfg["train"]:   # рельсы под поездом
        pygame.draw.rect(s, (90, 94, 108), (0, CAR_Y + CAR_H + 20, W, 8))
        for x in range(0, W, 28):
            pygame.draw.rect(s, (60, 64, 78), (x, CAR_Y + CAR_H + 28, 14, 6))
    if cfg.get("park"):   # дорожка парка и колесо обозрения на заднем плане
        ferris(s, 800, 430, 80, pygame.time.get_ticks() / 1000)
        for x in range(0, W, 36):
            pygame.draw.rect(s, (110, 100, 150), (x, CAR_Y + CAR_H + 22, 22, 6))
    hint = pixel_font(17).render(cfg["hint"], True, (170, 190, 210))
    s.blit(hint, hint.get_rect(center=(W // 2, 120)))
    tick = pygame.time.get_ticks()
    for i, room in enumerate(cfg["rooms"]):
        _draw_car(s, cfg, room, rects(chapter)[room["id"]], status(room["id"]), room["id"] == selected, tick, i + 1)
    for i in range(max_hp):
        img = sprites.heart if i < hp else sprites.heart_empty
        s.blit(img, (20 + i * 32, H - 62))
    info = pixel_font(20).render(f"Оружие: {weapon_text}      Зачищено: {done_count}/{len(cfg['rooms'])}", True,
                                 (255, 255, 255))
    s.blit(info, (max(190, 20 + max_hp * 32 + 16), H - 60))
    tip = pixel_font(17).render("Мышка или стрелки + Enter — выбрать комнату", True, (170, 190, 210))
    s.blit(tip, tip.get_rect(midbottom=(W // 2, H - 10)))
    if msg:
        txt = pixel_font(22).render(msg, True, (255, 255, 255))
        box = txt.get_rect(center=(W // 2, 390)).inflate(28, 14)
        pygame.draw.rect(s, (160, 50, 60), box, border_radius=8)
        pygame.draw.rect(s, INK, box, 3, border_radius=8)
        s.blit(txt, txt.get_rect(center=box.center))
