"""Картинки главы 4 «Парк аттракционов»: новые зомби (высокий, толстяк, гигант, мелкий) и босс-талисман.

Рисуются кодом на маленькой картинке и увеличиваются в 4 раза, как в market_art.py.
Каждый враг — словарь кадров {"a", "b", "a_flash", "b_flash"}, все смотрят вправо (игра сама разворачивает их влево).
У гиганта два вида картинок: "giant" (мелкий сидит у него на спине) и "giant_free" (мелкого уже бросили).
"""
import pygame

from market_art import INK, _dot, _finish, _pair

SKIN, SKIN_D = (110, 190, 110), (70, 140, 80)   # кожа зомби и её тень (как у обычного зомби)
EYE, MOUTH = (240, 230, 70), (200, 40, 60)
TEETH = (250, 250, 240)


def _rect(s, color, x, y, w, h):
    pygame.draw.rect(s, color, (x, y, w, h))


# ---------------------------------------------------------------- высокий: длинные руки и ноги
def draw_tall(s, step):
    shirt, shirt_d, pants, shoe = (120, 100, 175), (85, 70, 135), (70, 70, 100), (50, 50, 70)
    _rect(s, SKIN, 3, 0, 5, 5)                       # голова
    _dot(s, EYE, 6, 1, 1, 2)
    _rect(s, MOUTH, 5, 3, 3, 1)
    _dot(s, TEETH, 6, 3, 1, 1)
    _rect(s, SKIN_D, 3, 0, 5, 1)                     # волосы-лохмотья
    _rect(s, SKIN_D, 4, 5, 3, 1)                     # шея
    _rect(s, shirt, 2, 6, 7, 7)                      # рваная рубашка
    _rect(s, shirt_d, 2, 11, 2, 2)
    _rect(s, shirt_d, 6, 12, 3, 1)
    _rect(s, SKIN_D, 7, 9, 6, 2)                     # дальняя рука, длинная
    _rect(s, SKIN, 7, 7, 6, 2)                       # ближняя рука, тянется вперёд
    _dot(s, SKIN_D, 12, 9, 2, 2)
    _dot(s, SKIN, 12, 7, 2, 2)
    left, right = (3, 6) if step == 0 else (4, 5)
    _rect(s, pants, left, 13, 2, 7)                  # длинные ноги
    _rect(s, pants, right, 13, 2, 7)
    _rect(s, shoe, left, 20, 3, 1)
    _rect(s, shoe, right, 20, 3, 1)


# ---------------------------------------------------------------- толстяк: круглый, медленный, крепкий
def draw_fat(s, step):
    shirt, belly, pants = (210, 130, 70), (235, 175, 120), (80, 80, 110)
    pygame.draw.ellipse(s, shirt, (0, 3, 13, 10))    # огромное тело
    pygame.draw.ellipse(s, belly, (3, 6, 8, 6))      # пузо
    _dot(s, (150, 80, 40), 5, 8, 1, 1)               # пуговица
    _dot(s, (150, 80, 40), 7, 10, 3, 1)              # пятно от соуса
    pygame.draw.circle(s, SKIN, (11, 4), 3)          # маленькая голова
    _dot(s, EYE, 12, 3, 1, 1)
    _rect(s, MOUTH, 11, 5, 3, 1)
    _dot(s, TEETH, 12, 5, 1, 1)
    _rect(s, SKIN, 11, 8, 5, 2)                      # короткие руки вперёд
    _dot(s, SKIN, 15, 8, 1, 2)
    l, r = (2, 8) if step == 0 else (3, 7)
    _rect(s, pants, l, 12, 3, 2)
    _rect(s, pants, r, 12, 3, 2)


# ---------------------------------------------------------------- мелкий: чертёнок-зомби
def draw_imp_at(s, ox, oy, step):
    """Мелкий (его рисуют и отдельно, и на спине у гиганта). ox, oy — левый верхний угол."""
    horn = (150, 40, 60)
    _dot(s, horn, ox + 1, oy, 1, 2)
    _dot(s, horn, ox + 5, oy, 1, 2)
    _rect(s, (150, 210, 90), ox + 1, oy + 2, 5, 4)   # большая голова
    _dot(s, (255, 255, 255), ox + 2, oy + 3, 2, 1)
    _dot(s, (220, 40, 60), ox + 3, oy + 3, 1, 1)
    _rect(s, MOUTH, ox + 2, oy + 5, 3, 1)
    _rect(s, (95, 70, 130), ox + 2, oy + 6, 3, 2)    # тельце в лохмотьях
    _dot(s, (150, 210, 90), ox, oy + 6, 1, 2)        # ручки тянутся
    _dot(s, (150, 210, 90), ox + 5, oy + 6, 1, 2)
    if step == 0:
        _dot(s, (60, 50, 90), ox + 2, oy + 8, 1, 1)
        _dot(s, (60, 50, 90), ox + 4, oy + 8, 1, 1)
    else:
        _dot(s, (60, 50, 90), ox + 3, oy + 8, 1, 1)


def draw_imp(s, step):
    draw_imp_at(s, 0, 0, step)


# ---------------------------------------------------------------- гигант: мелкий сидит у него на спине
def draw_giant_body(s, step):
    shirt, shirt_d, pants, shoe = (125, 60, 75), (90, 40, 55), (70, 70, 105), (45, 45, 65)
    _rect(s, SKIN, 9, 0, 8, 7)                       # голова
    _rect(s, SKIN_D, 9, 0, 8, 2)
    _rect(s, (255, 255, 255), 13, 2, 3, 2)           # глаз
    _dot(s, (220, 40, 60), 14, 2, 2, 2)
    _rect(s, MOUTH, 12, 5, 5, 2)                     # огромная пасть
    for x in (12, 14, 16):
        _dot(s, TEETH, x, 5, 1, 1)
    _rect(s, SKIN_D, 11, 7, 4, 1)                    # шея
    _rect(s, shirt, 5, 8, 14, 10)                    # могучая грудь
    _rect(s, shirt_d, 5, 14, 3, 4)                   # лохмотья
    _rect(s, shirt_d, 14, 16, 5, 2)
    _rect(s, SKIN_D, 19, 12, 4, 3)                   # дальняя рука
    _rect(s, SKIN, 15, 9, 6, 5)                      # ближняя рука, толстая
    _rect(s, SKIN, 20, 12, 4, 4)                     # кулак
    left, right = (6, 13) if step == 0 else (7, 12)
    _rect(s, pants, left, 18, 5, 7)
    _rect(s, pants, right, 18, 5, 7)
    _rect(s, shoe, left - 1, 25, 7, 2)
    _rect(s, shoe, right - 1, 25, 7, 2)


def draw_giant(s, step):
    """Гигант с мелким на спине."""
    draw_imp_at(s, 0, 4 + step, 0)                   # мелкий вцепился и качается
    draw_giant_body(s, step)


def draw_giant_free(s, step):
    draw_giant_body(s, step)


# ---------------------------------------------------------------- босс: зомби-талисман парка
FUR, FUR_D, LIGHT = (150, 100, 60), (110, 70, 40), (215, 170, 120)


def draw_mascot_frame(s, name, step):
    bob = 1 if step in (1, 3) else 0
    lean = 2 if name == "charge" else 0
    # ноги
    lift_l = 1 if step == 1 else 0
    lift_r = 1 if step == 3 else 0
    _rect(s, FUR_D, 6 + lean, 23 - lift_l, 4, 4 + lift_l)
    _rect(s, FUR, 13 + lean, 23 - lift_r, 4, 4 + lift_r)
    _rect(s, (60, 40, 30), 5 + lean, 26, 5, 1)
    _rect(s, (60, 40, 30), 12 + lean, 26, 5, 1)
    # тело и пузо
    pygame.draw.ellipse(s, FUR, (4 + lean, 13 - bob, 14, 12))
    pygame.draw.ellipse(s, LIGHT, (7 + lean, 15 - bob, 8, 8))
    _rect(s, (210, 50, 60), 9 + lean, 13 - bob, 4, 2)     # бабочка
    _dot(s, (140, 20, 30), 10 + lean, 13 - bob, 2, 2)
    # ближняя рука
    if name == "throw":   # кидает шарик: рука вверх и пучок шаров
        _rect(s, FUR, 16 + lean, 8 - bob, 2, 8)
        for (bx, by, col) in ((16, 3, (230, 60, 70)), (19, 5, (245, 215, 70)), (21, 2, (90, 160, 235))):
            pygame.draw.circle(s, col, (bx + lean, by - bob), 2)
            _dot(s, (255, 255, 255), bx + lean - 1, by - bob - 1, 1, 1)
        _rect(s, LIGHT, 16 + lean, 8 - bob, 2, 1)
    else:
        _rect(s, FUR, 16 + lean, 15 - bob, 6, 3)
        _rect(s, LIGHT, 20 + lean, 15 - bob, 2, 3)
    _rect(s, FUR_D, 3 + lean, 15 - bob, 3, 4)             # дальняя рука
    # голова
    hx, hy = 11 + lean, 9 - bob
    pygame.draw.circle(s, FUR, (hx - 5, hy - 4), 2)      # уши
    pygame.draw.circle(s, FUR, (hx + 5, hy - 4), 2)
    _dot(s, (230, 150, 160), hx - 5, hy - 4, 1, 1)
    pygame.draw.circle(s, FUR, (hx, hy), 6)
    pygame.draw.circle(s, (140, 185, 140), (hx - 3, hy + 1), 3)   # зелёное пятно: он заражён
    pygame.draw.ellipse(s, LIGHT, (hx + 1, hy + 1, 6, 4))        # морда
    _dot(s, INK, hx + 6, hy + 1, 2, 2)                   # нос
    _rect(s, (230, 60, 70), hx + 1, hy - 2, 3, 3)        # красный глаз
    _dot(s, (255, 255, 255), hx + 1, hy - 2, 1, 1)
    _dot(s, INK, hx - 4, hy - 2, 1, 1)                   # глаз-крестик (пуговица)
    _dot(s, INK, hx - 2, hy - 2, 1, 1)
    _dot(s, INK, hx - 3, hy - 1, 1, 1)
    _dot(s, INK, hx - 4, hy, 1, 1)
    _dot(s, INK, hx - 2, hy, 1, 1)
    if name in ("throw", "charge"):                       # пасть нараспашку
        _rect(s, MOUTH, hx + 1, hy + 3, 5, 2)
        _dot(s, TEETH, hx + 2, hy + 3, 1, 1)
        _dot(s, TEETH, hx + 4, hy + 3, 1, 1)
    else:                                                 # зашитая улыбка
        _rect(s, INK, hx + 1, hy + 4, 5, 1)
        for x in (hx + 2, hx + 4):
            _dot(s, INK, x, hy + 3, 1, 1)
    pygame.draw.polygon(s, (245, 110, 170), [(hx - 3, hy - 5), (hx + 3, hy - 5), (hx, hy - 10)])   # праздничный колпак
    _dot(s, (255, 225, 90), hx, hy - 10, 1, 1)
    _rect(s, (255, 225, 90), hx - 2, hy - 7, 4, 1)


def make_mascot():
    frames = {}
    for name, step in (("walk0", 0), ("walk1", 1), ("walk2", 2), ("walk3", 3), ("throw", 0), ("charge", 0)):
        small = pygame.Surface((24, 28), pygame.SRCALPHA)
        draw_mascot_frame(small, name, step)
        frames[name] = _finish(small)
        frames[name + "_flash"] = _finish(small, flash=True)
    return frames


ENEMY_DRAW = {"tall": (draw_tall, 14, 21), "fat": (draw_fat, 16, 14), "imp": (draw_imp, 7, 9),
              "giant": (draw_giant, 24, 27), "giant_free": (draw_giant_free, 24, 27)}


def make_all():
    """Все картинки главы 4 одним словарём (market_art.make_all кладёт его вместе со своими)."""
    out = {kind: _pair(fn, w, h) for kind, (fn, w, h) in ENEMY_DRAW.items()}
    out["mascot"] = make_mascot()
    return out
