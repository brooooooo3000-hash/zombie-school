"""Модификаторы бесконечного режима: перед стартом выбираешь минимум 5, они меняют правила игры.

Хочешь свой модификатор? Три шага:
  1. Добавь строку в MODS: (ключ, название, описание, категория, группа).
     Группа — если два модификатора нельзя брать вместе (как три гравитации), у них одно слово.
  2. В классе Mods напиши, что он делает: числа — в gravity() / time_scale() / ..., события — в update().
  3. Добавь перевод названия и описания в translations.py.
"""
import math
import random

import pygame

from settings import FLOOR, H, INK, W

MIN_PICK = 5   # столько модификаторов нужно выбрать, чтобы начать

# цвет полоски на карточке по категории
CATS = {"phys": (95, 155, 235), "view": (175, 115, 225), "hazard": (240, 145, 55), "enemy": (225, 80, 80),
        "hero": (95, 205, 125), "gold": (245, 205, 70)}

# (ключ, название, описание, категория, группа)
MODS = [
    ("lava", "Пол — лава", "Пол жжёт! Стой на мебели и прыгай", "hazard", None),
    ("low_grav", "Луна", "Гравитация слабая: прыжки огромные", "phys", "gravity"),
    ("high_grav", "Тяжёлая планета", "Гравитация сильная: прыжки низкие", "phys", "gravity"),
    ("swing_grav", "Качели гравитации", "Гравитация то слабая, то сильная", "phys", "gravity"),
    ("ice", "Скользкий лёд", "Не остановиться сразу: всё скользит", "phys", None),
    ("wind", "Ветер", "Сильный ветер толкает всех в сторону", "phys", None),
    ("trampoline", "Батут-пол", "Пол подбрасывает при приземлении", "phys", None),
    ("quake", "Землетрясение", "Земля трясётся и подбрасывает всех", "hazard", None),
    ("conveyor", "Конвейер", "Пол едет, как лента, и везёт всех", "phys", None),
    ("dark", "Тьма", "Видно только вокруг себя", "view", None),
    ("blink", "Мигающий свет", "Свет то гаснет, то включается", "view", None),
    ("acid", "Кислотный дождь", "С неба капает кислота", "hazard", None),
    ("meteors", "Метеориты", "Смотри на тени: сейчас что-то упадёт", "hazard", None),
    ("fast_enemies", "Быстрые враги", "Все враги бегают на 50% быстрее", "enemy", None),
    ("double", "Двойная орда", "Врагов в два раза больше", "enemy", None),
    ("boom", "Взрывные враги", "Упавший враг взрывается", "enemy", None),
    ("jumpy", "Прыгучие враги", "Все враги скачут, как барашки", "enemy", None),
    ("armor", "Броня", "У врагов в два раза больше здоровья", "enemy", None),
    ("ghosts", "Призраки", "Враги то видны, то нет", "enemy", None),
    ("sky", "Враги с неба", "Враги падают прямо сверху", "enemy", None),
    ("poison", "Яд", "После укуса теряешь сердце, пока не съешь пирожок", "enemy", None),
    ("regen", "Регенерация", "Раненые враги лечатся", "enemy", None),
    ("glass", "Стеклянная пушка", "Одно сердце, но удары в два раза сильнее", "hero", None),
    ("vampire", "Вампир", "Пирожки не лечат, лечат победы", "hero", None),
    ("fists", "Только кулаки", "Никакого оружия: только руки", "hero", None),
    ("heavy", "Тяжёлая рука", "Удары в два раза сильнее, но медленнее", "hero", None),
    ("mirror", "Зеркало", "Право и лево перепутаны", "hero", None),
    ("drunk", "Шатает", "Героя качает из стороны в сторону", "hero", None),
    ("fast_time", "Быстрое время", "Всё происходит на 30% быстрее", "phys", None),
    ("greed", "Жадность", "Монет в два раза больше, но враги крепче", "gold", None),
]
KEYS = [m[0] for m in MODS]
BY_KEY = {m[0]: m for m in MODS}
GROUP = {m[0]: m[4] for m in MODS}

COIN_BONUS_PER_MOD = 0.1   # каждый модификатор даёт +10% монет
VAMPIRE_KILLS = 8          # сколько побед лечат на одно сердце
POISON_TIME = 3.2          # через сколько секунд яд отнимет сердце
LAVA_TICK = 0.7            # как часто пол-лава жжёт героя
WORLD_PUSH_WIND = 150      # скорость ветра
BELT_SPEED = 110           # скорость конвейера


def toggle(picked, key):
    """Включить или выключить модификатор в списке. Из одной группы (гравитация) берётся только один."""
    picked = list(picked)
    if key in picked:
        picked.remove(key)
        return picked
    group = GROUP.get(key)
    if group:
        picked = [k for k in picked if GROUP.get(k) != group]
    picked.append(key)
    return picked


def random_pick(n=MIN_PICK, rng=random):
    """n случайных модификаторов (не больше одного из группы)."""
    keys = list(KEYS)
    rng.shuffle(keys)
    out = []
    for k in keys:
        if len(out) >= n:
            break
        if GROUP.get(k) is None or all(GROUP.get(o) != GROUP[k] for o in out):
            out.append(k)
    return out


def coin_mult(keys):
    """Во сколько раз больше монет за выбранный набор."""
    mult = 1.0 + COIN_BONUS_PER_MOD * len(keys)
    return mult * (2 if "greed" in keys else 1)


_DARK = {}


def dark_mask():
    """Тёмный экран с дыркой света в центре (рисуется один раз). Размер вдвое больше экрана, чтобы закрыть края."""
    if "m" not in _DARK:
        m = pygame.Surface((W * 2, H * 2), pygame.SRCALPHA)
        m.fill((4, 6, 16, 238))
        c = (W, H)
        for r in range(240, 0, -6):
            a = int(238 * (r / 240) ** 1.6)
            pygame.draw.circle(m, (4, 6, 16, a), c, r)
        _DARK["m"] = m
    return _DARK["m"]


class Mods:
    """Включённые модификаторы и их события (метеориты, дождь, землетрясения...)."""

    def __init__(self, keys):
        self.keys = [k for k in keys if k in BY_KEY]
        self.on = set(self.keys)
        self.t = 0.0
        self.slide = 0.0            # скольжение на льду
        self.wind = WORLD_PUSH_WIND
        self.wind_t = 0.0
        self.belt = BELT_SPEED
        self.belt_t = 0.0
        self.lava_t = 0.0
        self.quake_t = random.uniform(7, 10)
        self.quake_warn = 0.0
        self.rain_t = 0.0
        self.meteor_t = random.uniform(2, 3)
        self.hz = []                # капли кислоты и метеориты: {"type", "x", "y", "t", "vy"}
        self.poison_t = 0.0
        self.kills = 0              # для вампира
        self.coin_mult = coin_mult(self.keys)

    def has(self, key):
        return key in self.on

    # ---------- числа ----------
    def gravity(self):
        if "low_grav" in self.on:
            return 0.45
        if "high_grav" in self.on:
            return 1.5
        if "swing_grav" in self.on:   # плавно от 0.5 до 1.6 и обратно, круг в 10 секунд
            return 1.05 + 0.55 * math.sin(self.t * math.tau / 10)
        return 1.0

    def time_scale(self):
        return 1.3 if "fast_time" in self.on else 1.0

    def dmg_mult(self):
        return (2 if "glass" in self.on else 1) * (2 if "heavy" in self.on else 1)

    def cd_mult(self):
        return 1.8 if "heavy" in self.on else 1.0

    # ---------- враги ----------
    def tune_enemy(self, z):
        """Подкрутить только что появившегося врага."""
        if "fast_enemies" in self.on:
            z.speed *= 1.5
        if "armor" in self.on:
            z.hp *= 2
        if "greed" in self.on:
            z.hp = math.ceil(z.hp * 1.3)
        if "jumpy" in self.on:
            z.hop = True
        if "sky" in self.on:
            z.y, z.on_ground = -140.0, False
        z.maxhp = z.hp
        z.regen_t = 0.0
        z.lava_t = 0.0
        z.phase = random.random() * 3

    def ghost_hidden(self, z):
        """Призрак сейчас невидим?"""
        return "ghosts" in self.on and (self.t * 1.3 + getattr(z, "phase", 0)) % 2.6 > 1.7

    # ---------- движение героя и врагов ----------
    def hero_vx(self, p, target, dt):
        """Итоговая скорость героя: лёд, шатание, ветер, конвейер."""
        if "ice" in self.on:
            self.slide += (target - self.slide) * (1 - math.exp(-1.5 * dt))
            vx = self.slide
        else:
            vx = target
        if "drunk" in self.on:
            vx += math.sin(self.t * 1.7) * 90 + math.sin(self.t * 0.9 + 1) * 60
        if "wind" in self.on:
            vx += self.wind * (0.7 if p.on_ground else 1.0)
        if "conveyor" in self.on and p.on_ground and p.y + p.h >= FLOOR - 1:
            vx += self.belt
        return vx

    def push(self, z):
        """Сколько пикселей в секунду ветер и конвейер сдвигают врага."""
        v = 0.0
        if "wind" in self.on:
            v += self.wind * 0.6
        if "conveyor" in self.on and z.on_ground and z.y + z.h >= FLOOR - 1:
            v += self.belt
        return v

    def bounce(self, p, vy_pre):
        """Батут-пол: если упал на пол — подбросило. Возвращает новую вертикальную скорость или None."""
        if "trampoline" in self.on and p.on_ground and p.y + p.h >= FLOOR - 1 and vy_pre > 250:
            return -min(vy_pre * 0.85, 1000.0)
        return None

    # ---------- события ----------
    def on_bite(self, g):
        if "poison" in self.on and self.poison_t <= 0:
            self.poison_t = POISON_TIME
            g.msg = ["Яд! Съешь пирожок", 2.0]

    def cure(self):
        self.poison_t = 0.0

    def on_kill(self, g, z):
        p = g.player
        self.kills += 1
        if "vampire" in self.on and self.kills % VAMPIRE_KILLS == 0 and p.hp < p.max_hp:
            p.hp += 1
            g.sparkle(p.x + p.w / 2, p.y + 10, (230, 60, 90))
        if "boom" in self.on:
            cx, cy = z.x + z.w / 2, z.y + z.h / 2
            g.fx.append({"type": "boom", "x": cx, "y": cy, "R": 80, "t": 0.0})
            g.add_shake(4, 0.2)
            g.particles.emit(cx, cy, 14, [(255, 190, 60), (255, 120, 40)], speed=(80, 260), life=(0.2, 0.5),
                             size=(4, 7), grav=200)
            if (p.x + p.w / 2 - cx) ** 2 + (p.y + p.h / 2 - cy) ** 2 <= (80 + p.w / 2) ** 2:
                g.hurt_player(1, cx)
            for o in g.zombies:
                if o is not z and o.hp > 1 and (o.x + o.w / 2 - cx) ** 2 + (o.y + o.h / 2 - cy) ** 2 <= (80 + o.w / 2) ** 2:
                    o.hp -= 1
                    o.flash = 0.12

    def update(self, g, dt):
        p = g.player
        self.t += dt
        on_floor = p.on_ground and p.y + p.h >= FLOOR - 1

        if "wind" in self.on:
            self.wind_t += dt
            if self.wind_t >= 7:
                self.wind_t, self.wind = 0.0, -self.wind
                g.msg = ["Ветер сменился!", 1.5]
        if "conveyor" in self.on:
            self.belt_t += dt
            if self.belt_t >= 10:
                self.belt_t, self.belt = 0.0, -self.belt
                g.msg = ["Конвейер поехал назад!", 1.5]

        if "lava" in self.on:
            if on_floor:
                self.lava_t += dt
                if self.lava_t >= LAVA_TICK:
                    self.lava_t = 0.0
                    if p.hurt_cd <= 0 and p.shield_t <= 0:
                        g.msg = ["Пол — лава!", 1.0]
                    g.hurt_player(1, p.x + p.w / 2 + random.choice((-30, 30)))
            else:
                self.lava_t = 0.0
            for z in g.zombies:
                if z.on_ground and z.y + z.h >= FLOOR - 1:
                    z.lava_t = getattr(z, "lava_t", 0.0) + dt
                    if z.lava_t >= 1.3:
                        z.lava_t = 0.0
                        z.hp -= 1
                        z.flash = 0.12
                else:
                    z.lava_t = 0.0

        if "quake" in self.on:
            if self.quake_warn > 0:
                self.quake_warn -= dt
                g.add_shake(2, 0.1)
                if self.quake_warn <= 0:
                    g.add_shake(9, 0.7)
                    if on_floor or p.on_ground:
                        p.vy, p.on_ground = -640.0, False
                    for z in g.zombies:
                        if z.on_ground:
                            z.vy, z.on_ground = -420.0, False
                            z.stun_t = max(z.stun_t, 1.0)
                    self.quake_t = random.uniform(8, 12)
            else:
                self.quake_t -= dt
                if self.quake_t <= 0:
                    self.quake_warn = 1.2
                    g.msg = ["Землетрясение!", 1.5]

        if "acid" in self.on:
            self.rain_t -= dt
            if self.rain_t <= 0:
                self.rain_t = 0.16
                x = random.uniform(max(0, g.cam - 40), min(g.ww, g.cam + W + 40))
                self.hz.append({"type": "drop", "x": x, "y": -10.0, "vy": random.uniform(520, 700), "t": 0.0})

        if "meteors" in self.on:
            self.meteor_t -= dt
            if self.meteor_t <= 0:
                self.meteor_t = random.uniform(2.2, 3.4)
                x = max(60.0, min(g.ww - 60.0, p.x + random.uniform(-380, 380)))
                self.hz.append({"type": "meteor", "x": x, "y": -80.0, "t": 0.0})

        for h in self.hz:
            h["t"] += dt
            if h["type"] == "drop":
                h["y"] += h["vy"] * dt
                if pygame.Rect(int(h["x"]) - 3, int(h["y"]) - 8, 6, 16).colliderect(p.rect):
                    g.hurt_player(1, h["x"])
                    h["dead"] = True
                elif h["y"] >= FLOOR or any(pl.collidepoint(h["x"], h["y"]) for pl in g.platforms):
                    h["dead"] = True
                    g.particles.emit(h["x"], min(h["y"], FLOOR), 3, [(130, 230, 80)], speed=(30, 90),
                                     life=(0.15, 0.3), size=(2, 3), grav=300)
            else:  # метеорит: сначала тень на полу, потом падает и взрывается
                if h["t"] < 1.1:
                    h["y"] = -80.0
                else:
                    h["y"] = -80.0 + (h["t"] - 1.1) / 0.3 * (FLOOR - 20 + 80)
                    if h["t"] >= 1.4:
                        h["dead"] = True
                        self.meteor_boom(g, h["x"])
        self.hz = [h for h in self.hz if not h.get("dead")]

        if self.poison_t > 0:
            self.poison_t -= dt
            if self.poison_t <= 0:
                p.hp -= 1
                g.on_player_hurt(1)
                g.msg = ["Яд подействовал!", 1.5]

        if "regen" in self.on:
            for z in g.zombies:
                if z.hp < getattr(z, "maxhp", z.hp):
                    z.regen_t = getattr(z, "regen_t", 0.0) + dt
                    if z.regen_t >= 3.5:
                        z.regen_t, z.hp = 0.0, z.hp + 1

    def meteor_boom(self, g, x):
        p = g.player
        y = FLOOR - 20
        g.fx.append({"type": "boom", "x": x, "y": y, "R": 90, "t": 0.0})
        g.add_shake(7, 0.3)
        g.particles.emit(x, y, 24, [(255, 190, 60), (255, 120, 40), (255, 240, 160)], speed=(80, 330),
                         life=(0.25, 0.6), size=(4, 8), grav=200)
        if (p.x + p.w / 2 - x) ** 2 + (p.y + p.h / 2 - y) ** 2 <= (90 + p.w / 2) ** 2:
            g.hurt_player(1, x)
        for z in g.zombies:
            if (z.x + z.w / 2 - x) ** 2 + (z.y + z.h / 2 - y) ** 2 <= (90 + z.w / 2) ** 2:
                z.hp -= 3
                z.flash = 0.15

    # ---------- рисование ----------
    def draw_back(self, g, s):
        """Под героем и врагами: лава и конвейер."""
        cam = g.cam
        tick = pygame.time.get_ticks() / 1000
        if "lava" in self.on:
            strip = pygame.Rect(cam, FLOOR - 6, W, H - FLOOR + 6)
            pygame.draw.rect(s, (150, 30, 20), strip)
            for x in range(int(cam) // 24 * 24, int(cam) + W + 24, 24):
                h = 8 + int(5 * math.sin(tick * 3 + x * 0.05))
                pygame.draw.rect(s, (255, 130, 30), (x, FLOOR - 6 - h + 6, 24, h))
                pygame.draw.rect(s, (255, 215, 80), (x + 6, FLOOR - h + 4, 10, 4))
            pygame.draw.rect(s, INK, (cam, FLOOR - 8, W, 3))
        if "conveyor" in self.on:
            d = 1 if self.belt > 0 else -1
            for x in range(int(cam) // 40 * 40, int(cam) + W + 40, 40):
                px = x + int(tick * self.belt * 0.5) % 40
                pygame.draw.polygon(s, (60, 60, 70), [(px, FLOOR + 10), (px + 14 * d, FLOOR + 18), (px, FLOOR + 26)])

    def draw_front(self, g, s):
        """Над героем: капли кислоты, тени и огонь метеоритов."""
        tick = pygame.time.get_ticks() / 1000
        for h in self.hz:
            if h["type"] == "drop":
                pygame.draw.rect(s, (60, 140, 40), (int(h["x"]) - 3, int(h["y"]) - 9, 6, 18))
                pygame.draw.rect(s, (150, 240, 90), (int(h["x"]) - 2, int(h["y"]) - 8, 4, 14))
            else:
                x = int(h["x"])
                if h["t"] < 1.1:   # предупреждение: красный кружок на полу
                    k = h["t"] / 1.1
                    r = int(30 + 40 * k)
                    shadow = pygame.Surface((r * 2, 20), pygame.SRCALPHA)
                    pygame.draw.ellipse(shadow, (230, 40, 30, int(70 + 120 * k)), shadow.get_rect())
                    s.blit(shadow, (x - r, FLOOR - 8))
                    if int(tick * 8) % 2:
                        pygame.draw.rect(s, (255, 230, 90), (x - 3, FLOOR - 40, 6, 14))
                else:
                    y = int(h["y"])
                    pygame.draw.circle(s, INK, (x, y), 24)
                    pygame.draw.circle(s, (255, 130, 30), (x, y), 20)
                    pygame.draw.circle(s, (255, 230, 100), (x - 4, y + 4), 10)
                    pygame.draw.rect(s, (255, 150, 40), (x - 8, y - 70, 16, 46))

    def draw_screen(self, g, s):
        """Поверх экрана: тьма, мигание, ветер, яд."""
        p = g.player
        tick = pygame.time.get_ticks() / 1000
        if "dark" in self.on:
            m = dark_mask()
            s.blit(m, (int(p.x + p.w / 2 - g.cam) - W, int(p.y + p.h / 2) - H))
        if "blink" in self.on:
            phase = self.t % 4.5
            if phase > 3.5:
                a = 235 if (phase < 3.75 or phase > 4.1 or int(phase * 20) % 2) else 90
                dark = pygame.Surface((W, H), pygame.SRCALPHA)
                dark.fill((4, 6, 16, a))
                s.blit(dark, (0, 0))
        if "wind" in self.on:
            d = 1 if self.wind > 0 else -1
            for i in range(14):
                y = (i * 71) % (H - 60) + 40
                x = int((tick * self.wind * 3 + i * 197) % (W + 120)) - 60
                if d < 0:
                    x = W - x
                pygame.draw.line(s, (235, 240, 255), (x, y), (x + 34 * d, y), 2)
        if self.poison_t > 0:
            tint = pygame.Surface((W, H), pygame.SRCALPHA)
            tint.fill((70, 200, 60, 38))
            s.blit(tint, (0, 0))
