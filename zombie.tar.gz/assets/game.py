"""Зомби-школа — этажи-комнаты для одного игрока.

Управление:
  A/D или стрелки — ходить
  Shift — бежать
  W / пробел / стрелка вверх — прыжок
  J или ЛКМ — ударить
  E — взять оружие с пола (старое останется лежать)
  R — заново
  B — сразу к боссу (проверить бой, не проходя классы)
Оружие бывает разное: бить, стрелять, кидать, щит, звонок. Список — в weapons.py.
M — карта школы (выбрать другую комнату)
Катсцены: Enter / клик — дальше, Esc — пропустить
Запуск сразу на боссе: python game.py --boss
Сразу «ты против школы» (круг 2, у босса 50%): python game.py --school
Сразу финал со школой: python game.py --final
Сразу мини-босс (три хулигана в одном теле): python game.py --mini
Сразу бесконечный режим (последние модификаторы или случайные 5): python game.py --endless
Сразу босс поезда (зомби-машинист): python game.py --driver
Режим показа (игра сама показывает себя, Esc — выйти): python game.py --demo
Режим проверки оружия: python game.py --test  (Q — следующее оружие, здоровье не кончается)
Пирожки подбираются сами (лечат на 1 сердце, если ты ранен).
Карта: Туалет (бонус), Классы 1-7 по порядку, потом Кабинет директора — босс, потом ФИНАЛ со школой.
В бою с боссом раз в 3 секунды 30% шанс, что тебе прилетит водяной пистолет (подбери на E).
"""
import asyncio
import math
import random
import sys

import pygame

import classes
import demo as demo_mode
import endless
import i18n
import prefs
import quests
import sound
import story_map
from market import ORDER2, ROOM2_BY_ID, Store, draw_map2, lock_reason as lock_reason2, move_selection as move_selection2, \
    room_at as room_at2, status_of as status2
from cutscenes import SCENES
from effects import (Particles, draw_motes, draw_shadow, ground_below, make_motes, make_overlay,
                     red_vignette)
from train import Train
from menu import Menu, apply_prefs
from modifiers import Mods
from pixelfont import pixel_font
from rooms import CLASS_WALLS, THEMES, draw_furniture, random_class_layout
from rooms3 import KINDS3, MARKET_KINDS, draw_furniture3
from rooms_train import KINDS_TRAIN, TRAIN_KINDS, ROOM_TRAIN_BY_ID, draw_furniture_train
from school_map import ROOM_BY_ID, draw_map, move_selection, room_at, MAP_ROOMS, ORDER
from settings import FLOOR, H, INK, W
from sprites import SpriteSet
from touch import MENU_OVER_RECT, MergedKeys, RESTART_RECT, SKIP_RECT, touch
from weapons import CLUB, FISTS, KICK, WEAPONS

GRAVITY = 2200
JUMP = -850
FPS = 60
WALK_SPEED = 220
RUN_SPEED = 360  # держи Shift
STEP_WALK = 30   # сколько пикселей пути — один кадр ходьбы
STEP_RUN = 40
CORPSE_TIME = 1.0  # сколько секунд лежит упавший зомби, пока не исчезнет
SPRITE_PAD = 4  # спрайт героя шире хитбокса на одну клетку слева и справа

ROUND_ZOMBIES = 3      # на сколько зомби больше в каждом следующем круге
ROUND_BOSS_HP = 20     # на сколько здоровья у босса больше в каждом круге
WATER_EVERY = 3.0      # раз в столько секунд в бою с боссом тебе может достаться водяной пистолет
WATER_CHANCE = 0.3     # ...с таким шансом (30%)
FINAL_HP = 30          # здоровье школы-колокола в финале
MENU_BTN = pygame.Rect(8, 8, 150, 42)   # кнопка «Меню» на карте школы
EASY_HP = 0.6          # на телефоне (кнопки на экране) боссы проще: здоровья меньше
EASY_SPEED = 0.75      # ...и двигаются/атакуют медленнее
MINI_HP = 36           # мини-босс (Борян+Толян+Колян): по 12 на каждую голову
MINI_HP_ROUND = 9      # на сколько больше в каждом следующем круге
FINAL_HP_ROUND = 15    # на сколько больше в каждом следующем круге
SCHOOL_TIME = 18.0     # сколько секунд «ты против школы» (со 2-го круга, когда у босса 50% здоровья)
SCHOOL_PIE_EVERY = 4.0  # пирожки из столовой в это время летят чаще
TYPE_SPEED = 45        # букв в секунду в катсценах
SPEAKERS = {"Ты": (150, 200, 255), "Директор": (255, 215, 90), "Зомби": (140, 220, 140),
            "Школа": (255, 110, 110), "Дневник": (232, 205, 150), "Повариха": (255, 175, 120),
            "Борян": (235, 110, 110), "Толян": (110, 200, 120), "Колян": (170, 170, 190),
            "Девочка": (245, 160, 205), "Работник магазина": (255, 160, 70), "Громкоговоритель": (190, 200, 230),
            "Королева": (140, 230, 90), "Диктор": (150, 190, 255), "Консьерж": (110, 160, 235), "Проводница": (255, 175, 120),
            "Машинист": (240, 150, 70), "Бабушка": (200, 160, 220), "Динамик": (190, 200, 230)}
BOSS_HP = 40
_NIGHT = {}   # ночные затемнения комнат главы 2 (рисуются один раз)
BOSS_PIE_EVERY = 9.0   # как часто из столовой прилетает пирожок во время боя
PIE_DROP_CHANCE = 0.2  # шанс, что из зомби выпадет пирожок
ZOMBIE_SLOW = 0.4      # во сколько раз замедлен зомби (пена, огнетушитель)


class Player:
    def __init__(self):
        self.x, self.y = 100.0, FLOOR - 60
        self.vx = self.vy = 0.0
        self.w, self.h = 40, 60
        self.face = 1
        self.hp = 5
        self.max_hp = 5       # у Ботана 7
        self.speed_mult = 1.0  # у Приколиста 1.2, у Ботана 0.7
        self.two_slots = False  # у Приколиста два места под оружие
        self.kick = False       # Тхэквондист: кулаки бьют ногой (сильнее и отбрасывают)
        self.uses_mult = 1.0    # Тхэквондист: оружие кончается быстрее (0.6)
        self.double_jump = False  # Геймер: второй прыжок в воздухе
        self.cd_mult = 1.0      # Геймер: быстрее удары (0.7)
        self.air_jumps = 0      # сколько ещё прыжков в воздухе осталось
        self.prev_jump = False  # была ли кнопка прыжка нажата в прошлом кадре
        self.alt = (FISTS, None)  # второе место (оружие, заряды): меняется кнопкой Q
        self.on_ground = False
        self.weapon = FISTS
        self.kick_w = KICK     # удар ногой Тхэквондиста (на высоких уровнях сильнее)
        # умения классов (см. classes.PERKS): заполняет Game.apply_class
        self.coin_mult, self.pie_bonus, self.kill_pie, self.stumble = 1.0, 0.0, 0, 0.0
        self.focus, self.hurt_mult, self.pie_heal, self.kick_both = False, 1.0, 1, False
        self.whirl, self.combo, self.revive = False, False, False
        self.dmg_mult, self.rage = 1.0, False   # урон всех ударов; «Ярость»: на последнем сердце урон вдвое
        self.attack_cd = 0.0
        self.swing = 0.0
        self.hurt_cd = 0.0
        self.anim = 0.0  # сколько пикселей прошёл — по нему листаем кадры
        self.running = False
        self.uses = None      # сколько раз ещё можно использовать оружие (None — сколько угодно)
        self.shield_t = 0.0   # пока больше 0 — щит поднят

    @property
    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    def eff(self):
        """Чем бьём на самом деле: у Тхэквондиста вместо кулаков удар ногой."""
        return self.kick_w if (self.kick and self.weapon is FISTS) else self.weapon

    def attack_rect(self):
        reach = self.eff()["reach"]
        if self.face > 0:
            return pygame.Rect(int(self.x + self.w), int(self.y + 10), reach, 40)
        return pygame.Rect(int(self.x - reach), int(self.y + 10), reach, 40)


# Враги: обычный зомби и мутанты мегамаркета (глава 2). hop — прыгает, dmg — сколько сердец отнимает укус
ZOMBIE_KINDS = {
    "zombie": {"hp": 3, "speed": (60, 100), "w": 38, "h": 56, "dmg": 1},
    "worm": {"hp": 2, "speed": (105, 140), "w": 42, "h": 26, "dmg": 1},
    "chicken": {"hp": 2, "speed": (150, 190), "w": 34, "h": 38, "dmg": 1, "hop": True},
    "cow": {"hp": 9, "speed": (36, 48), "w": 72, "h": 56, "dmg": 2},
    "lamb": {"hp": 4, "speed": (90, 115), "w": 46, "h": 44, "dmg": 1, "hop": True},
    "mimic": {"hp": 5, "speed": (80, 95), "w": 46, "h": 46, "dmg": 2},
    "runner": {"hp": 2, "speed": (125, 165), "w": 38, "h": 56, "dmg": 1},   # быстрый заражённый (глава 3)
}


class Zombie:
    def __init__(self, x, kind="zombie"):
        st = ZOMBIE_KINDS[kind]
        self.kind = kind
        self.w, self.h = st["w"], st["h"]
        self.x, self.y = float(x), float(FLOOR - self.h)
        self.hp = st["hp"]
        self.speed = random.uniform(*st["speed"])
        self.dmg = st["dmg"]
        self.hop = st.get("hop", False)
        self.hop_t = random.uniform(0.5, 2.0)
        self.vy = 0.0
        self.on_ground = True
        self.face = -1
        self.bite_cd = 0.0
        self.flash = 0.0
        self.anim = 0.0  # сколько прошёл — по нему листаем кадры шарканья
        self.stun_t = 0.0   # оглушён (стоит, звёздочки)
        self.slow_t = 0.0   # замедлен
        self.dot_t = 0.0    # горит/плавится: 1 урон каждые 0.5 сек
        self.dot_acc = 0.0

    @property
    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)


class Boss:
    """Директор-зомби. Состояния: walk -> (throw | windup -> charge -> tired) -> walk. dying — падает."""

    def __init__(self, x, hp=BOSS_HP, kind="boss"):
        self.kind = kind       # "boss" — директор, "queen" — королева червей (глава 2)
        self.w, self.h = (110, 88) if kind == "queen" else (60, 84)
        self.x, self.y = float(x), float(FLOOR - self.h)
        self.maxhp = self.hp = hp
        self.face = -1
        self.state = "walk"
        self.t = 0.0           # сколько времени в текущем состоянии
        self.speed = 70
        self.dir = -1          # куда несётся при таране
        self.throw_cd = 2.0
        self.charge_cd = 5.0
        self.bite_cd = 0.0
        self.flash = 0.0
        self.anim = 0.0
        self.phase2 = False    # меньше половины здоровья — злее
        self.school_done = kind != "boss"  # «ты против школы» уже было (у королевы и консьержа его нет)
        self.stun_t = 0.0   # оглушён (стоит, звёздочки)
        self.slow_t = 0.0   # замедлен
        self.dot_t = 0.0    # горит/плавится: 1 урон каждые 0.5 сек
        self.dot_acc = 0.0

    @property
    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    def set_state(self, name):
        self.state, self.t = name, 0.0


class MiniBoss:
    """Борян, Толян и Колян слились в одно тело с колоколом на макушке.
    Три головы = три «жизни» и три атаки: рывок (Борян), монеты (Толян), топот (Колян).
    Когда голова вырубается, колокол звякает, и её атака пропадает. Первым вырубается Колян.
    """

    def __init__(self, x, hp):
        self.w, self.h = 90, 100
        self.x, self.y = float(x), float(FLOOR - 100)
        self.maxhp = self.hp = hp
        self.heads = 3
        self.face = -1
        self.state = "walk"  # walk -> w_charge|w_coins|w_stomp -> charge|walk -> tired -> walk; dying
        self.t = 0.0
        self.dir = -1
        self.attack_cd = 2.5
        self.n = 0  # какая по счёту атака
        self.speed = 55
        self.bite_cd = 0.0
        self.flash = 0.0
        self.anim = 0.0
        self.stun_t = self.slow_t = self.dot_t = self.dot_acc = 0.0

    @property
    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    def set_state(self, name):
        self.state, self.t = name, 0.0


class SchoolBoss:
    """Финал: школа — огромный рот. Слабое место — колокол.
    hang (висит, летят парты) -> drop (падает) -> vuln (на полу, бей!) -> rise (поднимается) -> hang ...
    """

    def __init__(self, hp):
        self.maxhp = self.hp = hp
        self.w = self.h = 64
        self.x, self.y = W / 2 - 32, 140.0
        self.state = "hang"
        self.t = 0.0
        self.flash = 0.0
        self.enraged = False
        self.stun_t = self.slow_t = self.dot_t = self.dot_acc = 0.0  # чтобы работали общие эффекты
        self.sc = {"t": 0.0, "drop_cd": 1.5, "slide_cd": 3.0, "pie_t": 0.0, "hazards": []}

    @property
    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)


def info_of(rid):
    """Описание комнаты: из карты школы (глава 1) или из главы 2."""
    return ROOM_BY_ID.get(rid) or ROOM2_BY_ID.get(rid) or ROOM_TRAIN_BY_ID[rid]


def draw_furn(s, rect, kind):
    if kind in KINDS3:
        draw_furniture3(s, rect, kind)
    elif kind in KINDS_TRAIN:
        draw_furniture_train(s, rect, kind)
    else:
        draw_furniture(s, rect, kind)


# какая сцена показывается при входе в вагон на карте главы 3 (по ним «once» играет только один раз)
STORY_SCENES = {
    3: {"seats": "t_intro", "cafe": "t_cafe_in", "sleeper": "t_sleeper_in", "luggage": "t_luggage_in", "cab": "t_driver"},
}


def easy_on():
    """Лёгкие боссы: по настройке; в режиме «Авто» — когда играешь с экранными кнопками (на телефоне)."""
    mode = prefs.get("easy")
    return mode == "on" or (mode == "auto" and touch.enabled)


class Game:
    def __init__(self):
        self.player = Player()
        self.state = "map"       # map — карта школы, play — бой, cutscene — катсцена, win — победа
        self.cleared = set()     # какие комнаты зачищены
        self.round = 1           # после победы над директором — новый круг, сложнее
        self.current = None      # id комнаты, где идёт бой
        self.selected = "c1"     # что выбрано на карте
        self.map_msg = None      # [текст, секунд] — например «Закрыто»
        self.cutscenes = True
        self.seen_scenes = set()
        self.cut = None          # идущая катсцена
        self.room = THEMES["class"]
        self.variant = 0
        self.furniture = []
        self.platforms = []
        self.zombies = []
        self.corpses = []  # падающие зомби (только для красоты)
        self.boss = None
        self.projectiles = []  # двойки, которыми кидается босс
        self.shots = []        # снаряды героя: пульки, мел, учебники...
        self.fx = []           # взрывы и волны от звонка
        self.school = None     # «ты против школы»: {t, drop_cd, slide_cd, pie_t, hazards}
        self.final = None      # финальный босс — школа (SchoolBoss)
        self.mini = None       # мини-босс в Классе 7 (MiniBoss)
        self.has_key = False   # ключ от кабинета директора (выпадает из мини-босса)
        self.key_hint = False  # подсказку про ключ показываем один раз
        self.particles = Particles()   # искры, пыль, блёстки
        self.shake = [0.0, 0.0, 1.0]   # тряска экрана: сила, сколько осталось, на сколько секунд
        self.hurt_flash = 0.0          # красная вспышка по краям, когда больно
        self.overlay = None            # лучи света и виньетка для этой комнаты
        self.motes = []                # пылинки в лучах
        self.cut_motes = {}
        self.run_dust_t = 0.0
        self.water_t = 0.0     # таймер водяного пистолета (для тебя)
        self.msg = None        # [текст, секунд осталось]
        self.pie_timer = 0.0
        self.test_mode = False  # python game.py --test
        self.pickups = []  # лут: {"kind": "pie"|"club"|..., "rect": Rect}
        self.door_open = False
        self.over = False
        self.chapter = 1          # какая глава идёт: 1 (школа) или 2 («Мегамаркет»)
        self.mk = None            # события отдела в главе 2 (market.Store)
        self.decoy = None         # игрушка пони, которая отвлекает врагов: {"x", "dir", "t", "anim"}
        self.train = None            # сюжет текущего вагона главы 3 (train.Train)
        self.started = False      # началась ли игра (для «Продолжить» в меню)
        self.menu = Menu(self)
        self.menu_prev = "map"    # куда вернуться из меню
        self.room_snapshot = None  # что было у героя при входе в комнату (для «комната заново»)
        self.sprites = None  # создаётся при первой отрисовке
        self.run_coins = 0        # сколько монет заработано в этой игре
        self.demo_request = False   # в меню нажали P: надо включить показ
        self.focus_used = False   # «Фокус» Приколиста уже сработал в этой комнате
        self.revive_used = False  # «Продолжить?» Геймера уже использовано в этой игре
        self.kill_total = 0       # сколько врагов убито (для «каждый 10-й роняет пирожок»)
        self.streak, self.streak_t = 0, 0.0   # серия убийств подряд (Геймер)
        self.toast = None         # [текст, секунд]: «Квест выполнен!» (показывается и на карте)
        self.room_hurt = False    # получал ли герой урон в этой комнате (для квеста «без урона»)
        self.endless = None       # бесконечный режим (endless.Endless), если он идёт
        self.mods = None          # модификаторы бесконечного режима (modifiers.Mods)
        self.ww = W               # ширина мира: в обычных комнатах экран, в бесконечном режиме арена в 3 экрана
        self.cam = 0.0            # левый край камеры в мире
        self.arena_bg = None
        self.world = None         # широкая картинка, на которую рисуется арена
        self.apply_class()

    def apply_class(self):
        """Выбранный класс: сердца, скорость, второе место под оружие и стартовое оружие."""
        c = classes.effects(classes.current_key())   # числа класса и улучшения его уровня
        p = self.player
        p.max_hp = p.hp = c["hp"]
        p.speed_mult = c["speed"]
        p.two_slots = c["slots"] == 2
        p.kick = c.get("kick", False)
        p.uses_mult = c.get("uses_mult", 1.0)
        p.double_jump = c.get("double_jump", False)
        p.cd_mult = c.get("cd_mult", 1.0)
        p.coin_mult, p.pie_bonus, p.kill_pie = c.get("coin_mult", 1.0), c.get("pie_bonus", 0.0), c.get("kill_pie", 0)
        p.stumble, p.focus, p.hurt_mult = c.get("stumble", 0.0), c.get("focus", False), c.get("hurt_mult", 1.0)
        p.pie_heal, p.kick_both, p.whirl = c.get("pie_heal", 1), c.get("kick_both", False), c.get("whirl", False)
        p.combo, p.revive = c.get("combo", False), c.get("revive", False)
        p.dmg_mult, p.rage = c.get("dmg_mult", 1.0), c.get("rage", False)
        p.kick_w = dict(KICK, dmg=c.get("kick_dmg", KICK["dmg"]))
        p.alt = (FISTS, None)
        self.class_uses = c.get("weapon_uses")   # сколько зарядов у классового оружия (None — как в таблице)
        if c["weapon"]:
            w = WEAPONS[c["weapon"]]
            p.weapon, p.uses = w, self.class_uses or w["uses"]
        self.class_weapon = c["weapon"]

    def earn(self, n):
        """Монеты (на диск сохраняются позже). В бесконечном режиме их больше за каждый модификатор."""
        mult = self.player.coin_mult * (self.mods.coin_mult if self.mods is not None else 1.0)
        if mult != 1.0:   # монет больше: у класса (уровни), у бесконечного режима (модификаторы)
            x = n * mult
            n = int(x) + (random.random() < x - int(x))
        classes.add_coins(n)
        self.run_coins += n
        if n > 0:
            self.quest("coins", n)

    def quest(self, event, n=1, **kw):
        """Что-то случилось: засчитываем в квесты дня и показываем, если квест выполнен."""
        done, bonus = quests.progress(event, n, **kw)
        if bonus:
            self.toast = [f"Все квесты дня! +{quests.ALL_BONUS} монет", 4.0]
        elif done:
            self.toast = [f"Квест выполнен! +{quests.reward(done[-1])} монет", 3.5]

    def give_weapon(self, w, uses=None):
        """Положить оружие туда, где есть место (в начале игры)."""
        p = self.player
        if p.weapon is FISTS or not p.two_slots:
            p.weapon, p.uses = w, uses
        elif p.alt[0] is FISTS:
            p.alt = (w, uses)

    def scaled_uses(self, item):
        """Сколько зарядов у подобранного оружия (Тхэквондисту — на 40% меньше, но выброшенное им не урезается снова)."""
        uses = item["uses"]
        if uses is None or item.get("own"):
            return uses
        return max(1, round(uses * self.player.uses_mult))

    def swap_weapon(self):
        """Q: поменять оружие в руках и во втором месте (только у Приколиста)."""
        p = self.player
        if not p.two_slots or self.over or self.state != "play":
            return
        (w, u), (w2, u2) = (p.weapon, p.uses), p.alt
        p.weapon, p.uses, p.alt = w2, u2, (w, u)
        self.msg = [f"Оружие: {p.weapon['name']}", 1.0]

    def refill_class_weapon(self):
        """Классовое оружие (пистолет Приколиста) в каждой новой комнате снова полное."""
        p = self.player
        if not self.class_weapon:
            return
        w = WEAPONS[self.class_weapon]
        full = self.class_uses or w["uses"]
        if p.weapon is w:
            p.uses = full
        elif p.alt[0] is w:
            p.alt = (w, full)
        elif p.weapon is FISTS:
            p.weapon, p.uses = w, full
        elif p.two_slots and p.alt[0] is FISTS:
            p.alt = (w, full)

    def begin(self):
        """Начало игры: вступительная катсцена, потом карта."""
        self.started = True
        if self.chapter == 2:
            self.selected = "produce"
            self.play_scene("m_intro", ("map",))
        elif self.chapter == 3:
            self.selected = "seats"
            self.play_scene("t_intro", ("map",))
        else:
            self.play_scene("intro", ("map",))

    # ---------- меню и режимы ----------
    def show_menu(self):
        prefs.save()
        in_progress = self.started and not self.over and self.state in ("map", "play")
        if in_progress:
            self.menu_prev = self.state
        self.menu.open(in_progress)
        self.state = "menu"

    def menu_continue(self):
        self.state = self.menu_prev

    def new_game(self, chapter=1):
        self.restart(chapter=chapter)

    # ---------- бесконечный режим ----------
    def start_endless(self, keys):
        """Большая арена, волны врагов без конца и выбранные модификаторы."""
        sprites, test, cuts = self.sprites, self.test_mode, self.cutscenes
        self.__init__()
        self.sprites, self.test_mode, self.cutscenes = sprites, test, cuts
        self.started = True
        self.mods = Mods(keys)
        self.endless = endless.Endless(prefs.get("endless_best"))
        self.ww = endless.ARENA_W
        self.furniture, self.arena_bg = endless.build_arena()
        self.platforms = [rect for rect, _ in self.furniture]
        self.state, self.current = "play", "endless"
        p = self.player
        p.x, p.y = self.ww / 2 - p.w / 2, float(FLOOR - p.h)
        self.cam = self.ww / 2 - W / 2
        if self.mods.has("glass"):
            p.max_hp = p.hp = 1
        if self.mods.has("fists"):
            p.weapon, p.uses, p.alt, self.class_weapon = FISTS, None, (FISTS, None), None
        # первые находки: пирожки и немного оружия на мебели
        spots = [(r.centerx, r.top) for r in self.platforms]
        random.shuffle(spots)
        for cx, top in spots[:12]:
            kind = endless.random_loot(self.mods)
            if kind:
                self.add_loot(kind, cx, top)
        self.msg = ["Бесконечный режим", 2.0]

    def spawn_endless_enemy(self, kind, wave):
        z = Zombie(endless.spawn_x(self), kind)
        z.speed *= endless.speed_scale(wave)
        z.hp += endless.extra_hp(wave)
        self.mods.tune_enemy(z)
        self.zombies.append(z)

    def spawn_endless_boss(self, k):
        """k-й босс: нечётные — директор, чётные — королева червей. С каждым разом здоровья больше."""
        p = self.player
        queen = k % 2 == 0
        hp = BOSS_HP + 15 * (k - 1)
        x = p.x + (640 if p.x < self.ww / 2 else -640)
        x = max(20.0, min(self.ww - 140.0, x))
        self.boss = Boss(x, self.easy_hp(hp * 3 // 2 if queen else hp), "queen" if queen else "boss")

    def helper_x(self, b):
        """Где появляются помощники босса."""
        if self.endless is None:
            return random.choice((60, 120, 820))
        return max(20, min(self.ww - 90, int(b.x) + random.randint(-300, 300)))

    def finish_endless(self):
        """Герой погиб: запоминаем рекорд."""
        e = self.endless
        self.quest("run")
        if e.wave > prefs.get("endless_best"):
            prefs.set("endless_best", e.wave)

    def retry(self):
        """R, Enter или кнопка после поражения. Обычный режим: эта комната заново. Хардкор: вся игра сначала."""
        if self.endless is not None:   # бесконечный режим: заново с теми же модификаторами
            self.start_endless(self.mods.keys)
            return
        snap = self.room_snapshot
        if prefs.get("mode") == "hardcore" or self.current is None or self.state != "play" or snap is None:
            self.restart()
            return
        p = self.player
        p.weapon, p.uses = snap["weapon"], snap["uses"]
        p.alt = snap.get("alt", (FISTS, None))
        self.has_key = snap["has_key"]
        p.hp, p.hurt_cd, p.attack_cd, p.swing, p.shield_t = p.max_hp, 0.0, 0.0, 0.0, 0.0
        self.over = False
        self.start_room(self.current)

    # ---------- карта школы ----------
    def room_status(self, rid):
        """done — зачищена, open — можно идти, locked — закрыта."""
        if rid in self.cleared:
            return "done"
        if self.chapter == 3:
            return story_map.status_of(self.chapter, rid, self.cleared)
        if self.chapter == 2:
            return status2(rid, self.cleared)
        if rid == "office":
            ok = self.has_key and all(f"c{k}" in self.cleared for k in range(1, 8))
        elif rid == "school":
            ok = "office" in self.cleared
        elif rid == "canteen":
            ok = "c3" in self.cleared
        elif rid == "gym":
            ok = "c5" in self.cleared
        elif rid.startswith("c") and rid != "c1" and rid[1:].isdigit():
            ok = f"c{int(rid[1:]) - 1}" in self.cleared
        else:
            ok = True
        return "open" if ok else "locked"

    def lock_reason(self, rid):
        if self.chapter == 3:
            return f"Закрыто: сначала пройди «{story_map.lock_name(self.chapter, rid)}»"
        if self.chapter == 2:
            return lock_reason2(rid)
        if rid == "canteen":
            return "Закрыто: сначала зачисти Класс 3"
        if rid == "gym":
            return "Закрыто: сначала зачисти Класс 5"
        if rid == "school":
            return "Закрыто: сначала победи директора"
        if rid == "office":
            if all(f"c{k}" in self.cleared for k in range(1, 8)):
                return "Закрыто: нужен ключ от кабинета"
            return "Закрыто: сначала зачисти все 7 классов, ключ лежит в Классе 7"
        return f"Закрыто: сначала зачисти Класс {int(rid[1:]) - 1}"

    def enter_room(self, rid):
        status = self.room_status(rid)
        if status == "locked":
            self.map_msg = [self.lock_reason(rid), 2.5]
        elif status == "done":
            self.map_msg = ["Здесь уже всё зачищено", 2.0]
        else:
            kind = info_of(rid)["kind"]
            scene = STORY_SCENES[self.chapter][rid] if self.chapter == 3 else "m_" + rid if self.chapter == 2 else {"toilet": "toilet", "office": "boss_intro", "final": "school_awakens",
                     "canteen": "canteen", "gym": "gym"}.get(kind, rid)
            self.play_scene(scene, ("room", rid))

    def map_click(self, pos):
        rid = self.room_under(pos)
        if rid:
            self.selected = rid
            self.enter_room(rid)

    def room_under(self, pos):
        """Какая комната под мышкой на карте этой главы."""
        if self.chapter == 3:
            return story_map.room_at(self.chapter, pos)
        return room_at2(pos) if self.chapter == 2 else room_at(pos)

    def map_hover(self, pos):
        rid = self.room_under(pos)
        if rid:
            self.selected = rid

    def map_key(self, key):
        if key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            self.enter_room(self.selected)
        elif self.chapter == 3:
            self.selected = story_map.move_selection(self.chapter, self.selected, key)
        else:
            self.selected = (move_selection2 if self.chapter == 2 else move_selection)(self.selected, key)

    def open_map(self):
        if self.state == "play" and not self.over and self.endless is None:   # у арены карты нет
            self.state = "map"

    def next_open_room(self):
        for rid in (story_map.CFG[self.chapter]["order"] if self.chapter == 3 else ORDER2 if self.chapter == 2
                    else ORDER):
            if self.room_status(rid) == "open":
                return rid
        return self.selected

    def finish_room(self):
        """Комната зачищена: отдых (+2 сердца), назад на карту."""
        self.quest("room")
        if not self.room_hurt:
            self.quest("nohit")
        p = self.player
        p.hp = min(p.max_hp, p.hp + 2)
        self.cleared.add(self.current)
        reward = classes.COIN_BOSS_ROOM.get(self.current, classes.COIN_ROOM)
        self.earn(reward)
        prefs.save()
        self.map_msg = [f"+{reward} монет за комнату", 3.0]
        if self.chapter == 3:
            self.finish_story()
            return
        if self.chapter == 2:
            if self.current == "warehouse":  # королева червей побеждена: конец главы
                self.play_scene("m_end", ("win",))
                return
            self.state = "map"
            self.selected = self.next_open_room()
            return
        if self.current == "canteen":  # повариха накормила
            p.hp = p.max_hp
            self.map_msg = ["Повариха накормила тебя: здоровье полное!", 3.5]
        if self.current == "office":  # директор повержен — просыпается школа
            self.play_scene("school_awakens", ("room", "school"))
            return
        self.state = "map"
        self.selected = self.next_open_room()
        if self.room_status("office") == "open":
            self.play_scene("office_unlock", ("map",))

    def finish_story(self):
        """Главы 3 и 4: вагон или комната пройдены. Назад на карту, а за последней идёт концовка."""
        order = story_map.CFG[self.chapter]["order"]
        self.train = None
        if self.current == order[-1]:
            self.play_scene("t_end", ("win",))
            return
        self.state = "map"
        self.selected = self.next_open_room()

    def next_round(self):
        if self.chapter in (2, 3):  # глава 2 пройдена: назад в меню
            self.show_menu()
            return
        """После победы: все комнаты снова закрыты, зомби и босс сильнее."""
        self.round += 1
        self.cleared = set()
        self.has_key = False
        self.player.hp = self.player.max_hp
        self.selected = "c1"
        self.state = "map"

    # ---------- катсцены ----------
    def play_scene(self, name, then):
        scene = SCENES.get(name)
        if not self.cutscenes or scene is None or (scene.get("once", True) and name in self.seen_scenes):
            self.after_scene(then)
            return
        self.seen_scenes.add(name)
        self.cut = {"scene": scene, "i": 0, "t": 0.0, "then": then, "actors": []}
        self.state = "cutscene"
        self.begin_beat()

    def talk_sound(self, dt):
        """Время катсцены идёт, буквы печатаются: на каждую новую букву говорящий «пикает»."""
        cut = self.cut
        before = int(cut["t"] * TYPE_SPEED)
        cut["t"] += dt
        beat = cut["scene"]["beats"][cut["i"]]
        text = i18n.tr(beat["text"])
        after = min(len(text), int(cut["t"] * TYPE_SPEED))
        if after - before > 8:   # текст показали сразу (Enter): без трескотни
            return
        for k in range(before, after):
            sound.speak(beat.get("who", ""), text[k])

    def begin_beat(self):
        cut = self.cut
        beat = cut["scene"]["beats"][cut["i"]]
        if "actors" in beat:
            cut["actors"] = [dict(a) for a in beat["actors"]]
        else:  # актёры остаются там, где остановились
            cut["actors"] = [dict(a, x=a["to"]) for a in cut["actors"]]
        cut["t"] = 0.0

    def advance_scene(self):
        cut = self.cut
        beat = cut["scene"]["beats"][cut["i"]]
        if cut["t"] * TYPE_SPEED < len(i18n.tr(beat["text"])):
            cut["t"] = 99.0  # допечатать сразу
            return
        cut["i"] += 1
        if cut["i"] >= len(cut["scene"]["beats"]):
            self.skip_scene()
        else:
            self.begin_beat()

    def skip_scene(self):
        then = self.cut["then"]
        self.cut = None
        self.after_scene(then)

    def after_scene(self, then):
        kind = then[0]
        if kind == "map":
            self.state = "map"
        elif kind == "room":
            self.start_room(then[1])
        elif kind == "resume":
            self.state = "play"
        elif kind == "win":
            self.state = "win"
            self.earn(classes.COIN_CHAPTER)  # награда за прохождение главы
            if self.chapter == 2 and not prefs.get("ch2_done"):
                prefs.data["ch2_done"] = True   # глава 2 пройдена: открывается глава 3 («Поезд»)
            if self.chapter == 1 and not prefs.get("ch1_done"):
                prefs.data["ch1_done"] = True  # глава 1 пройдена: открывается глава 2
            prefs.save()

    # ---------- бой в комнате ----------
    def start_room(self, rid):
        p = self.player
        self.refill_class_weapon()
        self.room_snapshot = {"weapon": p.weapon, "uses": p.uses, "alt": p.alt, "has_key": self.has_key}
        self.room_hurt = False
        self.focus_used = False
        info = info_of(rid)
        self.state, self.current = "play", rid
        self.mk, self.decoy, self.train = None, None, None
        p.x, p.y, p.vx, p.vy = 60.0, FLOOR - p.h, 0.0, 0.0
        self.door_open = False
        self.corpses = []
        self.room = THEMES[info["kind"]]
        self.setup_light()
        self.variant = info.get("num", 1) - 1
        self.furniture = self.room["build"](self.variant)
        if info["kind"] == "class":   # классы каждый раз разные: цвет стен и расстановка парт случайные
            self.variant = random.randrange(len(CLASS_WALLS))
            self.furniture = random_class_layout()
        self.platforms = [rect for rect, _ in self.furniture]
        self.boss, self.projectiles, self.msg, self.pie_timer = None, [], None, 0.0
        self.shots, self.fx, self.school, self.final, self.water_t = [], [], None, None, 0.0
        self.mini = None
        extra = ROUND_ZOMBIES * (self.round - 1)
        if info["kind"] == "office":
            self.zombies = []
            self.boss = Boss(W - 220, self.easy_hp(BOSS_HP + ROUND_BOSS_HP * (self.round - 1)))
            self.msg = ["Директор-зомби!", 2.5]
        elif info["kind"] == "final":
            self.zombies = []
            self.final = SchoolBoss(self.easy_hp(FINAL_HP + FINAL_HP_ROUND * (self.round - 1)))
            self.msg = ["ФИНАЛ: школа против тебя!", 3.0]
        elif info["kind"] == "warehouse":  # босс главы 2: королева червей
            self.zombies = []
            self.boss = Boss(W - 260, self.easy_hp(BOSS_HP * 3 // 2 + ROUND_BOSS_HP * (self.round - 1)), "queen")
            self.msg = ["Королева червей!", 2.5]
            self.mk = Store(self, rid)
        elif info["kind"] in TRAIN_KINDS:  # глава 3: вагоны поезда
            self.zombies = []
            self.train = Train(self, rid)
        elif info["kind"] in MARKET_KINDS:  # отделы мегамаркета
            self.zombies = []
            self.mk = Store(self, rid)
        elif rid == "c7":  # последний класс: мини-босс
            self.zombies = []
            self.mini = MiniBoss(W - 240, self.easy_hp(MINI_HP + MINI_HP_ROUND * (self.round - 1)))
            self.msg = ["Три хулигана в одном теле!", 2.5]
        else:
            base = {"toilet": 8, "canteen": 6, "gym": 9}.get(info["kind"]) or 2 + 2 * info["num"]
            self.zombies = [Zombie(random.randint(500, W - 80)) for _ in range(base + extra)]

        # лут: на каждой мебели и ещё пара штук прямо на полу
        spots = [(rect.centerx, rect.top) for rect in self.platforms]
        spots += [(random.randint(150, 850), FLOOR) for _ in range(2)]
        self.pickups = []
        kinds, weights = zip(*self.room["loot"].items())
        for i, (cx, surface) in enumerate(spots):
            kind = random.choices(kinds, weights)[0]
            if i == 0 and p.weapon is FISTS and not self.cleared and self.chapter == 1:
                kind = "club"  # самая первая находка в игре — оружие
            elif info["kind"] == "canteen" and i < 3:
                kind = "pie"   # в столовой всегда есть чем подкрепиться
            elif info["kind"] == "gym" and i == 0:
                kind = "dumbbell"  # в спортзале гарантированно лежит гантель
            self.add_loot(kind, cx, surface)
        if self.train is not None:
            self.train.setup_loot()
        if self.mk is not None:
            self.mk.setup_loot()  # в главе 2 часть вещей лежит по сюжету, а часть пирожков — мимики

    def add_loot(self, kind, cx, surface_y, uses=None):
        if uses is None and kind in WEAPONS:
            uses = WEAPONS[kind]["uses"]
        rect = pygame.Rect(cx - 24, surface_y - 40, 48, 40)
        self.pickups.append({"kind": kind, "rect": rect, "uses": uses})

    def restart(self, chapter=None):
        """R: всё заново (катсцены и режим проверки сохраняются). chapter — какую главу начинать."""
        sprites, test, cuts, ch = self.sprites, self.test_mode, self.cutscenes, self.chapter
        self.__init__()
        self.sprites, self.test_mode, self.cutscenes = sprites, test, cuts
        self.chapter = ch if chapter is None else chapter
        self.begin()

    def weapon_item_near(self):
        """Ближайшее оружие на полу, до которого можно дотянуться (для подсказки и кнопки E)."""
        p = self.player
        if self.mods is not None and self.mods.has("fists"):
            return None   # «только кулаки»: оружие не берём
        reach = p.rect.inflate(20, 0)
        near = [i for i in self.pickups if i["kind"] in WEAPONS and reach.colliderect(i["rect"])]
        return min(near, key=lambda i: abs(i["rect"].centerx - p.rect.centerx), default=None)

    def take_weapon(self):
        """Кнопка E: берём оружие, а то, что было в руках, кладём на то же место."""
        item = self.weapon_item_near()
        if (item is None or self.over) and self.train is not None and not self.over:
            self.train.pull_brake()   # рядом стоп-кран: дёргаем
            return
        if item is None or self.over:
            return
        p = self.player
        old, old_uses = p.weapon, p.uses
        if p.two_slots and old is not FISTS and p.alt[0] is FISTS:  # есть свободное второе место
            p.alt = (old, old_uses)
            p.weapon, p.uses = WEAPONS[item["kind"]], self.scaled_uses(item)
            self.pickups.remove(item)
            self.quest("pickup")
            return
        p.weapon, p.uses = WEAPONS[item["kind"]], self.scaled_uses(item)
        if old is FISTS:
            self.pickups.remove(item)
        else:
            item["kind"], item["uses"], item["own"] = old["key"], old_uses, True
        self.quest("pickup")

    def cycle_weapon(self):
        """Режим проверки: следующее оружие из таблицы с полными зарядами."""
        order = [FISTS] + list(WEAPONS.values())
        p = self.player
        nxt = order[(order.index(p.weapon) + 1) % len(order)]
        p.weapon, p.uses = nxt, nxt["uses"]
        self.msg = [f"Оружие: {nxt['name']}", 1.2]

    # ---------- оружие ----------
    def spend(self):
        """Один заряд оружия потрачен. Кончились — снова кулаки."""
        p = self.player
        if p.uses is None:
            return
        p.uses -= 1
        if p.uses <= 0:
            name = p.weapon["name"]
            if p.two_slots and p.alt[0] is not FISTS:  # во втором месте есть оружие: берём его
                p.weapon, p.uses = p.alt
                p.alt = (FISTS, None)
            else:
                p.weapon, p.uses = FISTS, None
            self.msg = [f"{name}: всё, закончилось!", 1.6]

    def tick_effects(self, t, dt):
        """Замедление и горение у зомби или босса."""
        t.slow_t = max(0.0, t.slow_t - dt)
        if t.dot_t > 0:
            t.dot_t -= dt
            t.dot_acc += dt
            if t.dot_acc >= 0.5:
                t.dot_acc -= 0.5
                t.hp -= 1
                t.flash = 0.1

    # ---------- эффекты ----------
    def setup_light(self):
        beams = self.room.get("beams", [])
        self.overlay = make_overlay(beams)
        self.motes = make_motes(beams, 26, seed=len(beams) + 7)
        self.particles.clear()

    def puff(self, x, y, n=6, color=(214, 202, 180)):
        """Облачко пыли."""
        light = tuple(min(255, c + 30) for c in color)
        self.particles.emit(x, y, n, [color, light], speed=(20, 90), life=(0.25, 0.55), size=(4, 8),
                            grav=-50, angle=-math.pi / 2, spread=math.pi * 0.9)

    def spark(self, x, y, dirn=1):
        """Искры при ударе."""
        self.particles.emit(x, y, 9, [(255, 240, 120), (255, 255, 255), (255, 196, 80)], speed=(90, 280),
                            life=(0.15, 0.35), size=(3, 6), grav=260, angle=0 if dirn > 0 else math.pi, spread=2.4)
        self.fx.append({"type": "hit", "x": x, "y": y, "t": 0.0})

    def sparkle(self, x, y, color=(255, 232, 110)):
        """Блёстки вверх: подобрал что-то хорошее."""
        self.particles.emit(x, y, 12, [color, (255, 255, 255)], speed=(40, 150), life=(0.4, 0.8), size=(3, 5),
                            grav=-120, angle=-math.pi / 2, spread=math.pi * 0.8)

    def add_shake(self, amp, t):
        if not prefs.get("shake"):
            return
        if amp * t >= self.shake[0] * max(0.0, self.shake[1]):
            self.shake = [float(amp), float(t), float(t)]

    def on_player_hurt(self, dmg):
        p = self.player
        self.room_hurt = True
        self.hurt_flash = 0.35
        self.add_shake(3 + dmg * 1.5, 0.2)
        self.particles.emit(p.x + p.w / 2, p.y + 24, 10, [(230, 60, 80), (255, 140, 140)], speed=(60, 220),
                            life=(0.2, 0.45), size=(3, 6), grav=360)

    def fx_tick(self, dt):
        self.particles.update(dt)
        self.shake[1] = max(0.0, self.shake[1] - dt)
        self.hurt_flash = max(0.0, self.hurt_flash - dt)

    def apply_shake(self, s):
        amp, left, total = self.shake
        if left <= 0:
            return
        k = amp * (left / total)
        dx, dy = random.randint(-int(k), int(k)), random.randint(-int(k), int(k))
        if dx or dy:
            snap = s.copy()
            s.fill((0, 0, 0))
            s.blit(snap, (dx, dy))

    def draw_shadows(self, s):
        """Мягкие тени под героем, зомби и боссами — они стоят на земле, а не висят."""
        def one(rect, base):
            draw_shadow(s, rect.centerx, rect.bottom, ground_below(self.platforms, rect.left, rect.right, rect.bottom), base)
        one(self.player.rect, 64)
        for z in self.zombies:
            one(z.rect, max(40, int(z.w * 1.5)))
        if self.boss and self.boss.state not in ("dying", "hide"):
            one(self.boss.rect, int(self.boss.w * 1.5))
        if self.mini and self.mini.state != "dying":
            one(self.mini.rect, 120)

    def apply_hit(self, t, w, dirn):
        """Попадание оружия w по зомби или боссу t."""
        if isinstance(t, Zombie):   # чем добили, для квестов «убить оружием»
            t.last_w = "fists" if w["key"] in ("fists", "kick") else w["key"]
        p = self.player
        dmg = w["dmg"] * (self.mods.dmg_mult() if self.mods is not None else 1) * p.dmg_mult
        if p.rage and p.hp <= 1:   # «Ярость» Обыкновенного 5-го уровня
            dmg *= 2
        t.hp -= dmg
        if dmg > 0:
            t.flash = 0.12
            self.spark(t.x + t.w / 2, t.y + t.h / 2 - 8, dirn)
        if isinstance(t, Zombie):
            t.x += dirn * w.get("kb", 40 if w["type"] == "melee" else 0)
            t.x = max(0, min(self.ww - t.w, t.x))
        if "slow" in w:
            t.slow_t = max(t.slow_t, w["slow"])
        if "stun" in w:
            limit = 1.5 if isinstance(t, Boss) else w["stun"]  # босса надолго не оглушить
            t.stun_t = max(t.stun_t, min(w["stun"], limit))
        if "dot" in w:
            t.dot_t = max(t.dot_t, w["dot"])

    def targets(self):
        boss = [self.boss] if self.boss and self.boss.state not in ("dying", "hide") else []
        weak = [self.final] if self.final and self.final.state == "vuln" else []  # колокол только когда упал
        mini = [self.mini] if self.mini and self.mini.state != "dying" else []
        return list(self.zombies) + boss + weak + mini

    def use_weapon(self):
        p = self.player
        w = p.eff()   # у Тхэквондиста кулаки — это удар ногой
        p.attack_cd = w["cd"] * p.cd_mult * (self.mods.cd_mult() if self.mods is not None else 1)   # у Геймера быстрее
        kind = w["type"]
        if kind == "melee":
            p.swing = 0.15
            hit = p.attack_rect()
            kicking = p.kick and p.weapon is FISTS   # Тхэквондист бьёт ногой, пока кулаки пустые
            if kicking and p.kick_both:   # 4-й уровень: нога бьёт и назад
                reach = w["reach"]
                hit = pygame.Rect(int(p.x - reach), int(p.y + 10), int(p.w + 2 * reach), 40)
            hits = 0
            for t in self.targets():
                if hit.colliderect(t.rect):
                    dirn = (1 if t.x + t.w / 2 >= p.x + p.w / 2 else -1) if (kicking and p.kick_both) else p.face
                    self.apply_hit(t, w, dirn)
                    if p.stumble and isinstance(t, Zombie) and random.random() < p.stumble:
                        t.stun_t = max(t.stun_t, 0.5)   # 4-й уровень Приколиста: враг споткнулся
                    hits += 1
            if kicking and p.whirl and not p.on_ground:   # 5-й уровень: вертушка в прыжке
                self.whirlwind()
            if hits:
                self.spend()  # стул ломается только когда им попал
        elif kind in ("shot", "throw"):
            p.swing = 0.1
            self.shots.append({"x": p.x + p.w / 2 + p.face * 30, "y": p.y + 26.0, "w": w, "dir": p.face,
                               "x0": p.x + p.w / 2 + p.face * 30, "t": 0.0,
                               "vx": p.face * w["speed"], "vy": w.get("vy", 0.0)})
            self.spend()
        elif kind == "shield":
            p.shield_t = w["dur"]
            self.spend()
        elif kind == "decoy":  # игрушка пони скачет по комнате и отвлекает всех
            p.swing = 0.1
            self.decoy = {"x": p.x + p.w / 2, "dir": p.face, "t": w["dur"], "anim": 0.0}
            self.msg = ["Пони скачет и отвлекает всех!", 2.0]
            self.spend()
        elif kind == "bell":
            for t in self.targets():
                t.stun_t = max(t.stun_t, 1.5 if isinstance(t, Boss) else 2.5)
            self.fx.append({"type": "ring", "x": p.x + p.w / 2, "y": p.y + 30, "t": 0.0})
            self.msg = ["ДЗЫНЬ! Все замерли", 1.5]
            self.spend()

    def whirlwind(self):
        """Вертушка Тхэквондиста: удар ногой в прыжке отбрасывает и оглушает всех рядом (босса слабее)."""
        p = self.player
        cx = p.x + p.w / 2
        self.fx.append({"type": "ring", "x": cx, "y": p.y + 30, "t": 0.0})
        self.add_shake(4, 0.2)
        for t in self.targets():
            if abs(t.x + t.w / 2 - cx) < 170 and abs(t.y + t.h / 2 - (p.y + p.h / 2)) < 220:   # героя в прыжке над землёй тоже достаёт
                t.stun_t = max(t.stun_t, 0.6 if not isinstance(t, Zombie) else 1.0)
                if isinstance(t, Zombie):
                    t.x += 70 if t.x + t.w / 2 > cx else -70
                    t.x = max(0, min(self.ww - t.w, t.x))

    def explode(self, x, y, w):
        r = w["area"]
        for t in self.targets():
            cx, cy = t.x + t.w / 2, t.y + t.h / 2
            if (cx - x) ** 2 + (cy - y) ** 2 <= (r + t.w / 2) ** 2:
                self.apply_hit(t, w, 1 if cx > x else -1)
                if isinstance(t, Zombie):
                    t.x += 50 if cx > x else -50
                    t.x = max(0, min(self.ww - t.w, t.x))
        self.fx.append({"type": "boom", "x": x, "y": y, "R": r, "t": 0.0})
        self.add_shake(6, 0.28)
        self.particles.emit(x, y, 22, [(255, 190, 60), (255, 120, 40), (255, 240, 160)], speed=(80, 330),
                            life=(0.25, 0.6), size=(4, 8), grav=200)

    def update_shots(self, dt):
        for sh in self.shots:
            w = sh["w"]
            sh["t"] += dt
            sh["vy"] += w.get("grav", 0) * dt
            sh["x"] += sh["vx"] * dt
            sh["y"] += sh["vy"] * dt
            box = pygame.Rect(int(sh["x"]) - 9, int(sh["y"]) - 9, 18, 18)
            target = next((t for t in self.targets() if box.colliderect(t.rect)), None)
            landed = sh["y"] >= FLOOR - 4
            too_far = w["type"] == "shot" and abs(sh["x"] - sh["x0"]) > w["range"]
            if target or landed or too_far or not -30 < sh["x"] < self.ww + 30:
                if w.get("area"):
                    self.explode(sh["x"], min(sh["y"], FLOOR - 10), w)  # бомба взрывается везде
                elif target:
                    self.apply_hit(target, w, sh["dir"])
                sh["dead"] = True
        self.shots = [sh for sh in self.shots if not sh.get("dead")]
        for e in self.fx:
            e["t"] += dt
        self.fx = [e for e in self.fx if e["t"] < 0.45]

    @staticmethod
    def easy_hp(hp):
        return max(3, round(hp * EASY_HP)) if easy_on() else hp

    def hurt_player(self, dmg, knock_from_x):
        """Игрок получил урон (с неуязвимостью на время мигания)."""
        p = self.player
        if p.hurt_cd > 0 or p.shield_t > 0:
            return  # мигаешь после удара или держишь щит
        if easy_on():  # в лёгком режиме (на телефоне) удар босса отнимает не больше 1 сердца и защита после удара дольше
            dmg = min(dmg, 1)
        p.hp -= dmg
        self.on_player_hurt(dmg)
        p.hurt_cd = (1.4 if easy_on() else 0.9) * p.hurt_mult   # у Ботана 4-го уровня защита дольше
        p.vy = -400
        p.x += 40 if p.x + p.w / 2 > knock_from_x else -40
        p.x = max(0, min(self.ww - p.w, p.x))

    def update_boss(self, dt):
        b, p = self.boss, self.player
        b.flash = max(0, b.flash - dt)
        b.t += dt
        if b.state == "dying":
            if b.t > 1.4:
                self.boss = None
                self.add_loot("pie", int(b.x + b.w / 2), FLOOR)  # из директора выпадает пирожок
                self.quest("boss")
                if self.endless is not None:   # в бесконечном режиме без катсцены: просто награда
                    self.earn(30 + 5 * self.endless.wave)
                    self.msg = ["Босс побеждён!", 2.5]
                    return
                self.play_scene({"queen": "m_boss_defeat", "driver": "t_driver_defeat"}.get(b.kind, "boss_defeat"),
                                ("resume",))
            return
        if b.state == "hide":  # прячется, пока школа нападает
            self.update_school(dt)
            return
        self.tick_effects(b, dt)
        if b.hp <= 0:
            b.set_state("dying")
            self.projectiles = []
            return

        b.bite_cd = max(0, b.bite_cd - dt)
        bc = b.x + b.w / 2
        pc = self.decoy["x"] if self.decoy else p.x + p.w / 2   # пони отвлекает и босса
        to_p = 1 if pc > bc else -1

        # злость: меньше половины здоровья
        if not b.phase2 and b.hp <= b.maxhp / 2:
            if self.round >= 2 and not b.school_done:  # со 2-го круга: сначала «ты против школы»
                b.school_done = True
                b.set_state("hide")
                self.start_school()
                return
            b.phase2, b.speed = True, 95
            helpers = {"queen": "worm", "driver": "runner"}.get(b.kind, "zombie")
            self.zombies += [Zombie(self.helper_x(b), helpers) for _ in range(3 if helpers == "zombie" else 4)]
            self.msg = [{"queen": "Королева зовёт червяков на помощь!", "driver": "Машинист зовёт заражённых!"}.get(
                b.kind, "Директор в ярости! Зовёт подмогу!"), 2.5]

        if b.stun_t > 0:  # оглушён звонком или мусоркой — стоит и качается
            b.stun_t -= dt
            self.boss_pies(dt)
            return

        slow = 0.6 if b.slow_t > 0 else 1.0
        if b.state == "walk":
            b.face = to_p
            b.x += b.face * b.speed * slow * dt
            b.anim += b.speed * slow * dt
            b.throw_cd -= dt
            b.charge_cd -= dt
            if b.throw_cd <= 0 and not self.decoy:
                b.set_state("throw")
            elif b.charge_cd <= 0:
                b.face = to_p
                b.set_state("windup")
        elif b.state == "throw":
            b.face = to_p
            if b.t >= 0.5:  # замах закончен — кидаем двойки
                ys = [p.y + 30]
                if b.phase2:
                    ys.append(FLOOR - 30)
                for y in ys:
                    self.projectiles.append({"x": bc + b.face * 40, "y": float(y), "vx": b.face * 380, "t": 0.0})
                b.throw_cd = 1.5 if b.phase2 else 2.4
                b.set_state("walk")
        elif b.state == "windup":  # трясётся — сейчас рванёт на тебя
            if b.t >= 0.7:
                b.dir = b.face
                b.set_state("charge")
        elif b.state == "charge":
            b.x += b.dir * 520 * dt
            if b.t >= 0.9 or b.x <= 0 or b.x + b.w >= self.ww:
                b.set_state("tired")
        elif b.state == "tired":  # выдохся — самое время бить
            if b.t >= (0.6 if b.phase2 else 0.9):
                b.charge_cd = 3.5 if b.phase2 else 5.5
                b.set_state("walk")
        b.x = max(0, min(self.ww - b.w, b.x))

        # столкновение с игроком
        if b.rect.colliderect(p.rect) and not self.decoy:
            if b.state == "charge":
                if p.shield_t > 0:  # врезался в щит
                    b.set_state("tired")
                    self.msg = [{"queen": "Блок! Королева выдохлась", "driver": "Блок! Машинист выдохся"}.get(
                        b.kind, "Блок! Директор выдохся"), 1.5]
                else:
                    self.hurt_player(2, bc)
            elif b.state in ("walk", "throw") and b.bite_cd == 0:
                b.bite_cd = 1.2
                self.hurt_player(1, bc)

        self.boss_pies(dt)

    def update_mini(self, dt):
        m, p = self.mini, self.player
        m.flash = max(0.0, m.flash - dt)
        m.t += dt
        if m.state == "dying":
            if m.t > 1.5:
                self.mini = None
                self.quest("boss")
                self.add_loot("pie", int(m.x + m.w / 2) - 40, FLOOR)
                if not self.has_key:
                    self.add_loot("key", int(m.x + m.w / 2) + 20, FLOOR)  # ключ от кабинета директора
                self.play_scene("mini_defeat", ("resume",))
            return
        self.tick_effects(m, dt)
        if m.hp <= 0:
            m.set_state("dying")
            self.projectiles = []
            return
        heads = 3 if m.hp > m.maxhp * 2 / 3 else (2 if m.hp > m.maxhp / 3 else 1)
        if heads < m.heads:  # одна голова вырубилась — колокол звякает, атака пропадает
            lost = {3: "Колян", 2: "Толян"}[m.heads]
            m.heads = heads
            self.fx.append({"type": "ring", "x": m.x + m.w / 2, "y": m.y, "t": 0.0})
            self.msg = [f"Колокол звякнул: {lost} вырубился!", 2.5]
            self.add_loot("pie", random.randint(120, self.ww - 140), FLOOR)
            m.attack_cd = 1.5
        cd = {3: 2.2, 2: 1.8, 1: 1.4}[m.heads]
        bc, pc = m.x + m.w / 2, p.x + p.w / 2
        to_p = 1 if pc > bc else -1
        m.bite_cd = max(0.0, m.bite_cd - dt)
        if m.stun_t > 0:
            m.stun_t -= dt
            self.boss_pies(dt)
            return
        slow = 0.6 if m.slow_t > 0 else 1.0
        if m.state == "walk":
            m.face = to_p
            m.x += m.face * m.speed * slow * dt
            m.anim += m.speed * slow * dt
            m.attack_cd -= dt
            if m.attack_cd <= 0:  # какие атаки есть, зависит от живых голов
                kind = ["charge", "coins", "stomp"][:m.heads][m.n % m.heads]
                m.n += 1
                m.face = to_p
                m.set_state("w_" + kind)
        elif m.state == "w_charge":  # Борян: трясётся и несётся на тебя
            if m.t >= 0.7:
                m.dir = m.face
                m.set_state("charge")
        elif m.state == "charge":
            m.x += m.dir * 520 * dt
            if m.t >= 0.8 or m.x <= 0 or m.x + m.w >= W:
                m.set_state("tired")
        elif m.state == "tired":
            if m.t >= (0.6 if m.heads == 1 else 0.8):
                m.attack_cd = cd
                m.set_state("walk")
        elif m.state == "w_coins":  # Толян: швыряет твои же монеты по дуге
            if m.t >= 0.5:
                for vx in (240, 340, 440):
                    self.projectiles.append({"x": bc + m.face * 40, "y": m.y + 20.0, "vx": m.face * vx, "vy": -520.0,
                                             "grav": 1500, "t": 0.0, "kind": "coin"})
                m.attack_cd = cd
                m.set_state("walk")
        elif m.state == "w_stomp":  # Колян: топает, по полу в обе стороны бегут волны — прыгай
            if m.t >= 0.8:
                self.add_shake(6, 0.25)
                self.puff(bc, FLOOR - 4, 12)
                for d in (-1, 1):
                    self.projectiles.append({"x": bc + d * 50, "y": FLOOR - 18.0, "vx": d * 430, "t": 0.0, "kind": "wave"})
                m.attack_cd = cd
                m.set_state("walk")
        m.x = max(0, min(W - m.w, m.x))

        if m.rect.colliderect(p.rect):
            if m.state == "charge":
                if p.shield_t > 0:  # врезался в щит
                    m.set_state("tired")
                    self.msg = ["Блок! Они выдохлись", 1.5]
                else:
                    self.hurt_player(2, bc)
            elif m.state == "walk" and m.bite_cd == 0:
                m.bite_cd = 1.2
                self.hurt_player(1, bc)
        self.boss_pies(dt)

    def start_school(self):
        """Директор спрятался — школа оживает: падают парты и стулья, по полу летят парты."""
        self.school = {"t": 0.0, "drop_cd": 0.8, "slide_cd": 2.2, "pie_t": SCHOOL_PIE_EVERY - 1.5, "hazards": []}
        self.projectiles = []
        self.msg = ["ШКОЛА ПРОТИВ ТЕБЯ! Уворачивайся!", 3.0]

    def tick_hazards(self, sc, dt, spawn, drop_every, slide_every):
        """Парты и стулья: падают сверху (сначала тень-предупреждение) и летят по полу.
        Общий код для «ты против школы» и для финала."""
        p = self.player
        if spawn:
            sc["drop_cd"] -= dt
            sc["slide_cd"] -= dt
            if sc["drop_cd"] <= 0:
                sc["drop_cd"] = drop_every
                x = max(60, min(W - 60, int(p.x + p.w / 2 + random.randint(-220, 220))))
                sc["hazards"].append({"type": "drop", "kind": random.choice(("desk", "chair")),
                                      "x": x, "y": -50.0, "vy": 0.0, "warn": 0.7})
            if sc["slide_cd"] <= 0:
                sc["slide_cd"] = slide_every
                d = random.choice((-1, 1))
                sc["hazards"].append({"type": "slide", "kind": "desk", "x": float(-90 if d > 0 else W + 90),
                                      "y": float(FLOOR - 35), "dir": d, "warn": 0.9})
        for hz in sc["hazards"]:
            if hz["warn"] > 0:
                hz["warn"] -= dt
                continue
            if hz["type"] == "drop":
                hz["vy"] += 2400 * dt
                hz["y"] += hz["vy"] * dt
                rect = pygame.Rect(hz["x"] - 35, int(hz["y"]), 70, 40)
                if rect.bottom >= FLOOR:
                    hz["dead"] = True
                    self.puff(hz["x"], FLOOR - 4, 8)
                    self.add_shake(3, 0.12)
            else:
                hz["x"] += hz["dir"] * 620 * dt
                rect = pygame.Rect(int(hz["x"]) - 35, int(hz["y"]), 70, 35)
                if hz["x"] < -100 or hz["x"] > W + 100:
                    hz["dead"] = True
            if rect.colliderect(p.rect) and not hz.get("dead"):
                self.hurt_player(1, rect.centerx)  # щит и мигание после удара защищают
        sc["hazards"] = [hz for hz in sc["hazards"] if not hz.get("dead")]

    def update_school(self, dt):
        sc, b = self.school, self.boss
        sc["t"] += dt
        sc["pie_t"] += dt
        self.tick_hazards(sc, dt, True, max(0.55, 1.1 - sc["t"] * 0.03), 3.2)
        if sc["pie_t"] >= SCHOOL_PIE_EVERY:
            sc["pie_t"] = 0.0
            self.add_loot("pie", random.randint(120, self.ww - 140), FLOOR)
            self.msg = [f"{self.helper_name()} прислала пирожок!", 2.0]
        self.maybe_water(dt)
        if sc["t"] >= SCHOOL_TIME:  # школа успокоилась — директор возвращается злее
            self.school = None
            b.x = float(random.choice((60, W - 120)))
            b.set_state("walk")
            self.msg = ["Школа успокоилась. Директор вернулся!", 2.5]

    def update_final(self, dt):
        f = self.final
        f.flash = max(0.0, f.flash - dt)
        f.t += dt
        sc = f.sc
        sc["t"] += dt
        sc["pie_t"] += dt
        if f.state == "dying":  # школа затихает
            self.tick_hazards(sc, dt, False, 1, 1)
            if f.t > 2.0:
                self.final = None
                self.finish_final()
            return
        if f.hp <= 0:
            f.state, f.t = "dying", 0.0
            sc["hazards"] = []
            self.msg = ["Школа затихает...", 2.5]
            return
        rage = f.hp <= f.maxhp / 2
        if rage and not f.enraged:
            f.enraged = True
            self.msg = ["Школа в ярости! Всё быстрее!", 2.5]
        if f.state == "hang":
            f.y = 140 + math.sin(f.t * 2) * 8
            if f.t >= (6.5 if rage else 9.0):
                f.state, f.t = "drop", 0.0
        elif f.state == "drop":
            f.y += 560 * dt
            if f.y >= FLOOR - f.h:
                f.y, f.state, f.t = float(FLOOR - f.h), "vuln", 0.0
                self.add_shake(7, 0.3)
                self.puff(f.x + f.w / 2, FLOOR - 4, 14, (230, 190, 90))
                self.msg = ["Колокол упал! БЕЙ ПО НЕМУ!", 2.0]
        elif f.state == "vuln":  # слабое место — бей, пока не поднялся
            if f.t >= (5.0 if rage else 6.0):
                f.state, f.t = "rise", 0.0
        elif f.state == "rise":
            f.y -= 420 * dt
            if f.y <= 140:
                f.y, f.state, f.t = 140.0, "hang", 0.0
        self.tick_hazards(sc, dt, f.state == "hang", 0.7 if rage else 1.0, 2.4 if rage else 3.4)
        if sc["pie_t"] >= BOSS_PIE_EVERY:
            sc["pie_t"] = 0.0
            self.add_loot("pie", random.randint(120, self.ww - 140), FLOOR)
            self.msg = [f"{self.helper_name()} прислала пирожок!", 2.0]
        self.maybe_water(dt)

    def finish_final(self):
        """Школа побеждена — победа во всей игре."""
        self.quest("boss")
        self.cleared.add("school")
        self.player.hp = min(self.player.max_hp, self.player.hp + 2)
        self.play_scene("victory", ("win",))

    def maybe_water(self, dt):
        """Раз в 3 секунды — 30% шанс, что из столовой прилетит водяной пистолет (для тебя)."""
        self.water_t += dt
        if self.water_t < WATER_EVERY:
            return
        self.water_t = 0.0
        if random.random() >= WATER_CHANCE:
            return
        p = self.player
        if p.weapon["key"] == "watergun" or any(i["kind"] == "watergun" for i in self.pickups):
            return  # уже есть
        x = int(p.x + p.w / 2 + random.choice((-1, 1)) * random.randint(90, 180))
        self.add_loot("watergun", max(80, min(self.ww - 80, x)), FLOOR)
        self.msg = [f"{self.helper_name()} прислала водяной пистолет!", 2.0]

    def helper_name(self):
        """Кто присылает пирожки в бою с боссом."""
        return {3: "Проводница"}.get(self.chapter, "Повариха")

    def boss_pies(self, dt):
        """Пирожки из столовой во время боя (и шанс на водяной пистолет)."""
        self.maybe_water(dt)
        self.pie_timer += dt
        if self.pie_timer >= BOSS_PIE_EVERY:
            self.pie_timer = 0.0
            self.add_loot("pie", random.randint(120, self.ww - 140), FLOOR)
            self.msg = [f"{self.helper_name()} прислала пирожок!", 2.0]

    def spawn_driver(self):
        """Глава 3: зомби-машинист поворачивается от пульта (босс поезда)."""
        self.boss = Boss(W - 220, self.easy_hp(BOSS_HP * 4 // 5), "driver")
        self.msg = ["Зомби-машинист!", 2.5]
        self.play_scene("t_driver_boss", ("resume",))

    def update_projectiles(self, dt):
        p = self.player
        for pr in self.projectiles:
            pr["x"] += pr["vx"] * dt
            pr["t"] += dt
            if "grav" in pr:  # монета летит по дуге
                pr["vy"] += pr["grav"] * dt
                pr["y"] += pr["vy"] * dt
            w, h = {"coin": (18, 18), "wave": (46, 36)}.get(pr.get("kind"), (22, 28))
            hit = pygame.Rect(int(pr["x"]) - w // 2, int(pr["y"]) - h // 2, w, h)
            if hit.colliderect(p.rect):
                if p.shield_t > 0:  # двойку отбил щитом
                    pr["dead"] = True
                elif p.hurt_cd == 0:
                    self.hurt_player(1, pr["x"])
                    pr["dead"] = True
        self.projectiles = [pr for pr in self.projectiles
                            if not pr.get("dead") and -40 < pr["x"] < self.ww + 40 and pr["y"] < FLOOR + 20]

    # ---------- логика ----------
    def update(self, dt, keys, mouse_pressed):
        if self.toast:
            self.toast[1] -= dt
            if self.toast[1] <= 0:
                self.toast = None
        if self.state == "menu":
            self.menu.update(dt)
            return
        if self.map_msg:
            self.map_msg[1] -= dt
            if self.map_msg[1] <= 0:
                self.map_msg = None
        if self.state == "cutscene":
            self.talk_sound(dt)
            return
        if self.state != "play" or self.over:
            return
        p = self.player
        if self.mods is not None:   # бесконечный режим: время, события модификаторов, волны
            dt *= self.mods.time_scale()
            self.mods.update(self, dt)
            self.endless.update(self, dt)
        self.fx_tick(dt)
        if self.mk is not None:
            self.mk.update(dt)  # червяки из яблок, мимики, акция, объявления
        if self.train is not None:
            self.train.update(dt, keys)
            if self.state != "play":
                return  # началась катсцена или вагон пройден
        if self.decoy:  # игрушка пони скачет туда-сюда
            d = self.decoy
            d["x"] += d["dir"] * 280 * dt
            d["anim"] += dt
            if d["x"] < 30 or d["x"] > self.ww - 60:
                d["dir"] *= -1
                d["x"] = max(30.0, min(self.ww - 60.0, d["x"]))
            d["t"] -= dt
            self.particles.emit(d["x"], FLOOR - 24, 1, [(250, 160, 50), (245, 225, 70), (90, 200, 100), (80, 140, 230)],
                                speed=(10, 50), life=(0.2, 0.4), size=(3, 5))
            if d["t"] <= 0:
                self.puff(d["x"], FLOOR - 10, 10, (250, 150, 200))
                self.decoy = None
        move = (keys[pygame.K_d] or keys[pygame.K_RIGHT]) - (keys[pygame.K_a] or keys[pygame.K_LEFT])
        if self.mods is not None and self.mods.has("mirror"):
            move = -move
        p.running = bool(move) and (keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT])
        p.vx = move * (WALK_SPEED if not p.running else RUN_SPEED) * p.speed_mult
        if self.mods is not None:
            p.vx = self.mods.hero_vx(p, p.vx, dt)
        if move:
            p.face = move
        p.anim += abs(p.vx) * dt
        jump_key = bool(keys[pygame.K_w] or keys[pygame.K_UP] or keys[pygame.K_SPACE])
        if p.on_ground:
            p.air_jumps = 1 if p.double_jump else 0
        if jump_key and p.on_ground:
            p.vy = JUMP
            p.on_ground = False
            self.quest("jump")
        elif jump_key and not p.prev_jump and not p.on_ground and p.air_jumps > 0:  # Геймер: второй прыжок
            p.air_jumps -= 1
            self.quest("jump")
            p.vy = JUMP * 0.9
            self.puff(p.x + p.w / 2, p.y + p.h, 6, (200, 220, 255))
        p.prev_jump = jump_key

        # движение и гравитация
        grav = GRAVITY * (self.mods.gravity() if self.mods is not None else 1)
        p.vy += grav * dt
        was_air, vy_pre = not p.on_ground, p.vy
        p.x = max(0, min(self.ww - p.w, p.x + p.vx * dt))
        prev_bottom = p.y + p.h
        p.y += p.vy * dt
        p.on_ground = False
        if p.y + p.h >= FLOOR:
            p.y, p.vy, p.on_ground = FLOOR - p.h, 0, True
        elif p.vy > 0:
            for pl in self.platforms:
                if (prev_bottom <= pl.top + 2 and p.y + p.h >= pl.top
                        and p.x + p.w > pl.left and p.x < pl.right):
                    p.y, p.vy, p.on_ground = pl.top - p.h, 0, True
        if self.mods is not None:
            bounce = self.mods.bounce(p, vy_pre)
            if bounce is not None:   # батут-пол
                p.vy, p.on_ground = bounce, False

        if p.on_ground and was_air and vy_pre > 450:  # приземлился — пыль
            self.puff(p.x + p.w / 2, p.y + p.h - 4, 7)
            self.add_shake(2, 0.08)
        self.run_dust_t -= dt
        if p.on_ground and p.running and abs(p.vx) > 1 and self.run_dust_t <= 0:  # бежишь — пыль из-под ног
            self.run_dust_t = 0.09
            self.puff(p.x + p.w / 2 - p.face * 14, p.y + p.h - 4, 2)

        # оружие
        p.attack_cd = max(0, p.attack_cd - dt)
        p.swing = max(0, p.swing - dt)
        p.hurt_cd = max(0, p.hurt_cd - dt)
        p.shield_t = max(0, p.shield_t - dt)
        if (keys[pygame.K_j] or mouse_pressed) and p.attack_cd == 0:
            self.use_weapon()

        # зомби
        for z in self.zombies:
            z.flash = max(0, z.flash - dt)
            z.bite_cd = max(0, z.bite_cd - dt)
            self.tick_effects(z, dt)
            tx = self.decoy["x"] if self.decoy else p.x   # пони отвлекает всех: бегут за ней
            z.face = 1 if tx > z.x else -1
            mult = 0.0 if z.stun_t > 0 else (ZOMBIE_SLOW if z.slow_t > 0 else 1.0)
            z.stun_t = max(0.0, z.stun_t - dt)
            z.x += z.face * z.speed * mult * dt
            z.anim += z.speed * mult * dt
            if self.mods is not None:
                z.x = max(0.0, min(self.ww - z.w, z.x + self.mods.push(z) * dt))
            if z.hop and z.on_ground and mult > 0:  # куры и барашки скачут
                z.hop_t -= dt
                if z.hop_t <= 0:
                    z.vy, z.on_ground, z.hop_t = -430, False, random.uniform(0.8, 1.8)
            # зомби умеют прыгать на платформы, если игрок выше
            if z.on_ground and p.y + p.h < z.y + z.h - 40 and abs(p.x - z.x) < 120:
                z.vy, z.on_ground = -760, False
            z.vy += grav * dt
            prev_bottom = z.y + z.h
            z.y += z.vy * dt
            z.on_ground = False
            if z.y + z.h >= FLOOR:
                z.y, z.vy, z.on_ground = FLOOR - z.h, 0, True
            elif z.vy > 0:
                for pl in self.platforms:
                    if (prev_bottom <= pl.top + 2 and z.y + z.h >= pl.top
                            and z.x + z.w > pl.left and z.x < pl.right):
                        z.y, z.vy, z.on_ground = pl.top - z.h, 0, True
            if z.rect.colliderect(p.rect) and z.bite_cd == 0 and p.hurt_cd == 0 and z.stun_t <= 0 and not self.decoy:
                if p.shield_t > 0:  # щит: зомби отлетает назад
                    z.bite_cd = 0.6
                    z.x -= z.face * 30
                else:
                    p.hp -= z.dmg
                    self.on_player_hurt(z.dmg)
                    if self.mods is not None:
                        self.mods.on_bite(self)
                    z.bite_cd = 1.0
                    p.hurt_cd = 0.8 * p.hurt_mult
                    p.vy = -400
                    p.x += -z.face * 30
        for z in self.zombies:
            if z.hp <= 0:
                self.earn(classes.COIN_ZOMBIE)
                self.corpses.append({"cx": z.rect.centerx, "bottom": z.rect.bottom, "kind": z.kind,
                                     "face": z.face, "fall": p.face, "t": 0.0})
                self.puff(z.rect.centerx, z.rect.bottom - 8, 9, (120, 200, 120))
                self.quest("kill", kind=z.kind, weapon=getattr(z, "last_w", None))
                self.kill_total += 1
                if p.kill_pie and self.kill_total % p.kill_pie == 0:   # 5-й уровень Обыкновенного
                    self.add_loot("pie", z.rect.centerx, z.rect.bottom)
                if p.combo:   # Геймер 4-го уровня: пять убийств подряд — монеты
                    self.streak += 1
                    self.streak_t = 3.0
                    if self.streak >= 5:
                        self.earn(1)
                if self.mods is not None:
                    self.endless.kills += 1
                    self.mods.on_kill(self, z)
                if self.endless is not None:   # на арене вещей много: пирожки, линейки, бомбы, пистолеты
                    kind = endless.random_loot(self.mods) if random.random() < endless.LOOT_CHANCE else None
                    if kind:
                        self.add_loot(kind, z.rect.centerx, z.rect.bottom)
                        del self.pickups[:max(0, len(self.pickups) - 30)]
                elif random.random() < PIE_DROP_CHANCE + p.pie_bonus:
                    self.add_loot("pie", z.rect.centerx, z.rect.bottom)
        self.zombies = [z for z in self.zombies if z.hp > 0]
        bdt = dt * EASY_SPEED if easy_on() else dt
        if self.boss:
            self.update_boss(bdt)
        if self.final:
            self.update_final(bdt)
        if self.mini:
            self.update_mini(bdt)
        if self.state != "play":
            return  # катсцена или победа запустились в этом кадре
        self.update_projectiles(bdt)
        self.update_shots(dt)
        if self.msg:
            self.msg[1] -= dt
            if self.msg[1] <= 0:
                self.msg = None
        for c in self.corpses:
            c["t"] += dt
        self.corpses = [c for c in self.corpses if c["t"] < CORPSE_TIME]

        # ключ подбирается сам
        for item in list(self.pickups):
            if item["kind"] == "key" and p.rect.colliderect(item["rect"]):
                self.has_key = True
                self.pickups.remove(item)
                self.sparkle(p.x + p.w / 2, p.y + 10)
                self.msg = ["Ключ от кабинета директора у тебя!", 2.5]

        # кошелёк работника в туалете (глава 2): +60 монет
        for item in list(self.pickups):
            if item["kind"] == "wallet" and p.rect.colliderect(item["rect"]):
                self.pickups.remove(item)
                self.earn(60)
                self.sparkle(p.x + p.w / 2, p.y + 10, (245, 205, 70))
                self.msg = ["Кошелёк: +60 монет!", 3.0]

        # пирожки подбираются сами (если ты ранен)
        for item in list(self.pickups):
            sick = self.mods is not None and self.mods.poison_t > 0   # отравленному пирожок нужен, даже если сердца целы
            if item["kind"] == "pie" and (p.hp < p.max_hp or sick) and p.rect.colliderect(item["rect"]):
                if self.mods is not None:
                    self.mods.cure()
                    if not self.mods.has("vampire"):
                        p.hp = min(p.max_hp, p.hp + p.pie_heal)
                else:
                    p.hp = min(p.max_hp, p.hp + p.pie_heal)   # у Ботана 5-го уровня пирожок лечит на 2
                self.pickups.remove(item)
                self.sparkle(p.x + p.w / 2, p.y + 10, (255, 150, 160))
                self.quest("pie")

        if self.test_mode:
            p.hp = p.max_hp
            if not self.zombies and self.boss is None:
                self.zombies = [Zombie(random.randint(450, W - 80)) for _ in range(4)]

        if self.current == "c7" and self.mini is None and not self.zombies and not self.has_key and not self.key_hint:
            self.key_hint = True
            self.msg = ["Подними ключ: без него дверь не откроется", 3.0]

        # дверь: комната зачищена — можно вернуться на карту
        if (self.endless is None and not self.zombies and self.boss is None and self.final is None and self.mini is None
                and (self.current != "c7" or self.has_key)
                and (self.mk is None or self.mk.exit_ready())
                and (self.train is None or self.train.exit_ready())):
            self.door_open = True
        if self.door_open and p.x + p.w >= W - 10 and not self.test_mode:
            self.finish_room()
            return

        if self.endless is not None:   # камера плавно идёт за героем
            want = p.x + p.w / 2 - W / 2 + p.face * 60
            self.cam += (want - self.cam) * min(1.0, dt * 6)
            self.cam = max(0.0, min(self.ww - W, self.cam))

        if p.focus and not self.focus_used and 0 < p.hp <= 1:   # Приколист 5-го уровня: «Фокус» на последнем сердце
            self.focus_used = True
            for t in self.targets():
                t.stun_t = max(t.stun_t, 1.5 if not isinstance(t, Zombie) else 3.0)
            self.fx.append({"type": "ring", "x": p.x + p.w / 2, "y": p.y + 30, "t": 0.0})
            self.add_shake(5, 0.3)
            self.msg = ["Фокус! Все замерли", 2.0]
        if self.streak_t > 0:   # серия убийств Геймера гаснет, если 3 секунды никого не убил
            self.streak_t -= dt
            if self.streak_t <= 0:
                self.streak = 0
        if p.hp <= 0 and p.revive and not self.revive_used:   # Геймер 5-го уровня: «Продолжить?»
            self.revive_used = True
            p.hp, p.hurt_cd = 1, 2.5
            self.puff(p.x + p.w / 2, p.y + 20, 14, (255, 235, 120))
            self.sparkle(p.x + p.w / 2, p.y + 10)
            self.msg = ["Продолжить! Лишняя жизнь", 3.0]
        if p.hp <= 0:
            self.over = True
            if self.endless is not None:
                self.finish_endless()
            prefs.save()

    # ---------- рисование (пиксельное) ----------
    def draw(self, s, font, big):
        if self.sprites is None:
            self.sprites = SpriteSet()
            self.sprites.set_skin(prefs.get("skin"))
        sp = self.sprites
        if self.state == "menu":
            self.menu.draw(s, font, big)
            return
        if self.state == "map":
            wname = self.player.weapon["name"]
            if self.player.uses is not None:
                wname += f" x{self.player.uses}"
            if self.chapter == 3:
                story_map.draw_story_map(s, self.chapter, self.room_status, self.selected, len(self.cleared),
                                         self.map_msg[0] if self.map_msg else None, wname, self.player.hp, sp,
                                         self.player.max_hp)
            elif self.chapter == 2:
                draw_map2(s, self.room_status, self.selected, len(self.cleared),
                          self.map_msg[0] if self.map_msg else None, wname, self.player.hp, sp, self.player.max_hp)
            else:
                draw_map(s, self.room_status, self.selected, len(self.cleared),
                         self.map_msg[0] if self.map_msg else None, wname, self.player.hp, sp, self.has_key,
                         self.player.max_hp)
            pygame.draw.rect(s, (44, 58, 100), MENU_BTN, border_radius=8)
            pygame.draw.rect(s, (200, 205, 225), MENU_BTN, 3, border_radius=8)
            label = font.render("Меню" if touch.enabled else "Меню (Esc)", True, (255, 255, 255))
            s.blit(label, label.get_rect(center=MENU_BTN.center))
            self.draw_toast(s, font)
            return
        if self.state == "cutscene":
            self.draw_cutscene(s, font)
            return
        if self.endless is not None:   # арена шире экрана: рисуем на широкой картинке и показываем кусок под камерой
            if self.world is None:
                self.world = pygame.Surface((self.ww, H))
            self.world.set_clip(pygame.Rect(int(self.cam), 0, W, H))
            self.draw_world(self.world, sp)
            s.blit(self.world, (0, 0), pygame.Rect(int(self.cam), 0, W, H))
        else:
            self.draw_world(s, sp)
        tick = pygame.time.get_ticks()
        tint = self.room.get("tint", 0) if self.chapter == 2 else 0
        if tint:  # магазин ночью: полумрак
            if tint not in _NIGHT:
                _NIGHT[tint] = pygame.Surface((W, H), pygame.SRCALPHA)
                _NIGHT[tint].fill((6, 10, 40, tint))
            s.blit(_NIGHT[tint], (0, 0))
        if self.overlay is not None and prefs.get("light"):  # лучи света из окон и тёмные края
            s.blit(self.overlay, (0, 0))
        if prefs.get("light"):
            draw_motes(s, self.motes, tick / 1000)
        self.apply_shake(s)
        if self.hurt_flash > 0:  # красная вспышка по краям
            flash = red_vignette()
            flash.set_alpha(int(255 * min(1.0, self.hurt_flash / 0.35)))
            s.blit(flash, (0, 0))

        if self.mods is not None:
            self.mods.draw_screen(self, s)

        # интерфейс: тёмная полоса сверху, чтобы текст читался на любом фоне
        bar = pygame.Surface((W, 52), pygame.SRCALPHA)
        bar.fill((20, 20, 30, 170))
        s.blit(bar, (0, 0))
        for i in range(self.player.max_hp):
            img = sp.heart if i < self.player.hp else sp.heart_empty
            s.blit(img, (16 + i * 32, 16))
        white = (255, 255, 255)
        if self.endless is not None:
            title = f"Волна {self.endless.wave}"
        else:
            title = info_of(self.current)["name"] if self.current else ""
        if self.round > 1:
            title += f"  ·  круг {self.round}"
        tx = 16 + self.player.max_hp * 32 + 24
        if self.has_key:  # значок ключа рядом с сердцами
            s.blit(sp.key, (tx - 10, 17))
            tx += 52
        s.blit(font.render(title + ("" if touch.enabled or self.endless is not None else "   (M — карта)"), True, white), (tx, 14))
        p = self.player
        wname = p.weapon["name"] + (f" x{p.uses}" if p.uses is not None else "")
        if p.two_slots:  # второе место под оружие
            wname += f" [{'Смена' if touch.enabled else 'Q'}: {p.alt[0]['name']}]"
        left_over = len(self.zombies) + (self.endless.left if self.endless is not None else 0)
        right = font.render(f"{wname}  |  Зомби: {left_over}", True, white)
        s.blit(right, (W - right.get_width() - 16, 10))
        coins = pixel_font(16).render(f"{prefs.get('coins')}", True, (255, 225, 120))
        cx = W - coins.get_width() - 16
        s.blit(coins, (cx, 34))
        pygame.draw.circle(s, INK, (cx - 12, 43), 7)
        pygame.draw.circle(s, (245, 205, 70), (cx - 12, 43), 5)
        if self.endless is not None:   # рекорд и яд под сердцами
            self.outlined_pair(s, "Рекорд", self.endless.best, 16, 58, (255, 225, 120))
            if self.mods.poison_t > 0:
                self.outlined_pair(s, "Яд", int(self.mods.poison_t) + 1, 16, 80, (130, 235, 90))
        if self.school:  # вместо полоски босса — сколько ещё держаться
            left = max(0.0, SCHOOL_TIME - self.school["t"])
            bar = pygame.Rect(W // 2 - 220, 62, 440, 18)
            pygame.draw.rect(s, INK, bar.inflate(6, 6))
            pygame.draw.rect(s, (70, 40, 20), bar)
            pygame.draw.rect(s, (255, 170, 50), (bar.x, bar.y, int(bar.w * left / SCHOOL_TIME), bar.h))
            text = f"ШКОЛА ПРОТИВ ТЕБЯ — продержись: {int(left) + 1} с"
            label, shadow = font.render(text, True, (255, 255, 255)), font.render(text, True, INK)
            pos = label.get_rect(midtop=(W // 2, 84))
            for ox, oy in ((-2, 0), (2, 0), (0, -2), (0, 2)):
                s.blit(shadow, pos.move(ox, oy))
            s.blit(label, pos)
        if self.mini and self.mini.state != "dying":
            m = self.mini
            bar = pygame.Rect(W // 2 - 220, 62, 440, 18)
            pygame.draw.rect(s, INK, bar.inflate(6, 6))
            pygame.draw.rect(s, (90, 30, 40), bar)
            pygame.draw.rect(s, (230, 60, 80), (bar.x, bar.y, int(bar.w * max(0, m.hp) / m.maxhp), bar.h))
            for k in (1, 2):  # три головы — три части полоски
                pygame.draw.rect(s, INK, (bar.x + bar.w * k // 3 - 2, bar.y - 3, 4, bar.h + 6))
            text = "БОРЯН + ТОЛЯН + КОЛЯН"
            label, shadow = font.render(text, True, (255, 255, 255)), font.render(text, True, INK)
            pos = label.get_rect(midtop=(W // 2, 84))
            for ox, oy in ((-2, 0), (2, 0), (0, -2), (0, 2)):
                s.blit(shadow, pos.move(ox, oy))
            s.blit(label, pos)
        if self.final and self.final.state != "dying":
            f = self.final
            bar = pygame.Rect(W // 2 - 220, 62, 440, 18)
            pygame.draw.rect(s, INK, bar.inflate(6, 6))
            pygame.draw.rect(s, (90, 30, 40), bar)
            pygame.draw.rect(s, (230, 60, 80), (bar.x, bar.y, int(bar.w * max(0, f.hp) / f.maxhp), bar.h))
            text = "ШКОЛА — бей по упавшему колоколу!" if f.state in ("drop", "vuln") else "ШКОЛА — уворачивайся!"
            label, shadow = font.render(text, True, (255, 255, 255)), font.render(text, True, INK)
            pos = label.get_rect(midtop=(W // 2, 84))
            for ox, oy in ((-2, 0), (2, 0), (0, -2), (0, 2)):
                s.blit(shadow, pos.move(ox, oy))
            s.blit(label, pos)
        if self.boss and self.boss.state not in ("dying", "hide"):
            b = self.boss
            bar = pygame.Rect(W // 2 - 220, 62, 440, 18)
            pygame.draw.rect(s, INK, bar.inflate(6, 6))
            pygame.draw.rect(s, (90, 30, 40), bar)
            pygame.draw.rect(s, (230, 60, 80), (bar.x, bar.y, int(bar.w * max(0, b.hp) / b.maxhp), bar.h))
            bname = {"queen": "КОРОЛЕВА ЧЕРВЕЙ", "driver": "ЗОМБИ-МАШИНИСТ"}.get(self.boss.kind, "ДИРЕКТОР-ЗОМБИ")
            label = font.render(bname, True, (255, 255, 255))
            shadow = font.render(bname, True, INK)
            pos = label.get_rect(midtop=(W // 2, 84))
            for ox, oy in ((-2, 0), (2, 0), (0, -2), (0, 2)):
                s.blit(shadow, pos.move(ox, oy))
            s.blit(label, pos)
        if self.train is not None:
            self.train.draw_hud(s, font)
        if self.msg:
            txt = font.render(self.msg[0], True, (255, 255, 255))
            r = txt.get_rect(center=(W // 2, 150)).inflate(24, 12)
            pygame.draw.rect(s, INK, r, border_radius=8)
            s.blit(txt, txt.get_rect(center=r.center))
        if self.door_open and self.train is None:
            s.blit(font.render("Дверь открыта! Беги вправо", True, (255, 255, 255)), (W // 2 - 140, 62))
        self.draw_toast(s, font)
        near = self.weapon_item_near()
        if near and not self.over:
            name = WEAPONS[near["kind"]]["name"]
            txt = font.render((f"Нажми ВЗЯТЬ: {name}" if touch.enabled else f"E — взять: {name}"), True, (255, 255, 255))
            box = txt.get_rect(midbottom=(near["rect"].centerx - int(self.cam), near["rect"].top - 12)).inflate(16, 8)
            box.clamp_ip(s.get_rect())
            pygame.draw.rect(s, INK, box, border_radius=6)
            s.blit(txt, txt.get_rect(center=box.center))
        if self.over:
            shade = pygame.Surface((W, H), pygame.SRCALPHA)
            shade.fill((0, 0, 0, 150))
            s.blit(shade, (0, 0))
            t = big.render("Зомби победили", True, (255, 255, 255))
            s.blit(t, (W // 2 - t.get_width() // 2, 200))
            if self.endless is not None:
                self.draw_endless_result(s, font)
            else:
                t = font.render(f"Зачищено комнат: {len(self.cleared)}.", True, (255, 255, 255))
                s.blit(t, (W // 2 - t.get_width() // 2, 270))
            if not touch.enabled:
                hard = prefs.get("mode") == "hardcore"
                hint = "Хардкор: R — всё сначала.   Esc — меню" if hard else "Enter или R — эту комнату заново.   Esc — меню"
                if self.endless is not None:
                    hint = "Enter или R — ещё раз.   Esc — меню"
                t = pixel_font(20).render(hint, True, (200, 205, 220))
                s.blit(t, (W // 2 - t.get_width() // 2, 425 if self.endless is not None else 310))
        if self.state == "win":
            shade = pygame.Surface((W, H), pygame.SRCALPHA)
            shade.fill((0, 0, 0, 150))
            s.blit(shade, (0, 0))
            if self.chapter == 3:
                t = big.render("ХЭППИ-ЭНД!", True, (255, 235, 120))
                s.blit(t, (W // 2 - t.get_width() // 2, 180))
                t = font.render("Поезд остановился в Пусане. Бабушка ждёт на перроне. Конец главы 3.", True, (255, 255, 255))
                s.blit(t, (W // 2 - t.get_width() // 2, 265))
                t = font.render("Тапни или нажми Enter, чтобы вернуться в меню" if touch.enabled
                                else "Enter: вернуться в меню", True, (255, 255, 255))
                s.blit(t, (W // 2 - t.get_width() // 2, 310))
                return
            if self.chapter == 2:
                t = big.render("ХЭППИ-ЭНД!", True, (255, 235, 120))
                s.blit(t, (W // 2 - t.get_width() // 2, 180))
                t = font.render("Ты победил королеву червей. Мегамаркет снова открыт. Конец главы 2.", True, (255, 255, 255))
                s.blit(t, (W // 2 - t.get_width() // 2, 265))
                t = font.render("Тапни или нажми Enter, чтобы вернуться в меню" if touch.enabled
                                else "Enter: вернуться в меню", True, (255, 255, 255))
                s.blit(t, (W // 2 - t.get_width() // 2, 310))
                return
            t = big.render("ПОБЕДА!", True, (255, 235, 120))
            s.blit(t, (W // 2 - t.get_width() // 2, 180))
            t = font.render("Директор повержен, школа спасена.", True, (255, 255, 255))
            s.blit(t, (W // 2 - t.get_width() // 2, 265))
            t = font.render("Открыта глава 2 «Мегамаркет»: она в меню!", True, (150, 230, 120))
            s.blit(t, (W // 2 - t.get_width() // 2, 355))
            t = font.render((f"Тапни — новый круг ({self.round + 1}-й, зомби и босс сильнее)." if touch.enabled else
                             f"Enter — новый круг ({self.round + 1}-й, зомби и босс сильнее).  R — заново."),
                            True, (255, 255, 255))
            s.blit(t, (W // 2 - t.get_width() // 2, 310))

    def draw_world(self, s, sp):
        """Всё, что стоит и двигается в мире (на обычной комнате s — экран, на арене — широкая картинка)."""
        tick = pygame.time.get_ticks()
        if self.arena_bg is not None:
            s.blit(self.arena_bg, (0, 0))
        else:
            self.room["back"](s, self.variant)

        for rect, kind in self.furniture:
            draw_furn(s, rect, kind)
        if self.mods is not None:
            self.mods.draw_back(self, s)
        if self.train is not None:
            self.train.draw_back(s)   # хулиганы дерутся на заднем плане

        if self.school:
            self.draw_school_bg(s)

        if self.endless is None and self.train is None:   # дверь (на арене её нет, в вагонах она нарисована на фоне)
            door = pygame.Rect(W - 40, FLOOR - 112, 40, 112)
            pygame.draw.rect(s, INK, door)
            pygame.draw.rect(s, (90, 220, 120) if self.door_open else (120, 60, 60), door.inflate(-8, -8).move(4, 4))
            pygame.draw.rect(s, (250, 220, 60), (door.x + 8, door.centery, 8, 8))  # ручка

        tick = pygame.time.get_ticks()
        for item in self.pickups:
            bob = int(math.sin(tick / 200 + item["rect"].x) * 3)
            img = sp.pie if item["kind"] == "pie" else (sp.key if item["kind"] == "key" else (
                sp.market["wallet"] if item["kind"] == "wallet" else sp.weapon[item["kind"]][1]))
            pos = img.get_rect(midbottom=item["rect"].midbottom).move(0, bob - 4)
            s.blit(img, pos)
            if (tick // 350 + item["rect"].x) % 2:  # мигающая искорка
                pygame.draw.rect(s, (255, 240, 120), (pos.right - 4, pos.top - 6, 6, 6))
                pygame.draw.rect(s, (255, 255, 255), (pos.right - 2, pos.top - 4, 2, 2))

        self.draw_shadows(s)
        for c in self.corpses:
            self.draw_corpse(s, c)
        for z in self.zombies:
            if self.mods is not None and self.mods.ghost_hidden(z):
                continue
            self.draw_zombie(s, z)
        if self.boss:
            self.draw_boss(s)
        if self.mini:
            self.draw_mini(s)
        if self.final:
            self.draw_final(s)
        hazards = self.school["hazards"] if self.school else (self.final.sc["hazards"] if self.final else [])
        if hazards:
            self.draw_school_hazards(s, hazards)
        for pr in self.projectiles:
            if pr.get("kind") == "coin":  # монета, которую у тебя отобрали
                c = (int(pr["x"]), int(pr["y"]))
                pygame.draw.circle(s, INK, c, 10)
                pygame.draw.circle(s, (245, 205, 70), c, 7)
                pygame.draw.rect(s, (200, 150, 30), (c[0] - 1, c[1] - 4, 3, 8))
            elif pr.get("kind") == "wave":  # волна топота по полу
                x, y = int(pr["x"]), int(pr["y"])
                pts = [(x - 23, y + 18), (x, y - 18), (x + 23, y + 18)]
                pygame.draw.polygon(s, (170, 135, 95), pts)
                pygame.draw.polygon(s, INK, pts, 3)
            elif self.boss and self.boss.kind == "queen":  # королева плюётся кислотой
                c = (int(pr["x"]), int(pr["y"]))
                pygame.draw.circle(s, INK, c, 14)
                pygame.draw.circle(s, (120, 230, 70), c, 11)
                pygame.draw.circle(s, (200, 255, 150), (c[0] - 4, c[1] - 4), 4)
            else:
                card = pygame.transform.rotate(sp.card, pr["t"] * 360)
                s.blit(card, card.get_rect(center=(int(pr["x"]), int(pr["y"]))))
        for sh in self.shots:
            w = sh["w"]
            img = sp.proj[w["key"]]
            if w["type"] == "throw" and w.get("spin", True):
                img = pygame.transform.rotate(img, -sh["dir"] * sh["t"] * 600)
            elif sh["dir"] < 0:
                img = pygame.transform.flip(img, True, False)
            s.blit(img, img.get_rect(center=(int(sh["x"]), int(sh["y"]))))
        self.draw_fx(s)
        if self.mods is not None:
            self.mods.draw_front(self, s)
        if self.decoy:
            self.draw_decoy(s)
        self.draw_player(s)
        self.particles.draw(s)
        if self.train is not None:
            self.train.draw_dark(s)   # тоннель: темно, видно только вокруг героя

    def draw_toast(self, s, font):
        """Золотая плашка «Квест выполнен!» (видна и в бою, и на карте)."""
        if not self.toast:
            return
        txt = font.render(self.toast[0], True, (50, 38, 10))
        r = txt.get_rect(center=(W // 2, 205)).inflate(40, 18)
        pygame.draw.rect(s, INK, r.inflate(6, 6), border_radius=10)
        pygame.draw.rect(s, (255, 214, 90), r, border_radius=8)
        s.blit(txt, txt.get_rect(center=r.center))

    @staticmethod
    def outlined_pair(s, label, value, x, y, color):
        """Подпись и число с чёрной обводкой (читается на любом фоне, как подсказки в мире)."""
        f = pixel_font(16)
        a, b = f.render(label, True, color), f.render(f" {value}", True, color)
        sa, sb = f.render(label, True, INK), f.render(f" {value}", True, INK)
        for ox, oy in ((-2, 0), (2, 0), (0, -2), (0, 2)):
            s.blit(sa, (x + ox, y + oy))
            s.blit(sb, (x + sa.get_width() + ox, y + oy))
        s.blit(a, (x, y))
        s.blit(b, (x + a.get_width(), y))

    @staticmethod
    def blit_pair(s, font, label, value, y, color=(255, 255, 255)):
        """Подпись и число рядом по центру (число рисуем отдельно, чтобы подпись переводилась)."""
        a, b = font.render(label, True, color), font.render(f" {value}", True, color)
        x = W // 2 - (a.get_width() + b.get_width()) // 2
        s.blit(a, (x, y))
        s.blit(b, (x + a.get_width(), y))

    def draw_endless_result(self, s, font):
        e = self.endless
        self.blit_pair(s, font, "Ты дошёл до волны", e.wave, 282)
        self.blit_pair(s, font, "Убито врагов", e.kills, 315)
        self.blit_pair(s, font, "Рекорд", e.best, 348, (255, 225, 120))
        if e.new_record:
            t = font.render("Новый рекорд!", True, (150, 230, 120))
            s.blit(t, (W // 2 - t.get_width() // 2, 384))

    def draw_player(self, s):
        p = self.player
        sp = self.sprites
        if p.hurt_cd > 0 and int(p.hurt_cd * 20) % 2:
            return  # мигает после удара
        r = p.rect
        if not p.on_ground:
            name = "jump"
        elif abs(p.vx) > 1:
            kind, step = ("run", STEP_RUN) if p.running else ("walk", STEP_WALK)
            name = f"{kind}{int(p.anim / step) % 4}"
        else:
            name = "idle"
        img = sp.player[name]
        if p.face < 0:
            img = pygame.transform.flip(img, True, False)
        s.blit(img, (r.x - SPRITE_PAD, r.bottom - img.get_height()))

        key, kind = p.weapon["key"], p.weapon["type"]
        if p.shield_t > 0:  # тетрадь поднята перед героем
            shield = sp.weapon["notebook"][0]
            s.blit(shield, shield.get_rect(center=(r.centerx + p.face * 30, r.y + 32)))
        elif kind == "melee":
            if p.swing > 0:
                a = p.attack_rect()
                if key != "fists":
                    big_img = sp.weapon[key][0]
                    if p.face < 0:
                        big_img = pygame.transform.flip(big_img, True, False)
                    s.blit(big_img, (a.x, a.y + 8))
                else:
                    fist = sp.fist
                    fx = a.right - fist.get_width() if p.face > 0 else a.left
                    s.blit(fist, (fx, a.y + 12))
            elif key != "fists":
                held = pygame.transform.rotate(sp.weapon[key][1], 60 if p.face > 0 else 120)
                s.blit(held, held.get_rect(center=(r.centerx + p.face * 24, r.y + 28)))
            else:
                fist = sp.fist
                s.blit(fist, (r.centerx + p.face * 22 - fist.get_width() // 2, r.y + 32))
        else:  # стреляет, кидает, звонок, тетрадь опущена — держит перед собой
            img = sp.weapon[key][1]
            if p.face < 0:
                img = pygame.transform.flip(img, True, False)
            kick = -p.face * 4 if p.swing > 0 else 0  # отдача
            hand = (r.centerx + p.face * 16 + kick, r.y + 34)
            s.blit(img, img.get_rect(midleft=hand) if p.face > 0 else img.get_rect(midright=hand))

    def draw_school_bg(self, s):
        """Школа ожила: фон краснеет, сверху и снизу — зубы."""
        t = pygame.time.get_ticks() / 1000
        tint = pygame.Surface((W, H), pygame.SRCALPHA)
        tint.fill((120, 10, 20, 70))
        s.blit(tint, (0, 0))
        open_ = 14 + int(math.sin(t * 2.2) * 10)
        for x in range(-24, W, 48):
            pts = [(x, 52), (x + 48, 52), (x + 24, 52 + 36 + open_)]
            pygame.draw.polygon(s, (240, 240, 228), pts)
            pygame.draw.polygon(s, INK, pts, 3)
        for x in range(0, W, 48):
            pts = [(x, FLOOR), (x + 48, FLOOR), (x + 24, FLOOR - 30 - open_ // 2)]
            pygame.draw.polygon(s, (240, 240, 228), pts)
            pygame.draw.polygon(s, INK, pts, 3)

    def draw_school_hazards(self, s, hazards):
        sp = self.sprites
        blink = int(pygame.time.get_ticks() / 90) % 2
        for hz in hazards:
            if hz["type"] == "drop":
                if hz["warn"] > 0:  # красная тень на полу и стрелка сверху
                    if blink:
                        pygame.draw.rect(s, (235, 60, 60), (hz["x"] - 36, FLOOR - 6, 72, 6))
                        pygame.draw.polygon(s, (235, 60, 60), [(hz["x"] - 14, 62), (hz["x"] + 14, 62), (hz["x"], 88)])
                else:
                    img = sp.school[hz["kind"]]
                    s.blit(img, img.get_rect(midtop=(hz["x"], int(hz["y"]))))
            else:
                if hz["warn"] > 0:  # красная стрелка у края, откуда прилетит
                    if blink:
                        ex = 20 if hz["dir"] > 0 else W - 20
                        pts = [(ex, FLOOR - 50), (ex, FLOOR - 10), (ex + 30 * hz["dir"], FLOOR - 30)]
                        pygame.draw.polygon(s, (235, 60, 60), pts)
                else:
                    img = sp.school["desk"]
                    s.blit(img, (int(hz["x"]) - 35, int(hz["y"])))

    def draw_final(self, s):
        """Колокол школы: висит на верёвке, падает на пол, и тогда его можно бить."""
        sp, f = self.sprites, self.final
        r, t = f.rect, pygame.time.get_ticks() / 1000
        shake = random.choice((-4, 4)) if f.state == "dying" else 0
        cx = r.centerx + shake
        pygame.draw.line(s, INK, (cx, 0), (cx, r.top + 8), 8)  # верёвка
        pygame.draw.line(s, (205, 175, 105), (cx, 0), (cx, r.top + 8), 4)
        if f.state in ("drop", "vuln"):  # золотое свечение: сейчас можно бить
            aura = pygame.Surface((160, 160), pygame.SRCALPHA)
            pygame.draw.circle(aura, (255, 230, 90, 90), (80, 80), 60 + int(math.sin(t * 8) * 8))
            s.blit(aura, aura.get_rect(center=r.center))
        img = sp.big_bell_flash if f.flash > 0 else sp.big_bell
        if f.state == "dying" and f.t > 1.0:
            img = img.copy()
            img.set_alpha(int(255 * max(0.0, 1 - (f.t - 1.0))))
        s.blit(img, img.get_rect(center=(cx, r.centery)))
        if f.state == "vuln" and int(t * 6) % 2:  # красная стрелка над колоколом
            pygame.draw.polygon(s, (235, 60, 60), [(cx - 16, r.top - 44), (cx + 16, r.top - 44), (cx, r.top - 14)])

    def draw_mini(self, s):
        sp, m = self.sprites, self.mini
        r = m.rect
        mask = {3: "111", 2: "110", 1: "100"}[m.heads]
        if m.state == "dying":
            img = sp.mini[f"walk0_{mask}"]
            img = pygame.transform.rotate(img, -90 * (-m.face) * min(1.0, m.t / 0.5))
            if m.t > 0.9:
                img.set_alpha(int(255 * max(0.0, 1 - (m.t - 0.9) / 0.6)))
            s.blit(img, img.get_rect(midbottom=(r.centerx, r.bottom)))
            return
        if m.state in ("w_charge", "w_coins", "w_stomp", "charge"):
            pose = "attack"
        else:
            pose = "walk0" if int(m.anim / 24) % 2 == 0 else "walk1"
        key = f"{pose}_{mask}" + ("_flash" if m.flash > 0 else "")
        img = sp.mini[key]
        dx = random.choice((-4, 4)) if m.state == "w_charge" else 0  # трясётся перед рывком
        s.blit(img, img.get_rect(midbottom=(r.centerx + dx, r.bottom)))
        if m.state == "tired" or m.stun_t > 0:
            self.draw_stars(s, r.centerx, r.y - 20)

    def draw_stars(self, s, cx, top):
        """Звёздочки над оглушённым."""
        for i in range(3):
            a = pygame.time.get_ticks() / 250 + i * 2.1
            pygame.draw.rect(s, (255, 235, 90), (cx + int(math.cos(a) * 24) - 3, top - 8 + int(math.sin(a) * 6), 6, 6))

    def draw_fx(self, s):
        for e in self.fx:
            t = e["t"]
            if e["type"] == "boom":
                r = max(2, int(e["R"] * min(1.0, t / 0.12)))
                fade = max(0.0, 1 - t / 0.45)
                surf = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
                pygame.draw.circle(surf, (255, 150, 40, int(190 * fade)), (r, r), r)
                pygame.draw.circle(surf, (255, 235, 120, int(230 * fade)), (r, r), max(1, int(r * 0.6)))
                s.blit(surf, (int(e["x"]) - r, int(e["y"]) - r))
            elif e["type"] == "hit":  # быстрое кольцо в месте удара
                r = int(8 + 20 * min(1.0, t / 0.16))
                if t < 0.16:
                    pygame.draw.circle(s, (255, 255, 255), (int(e["x"]), int(e["y"])), r, 3)
            else:  # волна от звонка
                r = int(560 * min(1.0, t / 0.4))
                if r > 4:
                    pygame.draw.circle(s, (255, 225, 90), (int(e["x"]), int(e["y"])), r, 6)

    def draw_decoy(self, s):
        """Игрушка пони скачет по комнате."""
        d = self.decoy
        img = self.sprites.market["pony"]["a" if int(d["anim"] * 8) % 2 == 0 else "b"]
        if d["dir"] < 0:
            img = pygame.transform.flip(img, True, False)
        s.blit(img, img.get_rect(midbottom=(int(d["x"]), FLOOR + 2)))

    def draw_enemy(self, s, z):
        """Червяки, куры, коровы, барашки и мимики (глава 2)."""
        r = z.rect
        frame = "a" if int(z.anim / 16) % 2 == 0 else "b"
        if z.flash > 0:
            frame += "_flash"
        img = self.sprites.market[z.kind][frame]
        if z.face < 0:
            img = pygame.transform.flip(img, True, False)
        s.blit(img, img.get_rect(midbottom=(r.centerx, r.bottom + 4)))
        if z.stun_t > 0:
            self.draw_stars(s, r.centerx, r.y)

    def draw_zombie(self, s, z):
        if z.kind not in ("zombie", "runner"):
            self.draw_enemy(s, z)
            return
        sp = self.sprites
        r = z.rect
        if z.bite_cd > 0.75:
            frame = "bite"  # только что укусил
        elif not z.on_ground:
            frame = "walk1"
        else:
            frame = f"walk{int(z.anim / 18) % 4}"
        if z.flash > 0:
            frame += "_flash"
        img = (sp.zombie_v["red"] if z.kind == "runner" else sp.zombie)[frame]   # быстрые заражённые в красном
        if z.face > 0:
            s.blit(img, (r.centerx - 24, r.bottom - img.get_height()))
        else:
            s.blit(pygame.transform.flip(img, True, False), (r.centerx - 28, r.bottom - img.get_height()))
        if z.stun_t > 0:
            self.draw_stars(s, r.centerx, r.y)
        elif z.slow_t > 0:  # замедлен пеной — белые пузырьки
            for i in range(3):
                bx = r.x + 6 + i * 12
                pygame.draw.rect(s, (235, 245, 255), (bx, r.y - 6 - (pygame.time.get_ticks() // 200 + i) % 3 * 3, 6, 6))

    def boss_frames(self, b):
        """Картинки босса: королева червей, консьерж или директор."""
        sp = self.sprites
        return sp.market["queen"] if b.kind == "queen" else sp.boss_styles.get(b.kind, sp.boss)

    def draw_boss(self, s):
        sp, b = self.sprites, self.boss
        r = b.rect
        if b.state == "hide":
            return
        if b.state == "dying":
            img = self.boss_frames(b)["walk1"]
            if b.face < 0:
                img = pygame.transform.flip(img, True, False)
            fall = -b.face  # падает спиной вперёд
            img = pygame.transform.rotate(img, -90 * fall * min(1.0, b.t / 0.4))
            if b.t > 0.8:
                img.set_alpha(int(255 * (1 - (b.t - 0.8) / 0.6)))
            s.blit(img, img.get_rect(midbottom=(r.centerx, r.bottom)))
            return
        if b.state == "throw":
            name = "throw"
        elif b.state in ("windup", "charge"):
            name = "charge"
        elif b.state == "tired" or b.stun_t > 0:
            name = "walk1"
        else:
            name = f"walk{int(b.anim / 26) % 4}"
        if b.flash > 0 or (b.state == "windup" and int(b.t * 14) % 2):
            name += "_flash"  # белая вспышка при ударе; мигает перед тараном
        img = self.boss_frames(b)[name]
        dx = random.choice((-4, 4)) if b.state == "windup" else 0  # трясётся
        if b.kind == "queen":
            if b.face < 0:
                img = pygame.transform.flip(img, True, False)
            s.blit(img, img.get_rect(midbottom=(r.centerx + dx, r.bottom + 4)))
        elif b.face > 0:
            s.blit(img, (r.centerx - 36 + dx, r.bottom - img.get_height()))
        else:
            s.blit(pygame.transform.flip(img, True, False), (r.centerx - 42 + dx, r.bottom - img.get_height()))
        if b.state == "tired" or b.stun_t > 0:
            self.draw_stars(s, r.centerx, r.y)

    def draw_actor(self, s, a, cx, moving):
        sp, face, kind, pose = self.sprites, a["face"], a["kind"], a.get("pose")
        if kind == "hero" or kind in sp.humans:  # люди: ты, три хулигана, девочка
            frames = sp.player if kind == "hero" else sp.humans[kind]
            if pose == "fallen":
                img = frames["idle"]
                if face < 0:
                    img = pygame.transform.flip(img, True, False)
                img = pygame.transform.rotate(img, 90 * face)  # лежит на асфальте
                s.blit(img, img.get_rect(midbottom=(cx, FLOOR)))
                return
            img = frames[f"walk{int(abs(cx) / 30) % 4}" if moving else "idle"]
            if face < 0:
                img = pygame.transform.flip(img, True, False)
            s.blit(img, (cx - img.get_width() // 2, FLOOR - img.get_height()))
        elif kind in ("worm", "chicken", "cow", "lamb", "mimic", "queen", "pony"):  # враги и игрушка главы 2
            frames = sp.market[kind]
            img = frames["walk0"] if kind == "queen" else frames["a"]
            if face < 0:
                img = pygame.transform.flip(img, True, False)
            s.blit(img, img.get_rect(midbottom=(cx, FLOOR + 4)))
        elif kind == "mini":
            img = sp.mini[("attack" if pose == "attack" else "walk0") + "_111"]
            s.blit(img, img.get_rect(midbottom=(cx, FLOOR)))
        elif kind == "zombie":
            frames = sp.zombie_v.get(a.get("color"), sp.zombie)
            frame = "bite" if pose == "bite" else (f"walk{int(cx / 18) % 4}" if moving else "walk1")
            img = frames[frame]
            if face > 0:
                s.blit(img, (cx - 24, FLOOR - img.get_height()))
            else:
                s.blit(pygame.transform.flip(img, True, False), (cx - 28, FLOOR - img.get_height()))
        else:  # boss
            if pose == "fallen":
                img = sp.boss_styles.get(kind, sp.boss)["walk1"]
                if face < 0:
                    img = pygame.transform.flip(img, True, False)
                img = pygame.transform.rotate(img, 90 * face)  # лежит на спине
                s.blit(img, img.get_rect(midbottom=(cx, FLOOR)))
                return
            name = pose if pose in ("throw", "charge") else (f"walk{int(cx / 26) % 4}" if moving else "walk1")
            img = sp.boss_styles.get(kind, sp.boss)[name]
            if face > 0:
                s.blit(img, (cx - 36, FLOOR - img.get_height()))
            else:
                s.blit(pygame.transform.flip(img, True, False), (cx - 42, FLOOR - img.get_height()))

    def draw_cutscene(self, s, font):
        cut = self.cut
        scene = cut["scene"]
        kind, variant = scene["bg"]
        theme = THEMES[kind]
        theme["back"](s, variant)
        for rect, fk in theme["build"](variant):
            draw_furn(s, rect, fk)
        tint = 0 if (kind == "street" and variant == 1) else theme.get("tint", 0)
        if tint:  # ночные сцены темнее
            shade = pygame.Surface((W, H), pygame.SRCALPHA)
            shade.fill((2, 4, 20, tint))
            s.blit(shade, (0, 0))
        beat = scene["beats"][cut["i"]]
        t = cut["t"]
        prog = min(1.0, t / 1.2)
        base_w = {"mini": 120, "boss": 92, "driver": 92, "grandma": 62, "zombie": 56, "queen": 150, "cow": 100, "lamb": 70, "chicken": 50,
                  "worm": 60, "pony": 60}
        for a in cut["actors"]:  # тени под ногами
            if a.get("pose") != "fallen":
                draw_shadow(s, a["x"] + (a["to"] - a["x"]) * prog, FLOOR, FLOOR, base_w.get(a["kind"], 62))
        for a in cut["actors"]:
            self.draw_actor(s, a, a["x"] + (a["to"] - a["x"]) * prog, a["to"] != a["x"] and prog < 1.0)
        if prefs.get("light"):
            beams = theme.get("beams", [])
            s.blit(make_overlay(beams), (0, 0))
            if kind not in self.cut_motes:
                self.cut_motes[kind] = make_motes(beams, 22, seed=3)
            draw_motes(s, self.cut_motes[kind], pygame.time.get_ticks() / 1000)

        # чёрные полосы, как в кино
        pygame.draw.rect(s, (0, 0, 0), (0, 0, W, 36))
        pygame.draw.rect(s, (0, 0, 0), (0, H - 36, W, 36))

        # подпись: имя и текст, который «печатается»
        who, text = beat.get("who", ""), i18n.tr(beat["text"])  # перевод до разбивки на строки
        words, lines, cur = text.split(" "), [], ""
        for w in words:
            trial = (cur + " " + w).strip()
            if font.size(trial)[0] > W - 80:
                lines.append(cur)
                cur = w
            else:
                cur = trial
        lines.append(cur)
        box_h = 24 + (30 if who else 0) + len(lines) * 30
        box = pygame.Surface((W - 40, box_h), pygame.SRCALPHA)
        box.fill((15, 15, 25, 228))
        s.blit(box, (20, 46))
        pygame.draw.rect(s, (255, 255, 255), (20, 46, W - 40, box_h), 2)
        y = 56
        if who:
            s.blit(font.render(who, True, SPEAKERS.get(who, (255, 255, 255))), (36, y))
            y += 30
        left = int(t * TYPE_SPEED)
        for line in lines:
            s.blit(font.render(line[:max(0, left)], True, (255, 255, 255)), (36, y))
            left -= len(line) + 1
            y += 30
        small = pixel_font(16)
        done = int(t * TYPE_SPEED) >= len(text)
        hint = ("Тапни — дальше" if touch.enabled else "Enter / клик — дальше") if done else "Enter — показать всё"
        tip = small.render(i18n.tr(hint) + ("" if touch.enabled else i18n.tr("      Esc — пропустить")), True, (200, 205, 220))
        s.blit(tip, tip.get_rect(midbottom=(W // 2, H - 8)))

    def draw_corpse(self, s, c):
        t = c["t"]
        kind = c.get("kind", "zombie")
        if kind == "zombie":
            img = self.sprites.zombie["walk1_flash" if t < 0.12 else "walk1"]
        elif kind == "runner":   # быстрый заражённый (глава 3) — в красном
            img = self.sprites.zombie_v["red"]["walk1_flash" if t < 0.12 else "walk1"]
        else:
            img = self.sprites.market[kind]["a_flash" if t < 0.12 else "a"]
        if c["face"] < 0:
            img = pygame.transform.flip(img, True, False)
        angle = -90 * c["fall"] * min(1.0, t / 0.3)  # падает в сторону удара
        img = pygame.transform.rotate(img, angle)
        if t > 0.5:
            img.set_alpha(int(255 * (1 - (t - 0.5) / (CORPSE_TIME - 0.5))))
        s.blit(img, img.get_rect(midbottom=(c["cx"], c["bottom"])))


async def main():
    pygame.init()
    screen = pygame.display.set_mode((W, H))
    pygame.display.set_caption("Зомби-школа")
    font = pixel_font(24)
    big = pixel_font(64)
    clock = pygame.time.Clock()
    if "--all" in sys.argv:  # python game.py --all: всё открыто для проверки (прогресс не сохраняется)
        prefs.READONLY = True
        from sprites import SKINS
        prefs.data.update(coins=9999, owned_skins=list(SKINS), owned_classes=list(classes.CLASSES), ch1_done=True,
                          ch2_done=True)
    apply_prefs()
    refund = 0 if prefs.READONLY else classes.migrate()   # классы подешевели: вернуть тем, кто купил дороже
    game = Game()
    if "--test" in sys.argv:  # python game.py --test — проверка оружия
        game.test_mode, game.cutscenes = True, False
        game.start_room("c1")
        game.msg = ["Режим проверки: Q — следующее оружие", 3.0]
    elif "--boss" in sys.argv:  # python game.py --boss — сразу к директору, с дубиной в руках
        game.player.weapon = CLUB
        game.play_scene("boss_intro", ("room", "office"))
    elif "--mini" in sys.argv:  # python game.py --mini — сразу мини-босс (Класс 7)
        game.cutscenes = False
        game.player.weapon = CLUB
        game.start_room("c7")
    elif "--final" in sys.argv:  # python game.py --final — сразу финал со школой
        game.cutscenes = False
        game.player.weapon = CLUB
        game.start_room("school")
    elif "--school" in sys.argv:  # python game.py --school — сразу «ты против школы» (круг 2, у босса 50%)
        game.round, game.cutscenes = 2, False
        game.player.weapon = CLUB
        game.start_room("office")
        game.boss.hp = game.boss.maxhp // 2
    elif "--driver" in sys.argv:  # python game.py --driver — сразу босс поезда (зомби-машинист), глава 3
        game.chapter, game.cutscenes = 3, False
        game.start_room("cab")
        game.train.wave = len(game.train.cfg["waves"])   # враги кончились: сразу выходит машинист
    elif "--endless" in sys.argv:  # python game.py --endless — сразу бесконечный режим (модификаторы как в прошлый раз)
        import modifiers
        picked = [k for k in prefs.get("endless_mods") if k in modifiers.BY_KEY]
        game.start_endless(picked if len(picked) >= modifiers.MIN_PICK else modifiers.random_pick())
    else:
        game.show_menu()  # игра начинается с главного меню
    demo = None   # режим показа (demo.py): --demo, адрес с ?demo=1 или клавиша P в меню
    web_demo = False
    if sys.platform == "emscripten":
        try:
            import platform
            web_demo = "demo" in str(platform.window.location.search)
        except Exception:
            pass
    if "--demo" in sys.argv or web_demo:
        demo = demo_mode.Demo()
        demo.start(game)
    elif refund and game.state == "menu":
        game.menu.msg = [f"Классы подешевели: вернули {refund} монет!", 7.0]
    if any(a in sys.argv for a in ("--test", "--boss", "--mini", "--final", "--school", "--endless", "--driver")):
        game.started = True
    keys_map = (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN,
                pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE)
    def click(pos):
        """Нажатие мышью или пальцем в местах, где нет джойстика: карта, катсцена, победа, поражение."""
        if game.state == "menu":
            game.menu.click(pos)
        elif game.state == "map":
            if MENU_BTN.collidepoint(pos):
                game.show_menu()
                return
            game.map_hover(pos)
            game.map_click(pos)
        elif game.state == "cutscene":
            if touch.enabled and SKIP_RECT.collidepoint(pos):
                game.skip_scene()
            else:
                game.advance_scene()
        elif game.state == "win":
            if touch.enabled:
                game.next_round()
        elif game.over and touch.enabled and RESTART_RECT.collidepoint(pos):
            game.retry()
        elif game.over and touch.enabled and MENU_OVER_RECT.collidepoint(pos):
            game.show_menu()

    last_state = (None, None)
    frames, fps_t0, fps_value = 0, pygame.time.get_ticks(), 0.0
    while True:
        dt = clock.tick(FPS) / 1000
        if (game.state, game.over) != last_state:  # сменилась сцена — отпускаем кнопки на экране
            touch.reset()
            last_state = (game.state, game.over)
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if demo is not None:   # во время показа слушаем только Esc
                if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                    demo.stop(game)
                    demo = None
                continue
            if e.type == pygame.FINGERDOWN and not touch.enabled and prefs.get("buttons") == "auto":
                touch.enabled = True  # первое касание пальцем: показываем кнопки (на компьютере их нет)
            if touch.handle(e, game.state == "play" and not game.over):
                pass
            elif e.type == pygame.FINGERDOWN:
                click((e.x * W, e.y * H))
            elif e.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEMOTION) and getattr(e, "touch", False):
                pass  # копию мыши от пальца не берём: палец уже обработан выше
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                click(e.pos)
            elif e.type == pygame.MOUSEMOTION and game.state == "map":
                game.map_hover(e.pos)
            elif e.type == pygame.MOUSEMOTION and game.state == "menu":
                game.menu.hover(e.pos)
            key = e.key if e.type == pygame.KEYDOWN else None
            if game.state == "menu":
                if key is not None:
                    game.menu.key(key, getattr(e, "unicode", ""))
            elif key == pygame.K_r and game.state in ("play", "map", "win"):
                game.retry()
            elif key == pygame.K_ESCAPE and game.state in ("map", "play", "win"):
                game.show_menu()
            elif game.state == "map":
                if key in keys_map:
                    game.map_key(key)
            elif game.state == "cutscene":
                if key == pygame.K_ESCAPE:
                    game.skip_scene()
                elif key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                    game.advance_scene()
            elif game.state == "win":
                if key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    game.next_round()
            elif game.over and key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                game.retry()
            elif key == pygame.K_e:
                game.take_weapon()
            elif key == pygame.K_q and game.test_mode:
                game.cycle_weapon()
            elif key == pygame.K_q:
                game.swap_weapon()
            elif key == pygame.K_m:
                game.open_map()
            elif key == pygame.K_b and not game.over and game.endless is None:
                game.start_room("office")
        for act in touch.take_pending():
            if game.state == "play" and not game.over:
                if act == "take":
                    game.take_weapon()
                elif act == "map":
                    game.open_map()
                elif act == "menu":
                    game.show_menu()
                elif act == "swap":
                    game.swap_weapon()
        if game.demo_request and demo is None:   # P в главном меню
            game.demo_request = False
            demo = demo_mode.Demo()
            demo.start(game)
        if demo is not None:   # показ: героем и меню управляет сама игра
            demo_keys, mouse_down = demo.update(game, dt)
            game.update(dt, demo_keys, mouse_down)
            demo.after_update(game)
        else:
            mouse_down = pygame.mouse.get_pressed()[0] and not touch.enabled  # при кнопках на экране мышь не бьёт
            game.update(dt, MergedKeys(pygame.key.get_pressed()), mouse_down)
        game.draw(screen, font, big)
        if demo is not None:
            tag = pixel_font(16).render("Показ: Esc — выйти", True, (255, 255, 255))
            shadow = pixel_font(16).render("Показ: Esc — выйти", True, INK)
            for ox, oy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                screen.blit(shadow, (12 + ox, H - 26 + oy))
            screen.blit(tag, (12, H - 26))
        touch.two_slots = game.player.two_slots
        touch.map_enabled = True
        touch.take_label = game.train.take_label() if (game.train is not None and game.state == "play") else "ВЗЯТЬ"
        if demo is None:
            touch.draw(screen, game.state, game.over, "ЕЩЁ РАЗ" if prefs.get("mode") == "normal" else "ЗАНОВО")
        frames += 1
        now = pygame.time.get_ticks()
        if now - fps_t0 >= 1000:  # считаем кадры сами: в браузере clock.get_fps() показывает 0
            fps_value, frames, fps_t0 = frames * 1000 / (now - fps_t0), 0, now
        if prefs.get("fps"):
            label = pixel_font(16).render(f"FPS {fps_value:.0f}", True, (255, 255, 120))
            screen.blit(label, (W - label.get_width() - 8, H - label.get_height() - 6))
        pygame.display.flip()
        await asyncio.sleep(0)  # нужно для веб-версии (браузер), на компьютере ничего не меняет


if __name__ == "__main__":
    asyncio.run(main())
