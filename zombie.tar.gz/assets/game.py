"""Зомби-школа — этажи-комнаты для одного игрока.

Управление:
  A/D или стрелки — ходить
  Shift — бежать
  W / пробел / стрелка вверх — прыжок
  J или ЛКМ — ударить
  E — взять оружие с пола (старое останется лежать)
  R — заново
  B — сразу к боссу (проверить бой, не проходя классы)
Оружие бывает разное: бить, стрелять, кидать, щит, звонок. Список — в weapons.py.
M — карта школы (выбрать другую комнату)
Катсцены: Enter / клик — дальше, Esc — пропустить
Запуск сразу на боссе: python game.py --boss
Сразу «ты против школы» (круг 2, у босса 50%): python game.py --school
Сразу финал со школой: python game.py --final
Сразу мини-босс (три хулигана в одном теле): python game.py --mini
Режим проверки оружия: python game.py --test  (Q — следующее оружие, здоровье не кончается)
Пирожки подбираются сами (лечат на 1 сердце, если ты ранен).
Карта: Туалет (бонус), Классы 1-7 по порядку, потом Кабинет директора — босс, потом ФИНАЛ со школой.
В бою с боссом раз в 3 секунды 30% шанс, что тебе прилетит водяной пистолет (подбери на E).
"""
import asyncio
import math
import random
import sys

import pygame

from cutscenes import SCENES
from effects import (Particles, draw_motes, draw_shadow, ground_below, make_motes, make_overlay,
                     red_vignette)
from pixelfont import pixel_font
from rooms import THEMES, draw_furniture
from school_map import ROOM_BY_ID, draw_map, move_selection, room_at, MAP_ROOMS, ORDER
from settings import FLOOR, H, INK, W
from sprites import SpriteSet
from touch import MergedKeys, RESTART_RECT, SKIP_RECT, touch
from weapons import CLUB, FISTS, WEAPONS

GRAVITY = 2200
JUMP = -850
FPS = 60
WALK_SPEED = 220
RUN_SPEED = 360  # держи Shift
STEP_WALK = 30   # сколько пикселей пути — один кадр ходьбы
STEP_RUN = 40
CORPSE_TIME = 1.0  # сколько секунд лежит упавший зомби, пока не исчезнет
SPRITE_PAD = 4  # спрайт героя шире хитбокса на одну клетку слева и справа

ROUND_ZOMBIES = 3      # на сколько зомби больше в каждом следующем круге
ROUND_BOSS_HP = 20     # на сколько здоровья у босса больше в каждом круге
WATER_EVERY = 3.0      # раз в столько секунд в бою с боссом тебе может достаться водяной пистолет
WATER_CHANCE = 0.3     # ...с таким шансом (30%)
FINAL_HP = 30          # здоровье школы-колокола в финале
EASY_HP = 0.6          # на телефоне (кнопки на экране) боссы проще: здоровья меньше
EASY_SPEED = 0.75      # ...и двигаются/атакуют медленнее
MINI_HP = 36           # мини-босс (Чунгук+Мингук+Дундук): по 12 на каждую голову
MINI_HP_ROUND = 9      # на сколько больше в каждом следующем круге
FINAL_HP_ROUND = 15    # на сколько больше в каждом следующем круге
SCHOOL_TIME = 18.0     # сколько секунд «ты против школы» (со 2-го круга, когда у босса 50% здоровья)
SCHOOL_PIE_EVERY = 4.0  # пирожки из столовой в это время летят чаще
TYPE_SPEED = 45        # букв в секунду в катсценах
SPEAKERS = {"Ты": (150, 200, 255), "Директор": (255, 215, 90), "Зомби": (140, 220, 140),
            "Школа": (255, 110, 110), "Дневник": (232, 205, 150), "Повариха": (255, 175, 120),
            "Чунгук": (235, 110, 110), "Мингук": (110, 200, 120), "Дундук": (170, 170, 190),
            "Девочка": (245, 160, 205)}
BOSS_HP = 40
BOSS_PIE_EVERY = 9.0   # как часто из столовой прилетает пирожок во время боя
PIE_DROP_CHANCE = 0.2  # шанс, что из зомби выпадет пирожок
ZOMBIE_SLOW = 0.4      # во сколько раз замедлен зомби (пена, огнетушитель)


class Player:
    def __init__(self):
        self.x, self.y = 100.0, FLOOR - 60
        self.vx = self.vy = 0.0
        self.w, self.h = 40, 60
        self.face = 1
        self.hp = 5
        self.on_ground = False
        self.weapon = FISTS
        self.attack_cd = 0.0
        self.swing = 0.0
        self.hurt_cd = 0.0
        self.anim = 0.0  # сколько пикселей прошёл — по нему листаем кадры
        self.running = False
        self.uses = None      # сколько раз ещё можно использовать оружие (None — сколько угодно)
        self.shield_t = 0.0   # пока больше 0 — щит поднят

    @property
    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    def attack_rect(self):
        reach = self.weapon["reach"]
        if self.face > 0:
            return pygame.Rect(int(self.x + self.w), int(self.y + 10), reach, 40)
        return pygame.Rect(int(self.x - reach), int(self.y + 10), reach, 40)


class Zombie:
    def __init__(self, x):
        self.x, self.y = float(x), FLOOR - 56
        self.w, self.h = 38, 56
        self.hp = 3
        self.speed = random.uniform(60, 100)
        self.vy = 0.0
        self.on_ground = True
        self.face = -1
        self.bite_cd = 0.0
        self.flash = 0.0
        self.anim = 0.0  # сколько прошёл — по нему листаем кадры шарканья
        self.stun_t = 0.0   # оглушён (стоит, звёздочки)
        self.slow_t = 0.0   # замедлен
        self.dot_t = 0.0    # горит/плавится: 1 урон каждые 0.5 сек
        self.dot_acc = 0.0

    @property
    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)


class Boss:
    """Директор-зомби. Состояния: walk -> (throw | windup -> charge -> tired) -> walk. dying — падает."""

    def __init__(self, x, hp=BOSS_HP):
        self.w, self.h = 60, 84
        self.x, self.y = float(x), float(FLOOR - 84)
        self.maxhp = self.hp = hp
        self.face = -1
        self.state = "walk"
        self.t = 0.0           # сколько времени в текущем состоянии
        self.speed = 70
        self.dir = -1          # куда несётся при таране
        self.throw_cd = 2.0
        self.charge_cd = 5.0
        self.bite_cd = 0.0
        self.flash = 0.0
        self.anim = 0.0
        self.phase2 = False    # меньше половины здоровья — злее
        self.school_done = False  # «ты против школы» уже было
        self.stun_t = 0.0   # оглушён (стоит, звёздочки)
        self.slow_t = 0.0   # замедлен
        self.dot_t = 0.0    # горит/плавится: 1 урон каждые 0.5 сек
        self.dot_acc = 0.0

    @property
    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    def set_state(self, name):
        self.state, self.t = name, 0.0


class MiniBoss:
    """Чунгук, Мингук и Дундук слились в одно тело с колоколом на макушке.
    Три головы = три «жизни» и три атаки: рывок (Чунгук), монеты (Мингук), топот (Дундук).
    Когда голова вырубается, колокол звякает, и её атака пропадает. Первым вырубается Дундук.
    """

    def __init__(self, x, hp):
        self.w, self.h = 90, 100
        self.x, self.y = float(x), float(FLOOR - 100)
        self.maxhp = self.hp = hp
        self.heads = 3
        self.face = -1
        self.state = "walk"  # walk -> w_charge|w_coins|w_stomp -> charge|walk -> tired -> walk; dying
        self.t = 0.0
        self.dir = -1
        self.attack_cd = 2.5
        self.n = 0  # какая по счёту атака
        self.speed = 55
        self.bite_cd = 0.0
        self.flash = 0.0
        self.anim = 0.0
        self.stun_t = self.slow_t = self.dot_t = self.dot_acc = 0.0

    @property
    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    def set_state(self, name):
        self.state, self.t = name, 0.0


class SchoolBoss:
    """Финал: школа — огромный рот. Слабое место — колокол.
    hang (висит, летят парты) -> drop (падает) -> vuln (на полу, бей!) -> rise (поднимается) -> hang ...
    """

    def __init__(self, hp):
        self.maxhp = self.hp = hp
        self.w = self.h = 64
        self.x, self.y = W / 2 - 32, 140.0
        self.state = "hang"
        self.t = 0.0
        self.flash = 0.0
        self.enraged = False
        self.stun_t = self.slow_t = self.dot_t = self.dot_acc = 0.0  # чтобы работали общие эффекты
        self.sc = {"t": 0.0, "drop_cd": 1.5, "slide_cd": 3.0, "pie_t": 0.0, "hazards": []}

    @property
    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)


class Game:
    def __init__(self):
        self.player = Player()
        self.state = "map"       # map — карта школы, play — бой, cutscene — катсцена, win — победа
        self.cleared = set()     # какие комнаты зачищены
        self.round = 1           # после победы над директором — новый круг, сложнее
        self.current = None      # id комнаты, где идёт бой
        self.selected = "c1"     # что выбрано на карте
        self.map_msg = None      # [текст, секунд] — например «Закрыто»
        self.cutscenes = True
        self.seen_scenes = set()
        self.cut = None          # идущая катсцена
        self.room = THEMES["class"]
        self.variant = 0
        self.furniture = []
        self.platforms = []
        self.zombies = []
        self.corpses = []  # падающие зомби (только для красоты)
        self.boss = None
        self.projectiles = []  # двойки, которыми кидается босс
        self.shots = []        # снаряды героя: пульки, мел, учебники...
        self.fx = []           # взрывы и волны от звонка
        self.school = None     # «ты против школы»: {t, drop_cd, slide_cd, pie_t, hazards}
        self.final = None      # финальный босс — школа (SchoolBoss)
        self.mini = None       # мини-босс в Классе 7 (MiniBoss)
        self.has_key = False   # ключ от кабинета директора (выпадает из мини-босса)
        self.key_hint = False  # подсказку про ключ показываем один раз
        self.particles = Particles()   # искры, пыль, блёстки
        self.shake = [0.0, 0.0, 1.0]   # тряска экрана: сила, сколько осталось, на сколько секунд
        self.hurt_flash = 0.0          # красная вспышка по краям, когда больно
        self.overlay = None            # лучи света и виньетка для этой комнаты
        self.motes = []                # пылинки в лучах
        self.cut_motes = {}
        self.run_dust_t = 0.0
        self.water_t = 0.0     # таймер водяного пистолета (для тебя)
        self.msg = None        # [текст, секунд осталось]
        self.pie_timer = 0.0
        self.test_mode = False  # python game.py --test
        self.pickups = []  # лут: {"kind": "pie"|"club"|..., "rect": Rect}
        self.door_open = False
        self.over = False
        self.sprites = None  # создаётся при первой отрисовке

    def begin(self):
        """Начало игры: вступительная катсцена, потом карта."""
        self.play_scene("intro", ("map",))

    # ---------- карта школы ----------
    def room_status(self, rid):
        """done — зачищена, open — можно идти, locked — закрыта."""
        if rid in self.cleared:
            return "done"
        if rid == "office":
            ok = self.has_key and all(f"c{k}" in self.cleared for k in range(1, 8))
        elif rid == "school":
            ok = "office" in self.cleared
        elif rid == "canteen":
            ok = "c3" in self.cleared
        elif rid == "gym":
            ok = "c5" in self.cleared
        elif rid.startswith("c") and rid != "c1" and rid[1:].isdigit():
            ok = f"c{int(rid[1:]) - 1}" in self.cleared
        else:
            ok = True
        return "open" if ok else "locked"

    def lock_reason(self, rid):
        if rid == "canteen":
            return "Закрыто: сначала зачисти Класс 3"
        if rid == "gym":
            return "Закрыто: сначала зачисти Класс 5"
        if rid == "school":
            return "Закрыто: сначала победи директора"
        if rid == "office":
            if all(f"c{k}" in self.cleared for k in range(1, 8)):
                return "Закрыто: нужен ключ от кабинета"
            return "Закрыто: сначала зачисти все 7 классов, ключ лежит в Классе 7"
        return f"Закрыто: сначала зачисти Класс {int(rid[1:]) - 1}"

    def enter_room(self, rid):
        status = self.room_status(rid)
        if status == "locked":
            self.map_msg = [self.lock_reason(rid), 2.5]
        elif status == "done":
            self.map_msg = ["Здесь уже всё зачищено", 2.0]
        else:
            kind = ROOM_BY_ID[rid]["kind"]
            scene = {"toilet": "toilet", "office": "boss_intro", "final": "school_awakens",
                     "canteen": "canteen", "gym": "gym"}.get(kind, rid)
            self.play_scene(scene, ("room", rid))

    def map_click(self, pos):
        rid = room_at(pos)
        if rid:
            self.selected = rid
            self.enter_room(rid)

    def map_hover(self, pos):
        rid = room_at(pos)
        if rid:
            self.selected = rid

    def map_key(self, key):
        if key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            self.enter_room(self.selected)
        else:
            self.selected = move_selection(self.selected, key)

    def open_map(self):
        if self.state == "play" and not self.over:
            self.state = "map"

    def next_open_room(self):
        for rid in ORDER:
            if self.room_status(rid) == "open":
                return rid
        return self.selected

    def finish_room(self):
        """Комната зачищена: отдых (+2 сердца), назад на карту."""
        p = self.player
        p.hp = min(5, p.hp + 2)
        self.cleared.add(self.current)
        if self.current == "canteen":  # повариха накормила
            p.hp = 5
            self.map_msg = ["Повариха накормила тебя: здоровье полное!", 3.5]
        if self.current == "office":  # директор повержен — просыпается школа
            self.play_scene("school_awakens", ("room", "school"))
            return
        self.state = "map"
        self.selected = self.next_open_room()
        if self.room_status("office") == "open":
            self.play_scene("office_unlock", ("map",))

    def next_round(self):
        """После победы: все комнаты снова закрыты, зомби и босс сильнее."""
        self.round += 1
        self.cleared = set()
        self.has_key = False
        self.player.hp = 5
        self.selected = "c1"
        self.state = "map"

    # ---------- катсцены ----------
    def play_scene(self, name, then):
        scene = SCENES.get(name)
        if not self.cutscenes or scene is None or (scene.get("once", True) and name in self.seen_scenes):
            self.after_scene(then)
            return
        self.seen_scenes.add(name)
        self.cut = {"scene": scene, "i": 0, "t": 0.0, "then": then, "actors": []}
        self.state = "cutscene"
        self.begin_beat()

    def begin_beat(self):
        cut = self.cut
        beat = cut["scene"]["beats"][cut["i"]]
        if "actors" in beat:
            cut["actors"] = [dict(a) for a in beat["actors"]]
        else:  # актёры остаются там, где остановились
            cut["actors"] = [dict(a, x=a["to"]) for a in cut["actors"]]
        cut["t"] = 0.0

    def advance_scene(self):
        cut = self.cut
        beat = cut["scene"]["beats"][cut["i"]]
        if cut["t"] * TYPE_SPEED < len(beat["text"]):
            cut["t"] = 99.0  # допечатать сразу
            return
        cut["i"] += 1
        if cut["i"] >= len(cut["scene"]["beats"]):
            self.skip_scene()
        else:
            self.begin_beat()

    def skip_scene(self):
        then = self.cut["then"]
        self.cut = None
        self.after_scene(then)

    def after_scene(self, then):
        kind = then[0]
        if kind == "map":
            self.state = "map"
        elif kind == "room":
            self.start_room(then[1])
        elif kind == "resume":
            self.state = "play"
        elif kind == "win":
            self.state = "win"

    # ---------- бой в комнате ----------
    def start_room(self, rid):
        p = self.player
        info = ROOM_BY_ID[rid]
        self.state, self.current = "play", rid
        p.x, p.y, p.vx, p.vy = 60.0, FLOOR - p.h, 0.0, 0.0
        self.door_open = False
        self.corpses = []
        self.room = THEMES[info["kind"]]
        self.setup_light()
        self.variant = info.get("num", 1) - 1
        self.furniture = self.room["build"](self.variant)
        self.platforms = [rect for rect, _ in self.furniture]
        self.boss, self.projectiles, self.msg, self.pie_timer = None, [], None, 0.0
        self.shots, self.fx, self.school, self.final, self.water_t = [], [], None, None, 0.0
        self.mini = None
        extra = ROUND_ZOMBIES * (self.round - 1)
        if info["kind"] == "office":
            self.zombies = []
            self.boss = Boss(W - 220, self.easy_hp(BOSS_HP + ROUND_BOSS_HP * (self.round - 1)))
            self.msg = ["Директор-зомби!", 2.5]
        elif info["kind"] == "final":
            self.zombies = []
            self.final = SchoolBoss(self.easy_hp(FINAL_HP + FINAL_HP_ROUND * (self.round - 1)))
            self.msg = ["ФИНАЛ: школа против тебя!", 3.0]
        elif rid == "c7":  # последний класс: мини-босс
            self.zombies = []
            self.mini = MiniBoss(W - 240, self.easy_hp(MINI_HP + MINI_HP_ROUND * (self.round - 1)))
            self.msg = ["Три хулигана в одном теле!", 2.5]
        else:
            base = {"toilet": 8, "canteen": 6, "gym": 9}.get(info["kind"]) or 2 + 2 * info["num"]
            self.zombies = [Zombie(random.randint(500, W - 80)) for _ in range(base + extra)]

        # лут: на каждой мебели и ещё пара штук прямо на полу
        spots = [(rect.centerx, rect.top) for rect in self.platforms]
        spots += [(random.randint(150, 850), FLOOR) for _ in range(2)]
        self.pickups = []
        kinds, weights = zip(*self.room["loot"].items())
        for i, (cx, surface) in enumerate(spots):
            kind = random.choices(kinds, weights)[0]
            if i == 0 and p.weapon is FISTS and not self.cleared:
                kind = "club"  # самая первая находка в игре — оружие
            elif info["kind"] == "canteen" and i < 3:
                kind = "pie"   # в столовой всегда есть чем подкрепиться
            elif info["kind"] == "gym" and i == 0:
                kind = "dumbbell"  # в спортзале гарантированно лежит гантель
            self.add_loot(kind, cx, surface)

    def add_loot(self, kind, cx, surface_y, uses=None):
        if uses is None and kind in WEAPONS:
            uses = WEAPONS[kind]["uses"]
        rect = pygame.Rect(cx - 24, surface_y - 40, 48, 40)
        self.pickups.append({"kind": kind, "rect": rect, "uses": uses})

    def restart(self):
        """R: всё заново (катсцены и режим проверки сохраняются)."""
        sprites, test, cuts = self.sprites, self.test_mode, self.cutscenes
        self.__init__()
        self.sprites, self.test_mode, self.cutscenes = sprites, test, cuts
        self.begin()

    def weapon_item_near(self):
        """Ближайшее оружие на полу, до которого можно дотянуться (для подсказки и кнопки E)."""
        p = self.player
        reach = p.rect.inflate(20, 0)
        near = [i for i in self.pickups if i["kind"] in WEAPONS and reach.colliderect(i["rect"])]
        return min(near, key=lambda i: abs(i["rect"].centerx - p.rect.centerx), default=None)

    def take_weapon(self):
        """Кнопка E: берём оружие, а то, что было в руках, кладём на то же место."""
        item = self.weapon_item_near()
        if item is None or self.over:
            return
        p = self.player
        old, old_uses = p.weapon, p.uses
        p.weapon, p.uses = WEAPONS[item["kind"]], item["uses"]
        if old is FISTS:
            self.pickups.remove(item)
        else:
            item["kind"], item["uses"] = old["key"], old_uses

    def cycle_weapon(self):
        """Режим проверки: следующее оружие из таблицы с полными зарядами."""
        order = [FISTS] + list(WEAPONS.values())
        p = self.player
        nxt = order[(order.index(p.weapon) + 1) % len(order)]
        p.weapon, p.uses = nxt, nxt["uses"]
        self.msg = [f"Оружие: {nxt['name']}", 1.2]

    # ---------- оружие ----------
    def spend(self):
        """Один заряд оружия потрачен. Кончились — снова кулаки."""
        p = self.player
        if p.uses is None:
            return
        p.uses -= 1
        if p.uses <= 0:
            name = p.weapon["name"]
            p.weapon, p.uses = FISTS, None
            self.msg = [f"{name}: всё, закончилось!", 1.6]

    def tick_effects(self, t, dt):
        """Замедление и горение у зомби или босса."""
        t.slow_t = max(0.0, t.slow_t - dt)
        if t.dot_t > 0:
            t.dot_t -= dt
            t.dot_acc += dt
            if t.dot_acc >= 0.5:
                t.dot_acc -= 0.5
                t.hp -= 1
                t.flash = 0.1

    # ---------- эффекты ----------
    def setup_light(self):
        beams = self.room.get("beams", [])
        self.overlay = make_overlay(beams)
        self.motes = make_motes(beams, 26, seed=len(beams) + 7)
        self.particles.clear()

    def puff(self, x, y, n=6, color=(214, 202, 180)):
        """Облачко пыли."""
        light = tuple(min(255, c + 30) for c in color)
        self.particles.emit(x, y, n, [color, light], speed=(20, 90), life=(0.25, 0.55), size=(4, 8),
                            grav=-50, angle=-math.pi / 2, spread=math.pi * 0.9)

    def spark(self, x, y, dirn=1):
        """Искры при ударе."""
        self.particles.emit(x, y, 9, [(255, 240, 120), (255, 255, 255), (255, 196, 80)], speed=(90, 280),
                            life=(0.15, 0.35), size=(3, 6), grav=260, angle=0 if dirn > 0 else math.pi, spread=2.4)
        self.fx.append({"type": "hit", "x": x, "y": y, "t": 0.0})

    def sparkle(self, x, y, color=(255, 232, 110)):
        """Блёстки вверх: подобрал что-то хорошее."""
        self.particles.emit(x, y, 12, [color, (255, 255, 255)], speed=(40, 150), life=(0.4, 0.8), size=(3, 5),
                            grav=-120, angle=-math.pi / 2, spread=math.pi * 0.8)

    def add_shake(self, amp, t):
        if amp * t >= self.shake[0] * max(0.0, self.shake[1]):
            self.shake = [float(amp), float(t), float(t)]

    def on_player_hurt(self, dmg):
        p = self.player
        self.hurt_flash = 0.35
        self.add_shake(3 + dmg * 1.5, 0.2)
        self.particles.emit(p.x + p.w / 2, p.y + 24, 10, [(230, 60, 80), (255, 140, 140)], speed=(60, 220),
                            life=(0.2, 0.45), size=(3, 6), grav=360)

    def fx_tick(self, dt):
        self.particles.update(dt)
        self.shake[1] = max(0.0, self.shake[1] - dt)
        self.hurt_flash = max(0.0, self.hurt_flash - dt)

    def apply_shake(self, s):
        amp, left, total = self.shake
        if left <= 0:
            return
        k = amp * (left / total)
        dx, dy = random.randint(-int(k), int(k)), random.randint(-int(k), int(k))
        if dx or dy:
            snap = s.copy()
            s.fill((0, 0, 0))
            s.blit(snap, (dx, dy))

    def draw_shadows(self, s):
        """Мягкие тени под героем, зомби и боссами — они стоят на земле, а не висят."""
        def one(rect, base):
            draw_shadow(s, rect.centerx, rect.bottom, ground_below(self.platforms, rect.left, rect.right, rect.bottom), base)
        one(self.player.rect, 64)
        for z in self.zombies:
            one(z.rect, 56)
        if self.boss and self.boss.state not in ("dying", "hide"):
            one(self.boss.rect, 92)
        if self.mini and self.mini.state != "dying":
            one(self.mini.rect, 120)

    def apply_hit(self, t, w, dirn):
        """Попадание оружия w по зомби или боссу t."""
        t.hp -= w["dmg"]
        if w["dmg"] > 0:
            t.flash = 0.12
            self.spark(t.x + t.w / 2, t.y + t.h / 2 - 8, dirn)
        if isinstance(t, Zombie):
            t.x += dirn * w.get("kb", 40 if w["type"] == "melee" else 0)
            t.x = max(0, min(W - t.w, t.x))
        if "slow" in w:
            t.slow_t = max(t.slow_t, w["slow"])
        if "stun" in w:
            limit = 1.5 if isinstance(t, Boss) else w["stun"]  # босса надолго не оглушить
            t.stun_t = max(t.stun_t, min(w["stun"], limit))
        if "dot" in w:
            t.dot_t = max(t.dot_t, w["dot"])

    def targets(self):
        boss = [self.boss] if self.boss and self.boss.state not in ("dying", "hide") else []
        weak = [self.final] if self.final and self.final.state == "vuln" else []  # колокол только когда упал
        mini = [self.mini] if self.mini and self.mini.state != "dying" else []
        return list(self.zombies) + boss + weak + mini

    def use_weapon(self):
        p, w = self.player, self.player.weapon
        p.attack_cd = w["cd"]
        kind = w["type"]
        if kind == "melee":
            p.swing = 0.15
            hit = p.attack_rect()
            hits = 0
            for t in self.targets():
                if hit.colliderect(t.rect):
                    self.apply_hit(t, w, p.face)
                    hits += 1
            if hits:
                self.spend()  # стул ломается только когда им попал
        elif kind in ("shot", "throw"):
            p.swing = 0.1
            self.shots.append({"x": p.x + p.w / 2 + p.face * 30, "y": p.y + 26.0, "w": w, "dir": p.face,
                               "x0": p.x + p.w / 2 + p.face * 30, "t": 0.0,
                               "vx": p.face * w["speed"], "vy": w.get("vy", 0.0)})
            self.spend()
        elif kind == "shield":
            p.shield_t = w["dur"]
            self.spend()
        elif kind == "bell":
            for t in self.targets():
                t.stun_t = max(t.stun_t, 1.5 if isinstance(t, Boss) else 2.5)
            self.fx.append({"type": "ring", "x": p.x + p.w / 2, "y": p.y + 30, "t": 0.0})
            self.msg = ["ДЗЫНЬ! Все замерли", 1.5]
            self.spend()

    def explode(self, x, y, w):
        r = w["area"]
        for t in self.targets():
            cx, cy = t.x + t.w / 2, t.y + t.h / 2
            if (cx - x) ** 2 + (cy - y) ** 2 <= (r + t.w / 2) ** 2:
                self.apply_hit(t, w, 1 if cx > x else -1)
                if isinstance(t, Zombie):
                    t.x += 50 if cx > x else -50
                    t.x = max(0, min(W - t.w, t.x))
        self.fx.append({"type": "boom", "x": x, "y": y, "R": r, "t": 0.0})
        self.add_shake(6, 0.28)
        self.particles.emit(x, y, 22, [(255, 190, 60), (255, 120, 40), (255, 240, 160)], speed=(80, 330),
                            life=(0.25, 0.6), size=(4, 8), grav=200)

    def update_shots(self, dt):
        for sh in self.shots:
            w = sh["w"]
            sh["t"] += dt
            sh["vy"] += w.get("grav", 0) * dt
            sh["x"] += sh["vx"] * dt
            sh["y"] += sh["vy"] * dt
            box = pygame.Rect(int(sh["x"]) - 9, int(sh["y"]) - 9, 18, 18)
            target = next((t for t in self.targets() if box.colliderect(t.rect)), None)
            landed = sh["y"] >= FLOOR - 4
            too_far = w["type"] == "shot" and abs(sh["x"] - sh["x0"]) > w["range"]
            if target or landed or too_far or not -30 < sh["x"] < W + 30:
                if w.get("area"):
                    self.explode(sh["x"], min(sh["y"], FLOOR - 10), w)  # бомба взрывается везде
                elif target:
                    self.apply_hit(target, w, sh["dir"])
                sh["dead"] = True
        self.shots = [sh for sh in self.shots if not sh.get("dead")]
        for e in self.fx:
            e["t"] += dt
        self.fx = [e for e in self.fx if e["t"] < 0.45]

    @staticmethod
    def easy_hp(hp):
        return max(3, round(hp * EASY_HP)) if touch.enabled else hp

    def hurt_player(self, dmg, knock_from_x):
        """Игрок получил урон (с неуязвимостью на время мигания)."""
        p = self.player
        if p.hurt_cd > 0 or p.shield_t > 0:
            return  # мигаешь после удара или держишь щит
        if touch.enabled:  # на телефоне удар босса отнимает не больше 1 сердца и защита после удара дольше
            dmg = min(dmg, 1)
        p.hp -= dmg
        self.on_player_hurt(dmg)
        p.hurt_cd = 1.4 if touch.enabled else 0.9
        p.vy = -400
        p.x += 40 if p.x + p.w / 2 > knock_from_x else -40
        p.x = max(0, min(W - p.w, p.x))

    def update_boss(self, dt):
        b, p = self.boss, self.player
        b.flash = max(0, b.flash - dt)
        b.t += dt
        if b.state == "dying":
            if b.t > 1.4:
                self.boss = None
                self.add_loot("pie", int(b.x + b.w / 2), FLOOR)  # из директора выпадает пирожок
                self.play_scene("boss_defeat", ("resume",))
            return
        if b.state == "hide":  # прячется, пока школа нападает
            self.update_school(dt)
            return
        self.tick_effects(b, dt)
        if b.hp <= 0:
            b.set_state("dying")
            self.projectiles = []
            return

        b.bite_cd = max(0, b.bite_cd - dt)
        bc, pc = b.x + b.w / 2, p.x + p.w / 2
        to_p = 1 if pc > bc else -1

        # злость: меньше половины здоровья
        if not b.phase2 and b.hp <= b.maxhp / 2:
            if self.round >= 2 and not b.school_done:  # со 2-го круга: сначала «ты против школы»
                b.school_done = True
                b.set_state("hide")
                self.start_school()
                return
            b.phase2, b.speed = True, 95
            self.zombies += [Zombie(random.choice((60, 120, 820))) for _ in range(3)]
            self.msg = ["Директор в ярости! Зовёт подмогу!", 2.5]

        if b.stun_t > 0:  # оглушён звонком или мусоркой — стоит и качается
            b.stun_t -= dt
            self.boss_pies(dt)
            return

        slow = 0.6 if b.slow_t > 0 else 1.0
        if b.state == "walk":
            b.face = to_p
            b.x += b.face * b.speed * slow * dt
            b.anim += b.speed * slow * dt
            b.throw_cd -= dt
            b.charge_cd -= dt
            if b.throw_cd <= 0:
                b.set_state("throw")
            elif b.charge_cd <= 0:
                b.face = to_p
                b.set_state("windup")
        elif b.state == "throw":
            b.face = to_p
            if b.t >= 0.5:  # замах закончен — кидаем двойки
                ys = [p.y + 30]
                if b.phase2:
                    ys.append(FLOOR - 30)
                for y in ys:
                    self.projectiles.append({"x": bc + b.face * 40, "y": float(y), "vx": b.face * 380, "t": 0.0})
                b.throw_cd = 1.5 if b.phase2 else 2.4
                b.set_state("walk")
        elif b.state == "windup":  # трясётся — сейчас рванёт на тебя
            if b.t >= 0.7:
                b.dir = b.face
                b.set_state("charge")
        elif b.state == "charge":
            b.x += b.dir * 520 * dt
            if b.t >= 0.9 or b.x <= 0 or b.x + b.w >= W:
                b.set_state("tired")
        elif b.state == "tired":  # выдохся — самое время бить
            if b.t >= (0.6 if b.phase2 else 0.9):
                b.charge_cd = 3.5 if b.phase2 else 5.5
                b.set_state("walk")
        b.x = max(0, min(W - b.w, b.x))

        # столкновение с игроком
        if b.rect.colliderect(p.rect):
            if b.state == "charge":
                if p.shield_t > 0:  # врезался в щит
                    b.set_state("tired")
                    self.msg = ["Блок! Директор выдохся", 1.5]
                else:
                    self.hurt_player(2, bc)
            elif b.state in ("walk", "throw") and b.bite_cd == 0:
                b.bite_cd = 1.2
                self.hurt_player(1, bc)

        self.boss_pies(dt)

    def update_mini(self, dt):
        m, p = self.mini, self.player
        m.flash = max(0.0, m.flash - dt)
        m.t += dt
        if m.state == "dying":
            if m.t > 1.5:
                self.mini = None
                self.add_loot("pie", int(m.x + m.w / 2) - 40, FLOOR)
                if not self.has_key:
                    self.add_loot("key", int(m.x + m.w / 2) + 20, FLOOR)  # ключ от кабинета директора
                self.play_scene("mini_defeat", ("resume",))
            return
        self.tick_effects(m, dt)
        if m.hp <= 0:
            m.set_state("dying")
            self.projectiles = []
            return
        heads = 3 if m.hp > m.maxhp * 2 / 3 else (2 if m.hp > m.maxhp / 3 else 1)
        if heads < m.heads:  # одна голова вырубилась — колокол звякает, атака пропадает
            lost = {3: "Дундук", 2: "Мингук"}[m.heads]
            m.heads = heads
            self.fx.append({"type": "ring", "x": m.x + m.w / 2, "y": m.y, "t": 0.0})
            self.msg = [f"Колокол звякнул: {lost} вырубился!", 2.5]
            self.add_loot("pie", random.randint(120, 820), FLOOR)
            m.attack_cd = 1.5
        cd = {3: 2.2, 2: 1.8, 1: 1.4}[m.heads]
        bc, pc = m.x + m.w / 2, p.x + p.w / 2
        to_p = 1 if pc > bc else -1
        m.bite_cd = max(0.0, m.bite_cd - dt)
        if m.stun_t > 0:
            m.stun_t -= dt
            self.boss_pies(dt)
            return
        slow = 0.6 if m.slow_t > 0 else 1.0
        if m.state == "walk":
            m.face = to_p
            m.x += m.face * m.speed * slow * dt
            m.anim += m.speed * slow * dt
            m.attack_cd -= dt
            if m.attack_cd <= 0:  # какие атаки есть, зависит от живых голов
                kind = ["charge", "coins", "stomp"][:m.heads][m.n % m.heads]
                m.n += 1
                m.face = to_p
                m.set_state("w_" + kind)
        elif m.state == "w_charge":  # Чунгук: трясётся и несётся на тебя
            if m.t >= 0.7:
                m.dir = m.face
                m.set_state("charge")
        elif m.state == "charge":
            m.x += m.dir * 520 * dt
            if m.t >= 0.8 or m.x <= 0 or m.x + m.w >= W:
                m.set_state("tired")
        elif m.state == "tired":
            if m.t >= (0.6 if m.heads == 1 else 0.8):
                m.attack_cd = cd
                m.set_state("walk")
        elif m.state == "w_coins":  # Мингук: швыряет твои же монеты по дуге
            if m.t >= 0.5:
                for vx in (240, 340, 440):
                    self.projectiles.append({"x": bc + m.face * 40, "y": m.y + 20.0, "vx": m.face * vx, "vy": -520.0,
                                             "grav": 1500, "t": 0.0, "kind": "coin"})
                m.attack_cd = cd
                m.set_state("walk")
        elif m.state == "w_stomp":  # Дундук: топает, по полу в обе стороны бегут волны — прыгай
            if m.t >= 0.8:
                self.add_shake(6, 0.25)
                self.puff(bc, FLOOR - 4, 12)
                for d in (-1, 1):
                    self.projectiles.append({"x": bc + d * 50, "y": FLOOR - 18.0, "vx": d * 430, "t": 0.0, "kind": "wave"})
                m.attack_cd = cd
                m.set_state("walk")
        m.x = max(0, min(W - m.w, m.x))

        if m.rect.colliderect(p.rect):
            if m.state == "charge":
                if p.shield_t > 0:  # врезался в щит
                    m.set_state("tired")
                    self.msg = ["Блок! Они выдохлись", 1.5]
                else:
                    self.hurt_player(2, bc)
            elif m.state == "walk" and m.bite_cd == 0:
                m.bite_cd = 1.2
                self.hurt_player(1, bc)
        self.boss_pies(dt)

    def start_school(self):
        """Директор спрятался — школа оживает: падают парты и стулья, по полу летят парты."""
        self.school = {"t": 0.0, "drop_cd": 0.8, "slide_cd": 2.2, "pie_t": SCHOOL_PIE_EVERY - 1.5, "hazards": []}
        self.projectiles = []
        self.msg = ["ШКОЛА ПРОТИВ ТЕБЯ! Уворачивайся!", 3.0]

    def tick_hazards(self, sc, dt, spawn, drop_every, slide_every):
        """Парты и стулья: падают сверху (сначала тень-предупреждение) и летят по полу.
        Общий код для «ты против школы» и для финала."""
        p = self.player
        if spawn:
            sc["drop_cd"] -= dt
            sc["slide_cd"] -= dt
            if sc["drop_cd"] <= 0:
                sc["drop_cd"] = drop_every
                x = max(60, min(W - 60, int(p.x + p.w / 2 + random.randint(-220, 220))))
                sc["hazards"].append({"type": "drop", "kind": random.choice(("desk", "chair")),
                                      "x": x, "y": -50.0, "vy": 0.0, "warn": 0.7})
            if sc["slide_cd"] <= 0:
                sc["slide_cd"] = slide_every
                d = random.choice((-1, 1))
                sc["hazards"].append({"type": "slide", "kind": "desk", "x": float(-90 if d > 0 else W + 90),
                                      "y": float(FLOOR - 35), "dir": d, "warn": 0.9})
        for hz in sc["hazards"]:
            if hz["warn"] > 0:
                hz["warn"] -= dt
                continue
            if hz["type"] == "drop":
                hz["vy"] += 2400 * dt
                hz["y"] += hz["vy"] * dt
                rect = pygame.Rect(hz["x"] - 35, int(hz["y"]), 70, 40)
                if rect.bottom >= FLOOR:
                    hz["dead"] = True
                    self.puff(hz["x"], FLOOR - 4, 8)
                    self.add_shake(3, 0.12)
            else:
                hz["x"] += hz["dir"] * 620 * dt
                rect = pygame.Rect(int(hz["x"]) - 35, int(hz["y"]), 70, 35)
                if hz["x"] < -100 or hz["x"] > W + 100:
                    hz["dead"] = True
            if rect.colliderect(p.rect) and not hz.get("dead"):
                self.hurt_player(1, rect.centerx)  # щит и мигание после удара защищают
        sc["hazards"] = [hz for hz in sc["hazards"] if not hz.get("dead")]

    def update_school(self, dt):
        sc, b = self.school, self.boss
        sc["t"] += dt
        sc["pie_t"] += dt
        self.tick_hazards(sc, dt, True, max(0.55, 1.1 - sc["t"] * 0.03), 3.2)
        if sc["pie_t"] >= SCHOOL_PIE_EVERY:
            sc["pie_t"] = 0.0
            self.add_loot("pie", random.randint(120, 820), FLOOR)
            self.msg = ["Повариха прислала пирожок!", 2.0]
        self.maybe_water(dt)
        if sc["t"] >= SCHOOL_TIME:  # школа успокоилась — директор возвращается злее
            self.school = None
            b.x = float(random.choice((60, W - 120)))
            b.set_state("walk")
            self.msg = ["Школа успокоилась. Директор вернулся!", 2.5]

    def update_final(self, dt):
        f = self.final
        f.flash = max(0.0, f.flash - dt)
        f.t += dt
        sc = f.sc
        sc["t"] += dt
        sc["pie_t"] += dt
        if f.state == "dying":  # школа затихает
            self.tick_hazards(sc, dt, False, 1, 1)
            if f.t > 2.0:
                self.final = None
                self.finish_final()
            return
        if f.hp <= 0:
            f.state, f.t = "dying", 0.0
            sc["hazards"] = []
            self.msg = ["Школа затихает...", 2.5]
            return
        rage = f.hp <= f.maxhp / 2
        if rage and not f.enraged:
            f.enraged = True
            self.msg = ["Школа в ярости! Всё быстрее!", 2.5]
        if f.state == "hang":
            f.y = 140 + math.sin(f.t * 2) * 8
            if f.t >= (6.5 if rage else 9.0):
                f.state, f.t = "drop", 0.0
        elif f.state == "drop":
            f.y += 560 * dt
            if f.y >= FLOOR - f.h:
                f.y, f.state, f.t = float(FLOOR - f.h), "vuln", 0.0
                self.add_shake(7, 0.3)
                self.puff(f.x + f.w / 2, FLOOR - 4, 14, (230, 190, 90))
                self.msg = ["Колокол упал! БЕЙ ПО НЕМУ!", 2.0]
        elif f.state == "vuln":  # слабое место — бей, пока не поднялся
            if f.t >= (5.0 if rage else 6.0):
                f.state, f.t = "rise", 0.0
        elif f.state == "rise":
            f.y -= 420 * dt
            if f.y <= 140:
                f.y, f.state, f.t = 140.0, "hang", 0.0
        self.tick_hazards(sc, dt, f.state == "hang", 0.7 if rage else 1.0, 2.4 if rage else 3.4)
        if sc["pie_t"] >= BOSS_PIE_EVERY:
            sc["pie_t"] = 0.0
            self.add_loot("pie", random.randint(120, 820), FLOOR)
            self.msg = ["Повариха прислала пирожок!", 2.0]
        self.maybe_water(dt)

    def finish_final(self):
        """Школа побеждена — победа во всей игре."""
        self.cleared.add("school")
        self.player.hp = min(5, self.player.hp + 2)
        self.play_scene("victory", ("win",))

    def maybe_water(self, dt):
        """Раз в 3 секунды — 30% шанс, что из столовой прилетит водяной пистолет (для тебя)."""
        self.water_t += dt
        if self.water_t < WATER_EVERY:
            return
        self.water_t = 0.0
        if random.random() >= WATER_CHANCE:
            return
        p = self.player
        if p.weapon["key"] == "watergun" or any(i["kind"] == "watergun" for i in self.pickups):
            return  # уже есть
        x = int(p.x + p.w / 2 + random.choice((-1, 1)) * random.randint(90, 180))
        self.add_loot("watergun", max(80, min(W - 80, x)), FLOOR)
        self.msg = ["Повариха прислала водяной пистолет!", 2.0]

    def boss_pies(self, dt):
        """Пирожки из столовой во время боя (и шанс на водяной пистолет)."""
        self.maybe_water(dt)
        self.pie_timer += dt
        if self.pie_timer >= BOSS_PIE_EVERY:
            self.pie_timer = 0.0
            self.add_loot("pie", random.randint(120, 820), FLOOR)
            self.msg = ["Повариха прислала пирожок!", 2.0]

    def update_projectiles(self, dt):
        p = self.player
        for pr in self.projectiles:
            pr["x"] += pr["vx"] * dt
            pr["t"] += dt
            if "grav" in pr:  # монета летит по дуге
                pr["vy"] += pr["grav"] * dt
                pr["y"] += pr["vy"] * dt
            w, h = {"coin": (18, 18), "wave": (46, 36)}.get(pr.get("kind"), (22, 28))
            hit = pygame.Rect(int(pr["x"]) - w // 2, int(pr["y"]) - h // 2, w, h)
            if hit.colliderect(p.rect):
                if p.shield_t > 0:  # двойку отбил щитом
                    pr["dead"] = True
                elif p.hurt_cd == 0:
                    self.hurt_player(1, pr["x"])
                    pr["dead"] = True
        self.projectiles = [pr for pr in self.projectiles
                            if not pr.get("dead") and -40 < pr["x"] < W + 40 and pr["y"] < FLOOR + 20]

    # ---------- логика ----------
    def update(self, dt, keys, mouse_pressed):
        if self.map_msg:
            self.map_msg[1] -= dt
            if self.map_msg[1] <= 0:
                self.map_msg = None
        if self.state == "cutscene":
            self.cut["t"] += dt
            return
        if self.state != "play" or self.over:
            return
        p = self.player
        self.fx_tick(dt)
        move = (keys[pygame.K_d] or keys[pygame.K_RIGHT]) - (keys[pygame.K_a] or keys[pygame.K_LEFT])
        p.running = bool(move) and (keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT])
        p.vx = move * (WALK_SPEED if not p.running else RUN_SPEED)
        if move:
            p.face = move
        p.anim += abs(p.vx) * dt
        if (keys[pygame.K_w] or keys[pygame.K_UP] or keys[pygame.K_SPACE]) and p.on_ground:
            p.vy = JUMP
            p.on_ground = False

        # движение и гравитация
        p.vy += GRAVITY * dt
        was_air, vy_pre = not p.on_ground, p.vy
        p.x = max(0, min(W - p.w, p.x + p.vx * dt))
        prev_bottom = p.y + p.h
        p.y += p.vy * dt
        p.on_ground = False
        if p.y + p.h >= FLOOR:
            p.y, p.vy, p.on_ground = FLOOR - p.h, 0, True
        elif p.vy > 0:
            for pl in self.platforms:
                if (prev_bottom <= pl.top + 2 and p.y + p.h >= pl.top
                        and p.x + p.w > pl.left and p.x < pl.right):
                    p.y, p.vy, p.on_ground = pl.top - p.h, 0, True

        if p.on_ground and was_air and vy_pre > 450:  # приземлился — пыль
            self.puff(p.x + p.w / 2, p.y + p.h - 4, 7)
            self.add_shake(2, 0.08)
        self.run_dust_t -= dt
        if p.on_ground and p.running and abs(p.vx) > 1 and self.run_dust_t <= 0:  # бежишь — пыль из-под ног
            self.run_dust_t = 0.09
            self.puff(p.x + p.w / 2 - p.face * 14, p.y + p.h - 4, 2)

        # оружие
        p.attack_cd = max(0, p.attack_cd - dt)
        p.swing = max(0, p.swing - dt)
        p.hurt_cd = max(0, p.hurt_cd - dt)
        p.shield_t = max(0, p.shield_t - dt)
        if (keys[pygame.K_j] or mouse_pressed) and p.attack_cd == 0:
            self.use_weapon()

        # зомби
        for z in self.zombies:
            z.flash = max(0, z.flash - dt)
            z.bite_cd = max(0, z.bite_cd - dt)
            self.tick_effects(z, dt)
            z.face = 1 if p.x > z.x else -1
            mult = 0.0 if z.stun_t > 0 else (ZOMBIE_SLOW if z.slow_t > 0 else 1.0)
            z.stun_t = max(0.0, z.stun_t - dt)
            z.x += z.face * z.speed * mult * dt
            z.anim += z.speed * mult * dt
            # зомби умеют прыгать на платформы, если игрок выше
            if z.on_ground and p.y + p.h < z.y + z.h - 40 and abs(p.x - z.x) < 120:
                z.vy, z.on_ground = -760, False
            z.vy += GRAVITY * dt
            prev_bottom = z.y + z.h
            z.y += z.vy * dt
            z.on_ground = False
            if z.y + z.h >= FLOOR:
                z.y, z.vy, z.on_ground = FLOOR - z.h, 0, True
            elif z.vy > 0:
                for pl in self.platforms:
                    if (prev_bottom <= pl.top + 2 and z.y + z.h >= pl.top
                            and z.x + z.w > pl.left and z.x < pl.right):
                        z.y, z.vy, z.on_ground = pl.top - z.h, 0, True
            if z.rect.colliderect(p.rect) and z.bite_cd == 0 and p.hurt_cd == 0 and z.stun_t <= 0:
                if p.shield_t > 0:  # щит: зомби отлетает назад
                    z.bite_cd = 0.6
                    z.x -= z.face * 30
                else:
                    p.hp -= 1
                    self.on_player_hurt(1)
                    z.bite_cd = 1.0
                    p.hurt_cd = 0.8
                    p.vy = -400
                    p.x += -z.face * 30
        for z in self.zombies:
            if z.hp <= 0:
                self.corpses.append({"cx": z.rect.centerx, "bottom": z.rect.bottom,
                                     "face": z.face, "fall": p.face, "t": 0.0})
                self.puff(z.rect.centerx, z.rect.bottom - 8, 9, (120, 200, 120))
                if random.random() < PIE_DROP_CHANCE:
                    self.add_loot("pie", z.rect.centerx, z.rect.bottom)
        self.zombies = [z for z in self.zombies if z.hp > 0]
        bdt = dt * EASY_SPEED if touch.enabled else dt
        if self.boss:
            self.update_boss(bdt)
        if self.final:
            self.update_final(bdt)
        if self.mini:
            self.update_mini(bdt)
        if self.state != "play":
            return  # катсцена или победа запустились в этом кадре
        self.update_projectiles(bdt)
        self.update_shots(dt)
        if self.msg:
            self.msg[1] -= dt
            if self.msg[1] <= 0:
                self.msg = None
        for c in self.corpses:
            c["t"] += dt
        self.corpses = [c for c in self.corpses if c["t"] < CORPSE_TIME]

        # ключ подбирается сам
        for item in list(self.pickups):
            if item["kind"] == "key" and p.rect.colliderect(item["rect"]):
                self.has_key = True
                self.pickups.remove(item)
                self.sparkle(p.x + p.w / 2, p.y + 10)
                self.msg = ["Ключ от кабинета директора у тебя!", 2.5]

        # пирожки подбираются сами (если ты ранен)
        for item in list(self.pickups):
            if item["kind"] == "pie" and p.hp < 5 and p.rect.colliderect(item["rect"]):
                p.hp += 1
                self.pickups.remove(item)
                self.sparkle(p.x + p.w / 2, p.y + 10, (255, 150, 160))

        if self.test_mode:
            p.hp = 5
            if not self.zombies and self.boss is None:
                self.zombies = [Zombie(random.randint(450, W - 80)) for _ in range(4)]

        if self.current == "c7" and self.mini is None and not self.zombies and not self.has_key and not self.key_hint:
            self.key_hint = True
            self.msg = ["Подними ключ: без него дверь не откроется", 3.0]

        # дверь: комната зачищена — можно вернуться на карту
        if (not self.zombies and self.boss is None and self.final is None and self.mini is None
                and (self.current != "c7" or self.has_key)):
            self.door_open = True
        if self.door_open and p.x + p.w >= W - 10 and not self.test_mode:
            self.finish_room()
            return

        if p.hp <= 0:
            self.over = True

    # ---------- рисование (пиксельное) ----------
    def draw(self, s, font, big):
        if self.sprites is None:
            self.sprites = SpriteSet()
        sp = self.sprites
        if self.state == "map":
            wname = self.player.weapon["name"]
            if self.player.uses is not None:
                wname += f" x{self.player.uses}"
            draw_map(s, self.room_status, self.selected, len(self.cleared),
                     self.map_msg[0] if self.map_msg else None, wname, self.player.hp, sp, self.has_key)
            return
        if self.state == "cutscene":
            self.draw_cutscene(s, font)
            return
        self.room["back"](s, self.variant)

        for rect, kind in self.furniture:
            draw_furniture(s, rect, kind)

        if self.school:
            self.draw_school_bg(s)

        # дверь
        door = pygame.Rect(W - 40, FLOOR - 112, 40, 112)
        pygame.draw.rect(s, INK, door)
        pygame.draw.rect(s, (90, 220, 120) if self.door_open else (120, 60, 60), door.inflate(-8, -8).move(4, 4))
        pygame.draw.rect(s, (250, 220, 60), (door.x + 8, door.centery, 8, 8))  # ручка

        tick = pygame.time.get_ticks()
        for item in self.pickups:
            bob = int(math.sin(tick / 200 + item["rect"].x) * 3)
            img = sp.pie if item["kind"] == "pie" else (sp.key if item["kind"] == "key" else sp.weapon[item["kind"]][1])
            pos = img.get_rect(midbottom=item["rect"].midbottom).move(0, bob - 4)
            s.blit(img, pos)
            if (tick // 350 + item["rect"].x) % 2:  # мигающая искорка
                pygame.draw.rect(s, (255, 240, 120), (pos.right - 4, pos.top - 6, 6, 6))
                pygame.draw.rect(s, (255, 255, 255), (pos.right - 2, pos.top - 4, 2, 2))

        self.draw_shadows(s)
        for c in self.corpses:
            self.draw_corpse(s, c)
        for z in self.zombies:
            self.draw_zombie(s, z)
        if self.boss:
            self.draw_boss(s)
        if self.mini:
            self.draw_mini(s)
        if self.final:
            self.draw_final(s)
        hazards = self.school["hazards"] if self.school else (self.final.sc["hazards"] if self.final else [])
        if hazards:
            self.draw_school_hazards(s, hazards)
        for pr in self.projectiles:
            if pr.get("kind") == "coin":  # монета, которую у тебя отобрали
                c = (int(pr["x"]), int(pr["y"]))
                pygame.draw.circle(s, INK, c, 10)
                pygame.draw.circle(s, (245, 205, 70), c, 7)
                pygame.draw.rect(s, (200, 150, 30), (c[0] - 1, c[1] - 4, 3, 8))
            elif pr.get("kind") == "wave":  # волна топота по полу
                x, y = int(pr["x"]), int(pr["y"])
                pts = [(x - 23, y + 18), (x, y - 18), (x + 23, y + 18)]
                pygame.draw.polygon(s, (170, 135, 95), pts)
                pygame.draw.polygon(s, INK, pts, 3)
            else:
                card = pygame.transform.rotate(sp.card, pr["t"] * 360)
                s.blit(card, card.get_rect(center=(int(pr["x"]), int(pr["y"]))))
        for sh in self.shots:
            w = sh["w"]
            img = sp.proj[w["key"]]
            if w["type"] == "throw" and w.get("spin", True):
                img = pygame.transform.rotate(img, -sh["dir"] * sh["t"] * 600)
            elif sh["dir"] < 0:
                img = pygame.transform.flip(img, True, False)
            s.blit(img, img.get_rect(center=(int(sh["x"]), int(sh["y"]))))
        self.draw_fx(s)
        self.draw_player(s)
        self.particles.draw(s)
        if self.overlay is not None:  # лучи света из окон и тёмные края
            s.blit(self.overlay, (0, 0))
        draw_motes(s, self.motes, tick / 1000)
        self.apply_shake(s)
        if self.hurt_flash > 0:  # красная вспышка по краям
            flash = red_vignette()
            flash.set_alpha(int(255 * min(1.0, self.hurt_flash / 0.35)))
            s.blit(flash, (0, 0))

        # интерфейс: тёмная полоса сверху, чтобы текст читался на любом фоне
        bar = pygame.Surface((W, 52), pygame.SRCALPHA)
        bar.fill((20, 20, 30, 170))
        s.blit(bar, (0, 0))
        for i in range(5):
            img = sp.heart if i < self.player.hp else sp.heart_empty
            s.blit(img, (16 + i * 32, 16))
        white = (255, 255, 255)
        title = ROOM_BY_ID[self.current]["name"] if self.current else ""
        if self.round > 1:
            title += f"  ·  круг {self.round}"
        tx = 190
        if self.has_key:  # значок ключа рядом с сердцами
            s.blit(sp.key, (180, 17))
            tx += 52
        s.blit(font.render(title + ("" if touch.enabled else "   (M — карта)"), True, white), (tx, 14))
        p = self.player
        wname = p.weapon["name"] + (f" x{p.uses}" if p.uses is not None else "")
        right = font.render(f"{wname}  |  Зомби: {len(self.zombies)}", True, white)
        s.blit(right, (W - right.get_width() - 16, 14))
        if self.school:  # вместо полоски босса — сколько ещё держаться
            left = max(0.0, SCHOOL_TIME - self.school["t"])
            bar = pygame.Rect(W // 2 - 220, 62, 440, 18)
            pygame.draw.rect(s, INK, bar.inflate(6, 6))
            pygame.draw.rect(s, (70, 40, 20), bar)
            pygame.draw.rect(s, (255, 170, 50), (bar.x, bar.y, int(bar.w * left / SCHOOL_TIME), bar.h))
            text = f"ШКОЛА ПРОТИВ ТЕБЯ — продержись: {int(left) + 1} с"
            label, shadow = font.render(text, True, (255, 255, 255)), font.render(text, True, INK)
            pos = label.get_rect(midtop=(W // 2, 84))
            for ox, oy in ((-2, 0), (2, 0), (0, -2), (0, 2)):
                s.blit(shadow, pos.move(ox, oy))
            s.blit(label, pos)
        if self.mini and self.mini.state != "dying":
            m = self.mini
            bar = pygame.Rect(W // 2 - 220, 62, 440, 18)
            pygame.draw.rect(s, INK, bar.inflate(6, 6))
            pygame.draw.rect(s, (90, 30, 40), bar)
            pygame.draw.rect(s, (230, 60, 80), (bar.x, bar.y, int(bar.w * max(0, m.hp) / m.maxhp), bar.h))
            for k in (1, 2):  # три головы — три части полоски
                pygame.draw.rect(s, INK, (bar.x + bar.w * k // 3 - 2, bar.y - 3, 4, bar.h + 6))
            text = "ЧУНГУК + МИНГУК + ДУНДУК"
            label, shadow = font.render(text, True, (255, 255, 255)), font.render(text, True, INK)
            pos = label.get_rect(midtop=(W // 2, 84))
            for ox, oy in ((-2, 0), (2, 0), (0, -2), (0, 2)):
                s.blit(shadow, pos.move(ox, oy))
            s.blit(label, pos)
        if self.final and self.final.state != "dying":
            f = self.final
            bar = pygame.Rect(W // 2 - 220, 62, 440, 18)
            pygame.draw.rect(s, INK, bar.inflate(6, 6))
            pygame.draw.rect(s, (90, 30, 40), bar)
            pygame.draw.rect(s, (230, 60, 80), (bar.x, bar.y, int(bar.w * max(0, f.hp) / f.maxhp), bar.h))
            text = "ШКОЛА — бей по упавшему колоколу!" if f.state in ("drop", "vuln") else "ШКОЛА — уворачивайся!"
            label, shadow = font.render(text, True, (255, 255, 255)), font.render(text, True, INK)
            pos = label.get_rect(midtop=(W // 2, 84))
            for ox, oy in ((-2, 0), (2, 0), (0, -2), (0, 2)):
                s.blit(shadow, pos.move(ox, oy))
            s.blit(label, pos)
        if self.boss and self.boss.state not in ("dying", "hide"):
            b = self.boss
            bar = pygame.Rect(W // 2 - 220, 62, 440, 18)
            pygame.draw.rect(s, INK, bar.inflate(6, 6))
            pygame.draw.rect(s, (90, 30, 40), bar)
            pygame.draw.rect(s, (230, 60, 80), (bar.x, bar.y, int(bar.w * max(0, b.hp) / b.maxhp), bar.h))
            label = font.render("ДИРЕКТОР-ЗОМБИ", True, (255, 255, 255))
            shadow = font.render("ДИРЕКТОР-ЗОМБИ", True, INK)
            pos = label.get_rect(midtop=(W // 2, 84))
            for ox, oy in ((-2, 0), (2, 0), (0, -2), (0, 2)):
                s.blit(shadow, pos.move(ox, oy))
            s.blit(label, pos)
        if self.msg:
            txt = font.render(self.msg[0], True, (255, 255, 255))
            r = txt.get_rect(center=(W // 2, 150)).inflate(24, 12)
            pygame.draw.rect(s, INK, r, border_radius=8)
            s.blit(txt, txt.get_rect(center=r.center))
        if self.door_open:
            s.blit(font.render("Дверь открыта! Беги вправо", True, (255, 255, 255)), (W // 2 - 140, 62))
        near = self.weapon_item_near()
        if near and not self.over:
            name = WEAPONS[near["kind"]]["name"]
            txt = font.render((f"Нажми ВЗЯТЬ: {name}" if touch.enabled else f"E — взять: {name}"), True, (255, 255, 255))
            box = txt.get_rect(midbottom=(near["rect"].centerx, near["rect"].top - 12)).inflate(16, 8)
            box.clamp_ip(s.get_rect())
            pygame.draw.rect(s, INK, box, border_radius=6)
            s.blit(txt, txt.get_rect(center=box.center))
        if self.over:
            shade = pygame.Surface((W, H), pygame.SRCALPHA)
            shade.fill((0, 0, 0, 150))
            s.blit(shade, (0, 0))
            t = big.render("Зомби победили", True, (255, 255, 255))
            s.blit(t, (W // 2 - t.get_width() // 2, 200))
            t = font.render(f"Зачищено комнат: {len(self.cleared)}." + ("" if touch.enabled else " Нажми R, чтобы заново"), True, (255, 255, 255))
            s.blit(t, (W // 2 - t.get_width() // 2, 270))
        if self.state == "win":
            shade = pygame.Surface((W, H), pygame.SRCALPHA)
            shade.fill((0, 0, 0, 150))
            s.blit(shade, (0, 0))
            t = big.render("ПОБЕДА!", True, (255, 235, 120))
            s.blit(t, (W // 2 - t.get_width() // 2, 180))
            t = font.render("Директор повержен, школа спасена.", True, (255, 255, 255))
            s.blit(t, (W // 2 - t.get_width() // 2, 265))
            t = font.render((f"Тапни — новый круг ({self.round + 1}-й, зомби и босс сильнее)." if touch.enabled else
                             f"Enter — новый круг ({self.round + 1}-й, зомби и босс сильнее).  R — заново."),
                            True, (255, 255, 255))
            s.blit(t, (W // 2 - t.get_width() // 2, 310))

    def draw_player(self, s):
        p = self.player
        sp = self.sprites
        if p.hurt_cd > 0 and int(p.hurt_cd * 20) % 2:
            return  # мигает после удара
        r = p.rect
        if not p.on_ground:
            name = "jump"
        elif abs(p.vx) > 1:
            kind, step = ("run", STEP_RUN) if p.running else ("walk", STEP_WALK)
            name = f"{kind}{int(p.anim / step) % 4}"
        else:
            name = "idle"
        img = sp.player[name]
        if p.face < 0:
            img = pygame.transform.flip(img, True, False)
        s.blit(img, (r.x - SPRITE_PAD, r.bottom - img.get_height()))

        key, kind = p.weapon["key"], p.weapon["type"]
        if p.shield_t > 0:  # тетрадь поднята перед героем
            shield = sp.weapon["notebook"][0]
            s.blit(shield, shield.get_rect(center=(r.centerx + p.face * 30, r.y + 32)))
        elif kind == "melee":
            if p.swing > 0:
                a = p.attack_rect()
                if key != "fists":
                    big_img = sp.weapon[key][0]
                    if p.face < 0:
                        big_img = pygame.transform.flip(big_img, True, False)
                    s.blit(big_img, (a.x, a.y + 8))
                else:
                    fist = sp.fist
                    fx = a.right - fist.get_width() if p.face > 0 else a.left
                    s.blit(fist, (fx, a.y + 12))
            elif key != "fists":
                held = pygame.transform.rotate(sp.weapon[key][1], 60 if p.face > 0 else 120)
                s.blit(held, held.get_rect(center=(r.centerx + p.face * 24, r.y + 28)))
            else:
                fist = sp.fist
                s.blit(fist, (r.centerx + p.face * 22 - fist.get_width() // 2, r.y + 32))
        else:  # стреляет, кидает, звонок, тетрадь опущена — держит перед собой
            img = sp.weapon[key][1]
            if p.face < 0:
                img = pygame.transform.flip(img, True, False)
            kick = -p.face * 4 if p.swing > 0 else 0  # отдача
            hand = (r.centerx + p.face * 16 + kick, r.y + 34)
            s.blit(img, img.get_rect(midleft=hand) if p.face > 0 else img.get_rect(midright=hand))

    def draw_school_bg(self, s):
        """Школа ожила: фон краснеет, сверху и снизу — зубы."""
        t = pygame.time.get_ticks() / 1000
        tint = pygame.Surface((W, H), pygame.SRCALPHA)
        tint.fill((120, 10, 20, 70))
        s.blit(tint, (0, 0))
        open_ = 14 + int(math.sin(t * 2.2) * 10)
        for x in range(-24, W, 48):
            pts = [(x, 52), (x + 48, 52), (x + 24, 52 + 36 + open_)]
            pygame.draw.polygon(s, (240, 240, 228), pts)
            pygame.draw.polygon(s, INK, pts, 3)
        for x in range(0, W, 48):
            pts = [(x, FLOOR), (x + 48, FLOOR), (x + 24, FLOOR - 30 - open_ // 2)]
            pygame.draw.polygon(s, (240, 240, 228), pts)
            pygame.draw.polygon(s, INK, pts, 3)

    def draw_school_hazards(self, s, hazards):
        sp = self.sprites
        blink = int(pygame.time.get_ticks() / 90) % 2
        for hz in hazards:
            if hz["type"] == "drop":
                if hz["warn"] > 0:  # красная тень на полу и стрелка сверху
                    if blink:
                        pygame.draw.rect(s, (235, 60, 60), (hz["x"] - 36, FLOOR - 6, 72, 6))
                        pygame.draw.polygon(s, (235, 60, 60), [(hz["x"] - 14, 62), (hz["x"] + 14, 62), (hz["x"], 88)])
                else:
                    img = sp.school[hz["kind"]]
                    s.blit(img, img.get_rect(midtop=(hz["x"], int(hz["y"]))))
            else:
                if hz["warn"] > 0:  # красная стрелка у края, откуда прилетит
                    if blink:
                        ex = 20 if hz["dir"] > 0 else W - 20
                        pts = [(ex, FLOOR - 50), (ex, FLOOR - 10), (ex + 30 * hz["dir"], FLOOR - 30)]
                        pygame.draw.polygon(s, (235, 60, 60), pts)
                else:
                    img = sp.school["desk"]
                    s.blit(img, (int(hz["x"]) - 35, int(hz["y"])))

    def draw_final(self, s):
        """Колокол школы: висит на верёвке, падает на пол, и тогда его можно бить."""
        sp, f = self.sprites, self.final
        r, t = f.rect, pygame.time.get_ticks() / 1000
        shake = random.choice((-4, 4)) if f.state == "dying" else 0
        cx = r.centerx + shake
        pygame.draw.line(s, INK, (cx, 0), (cx, r.top + 8), 8)  # верёвка
        pygame.draw.line(s, (205, 175, 105), (cx, 0), (cx, r.top + 8), 4)
        if f.state in ("drop", "vuln"):  # золотое свечение: сейчас можно бить
            aura = pygame.Surface((160, 160), pygame.SRCALPHA)
            pygame.draw.circle(aura, (255, 230, 90, 90), (80, 80), 60 + int(math.sin(t * 8) * 8))
            s.blit(aura, aura.get_rect(center=r.center))
        img = sp.big_bell_flash if f.flash > 0 else sp.big_bell
        if f.state == "dying" and f.t > 1.0:
            img = img.copy()
            img.set_alpha(int(255 * max(0.0, 1 - (f.t - 1.0))))
        s.blit(img, img.get_rect(center=(cx, r.centery)))
        if f.state == "vuln" and int(t * 6) % 2:  # красная стрелка над колоколом
            pygame.draw.polygon(s, (235, 60, 60), [(cx - 16, r.top - 44), (cx + 16, r.top - 44), (cx, r.top - 14)])

    def draw_mini(self, s):
        sp, m = self.sprites, self.mini
        r = m.rect
        mask = {3: "111", 2: "110", 1: "100"}[m.heads]
        if m.state == "dying":
            img = sp.mini[f"walk0_{mask}"]
            img = pygame.transform.rotate(img, -90 * (-m.face) * min(1.0, m.t / 0.5))
            if m.t > 0.9:
                img.set_alpha(int(255 * max(0.0, 1 - (m.t - 0.9) / 0.6)))
            s.blit(img, img.get_rect(midbottom=(r.centerx, r.bottom)))
            return
        if m.state in ("w_charge", "w_coins", "w_stomp", "charge"):
            pose = "attack"
        else:
            pose = "walk0" if int(m.anim / 24) % 2 == 0 else "walk1"
        key = f"{pose}_{mask}" + ("_flash" if m.flash > 0 else "")
        img = sp.mini[key]
        dx = random.choice((-4, 4)) if m.state == "w_charge" else 0  # трясётся перед рывком
        s.blit(img, img.get_rect(midbottom=(r.centerx + dx, r.bottom)))
        if m.state == "tired" or m.stun_t > 0:
            self.draw_stars(s, r.centerx, r.y - 20)

    def draw_stars(self, s, cx, top):
        """Звёздочки над оглушённым."""
        for i in range(3):
            a = pygame.time.get_ticks() / 250 + i * 2.1
            pygame.draw.rect(s, (255, 235, 90), (cx + int(math.cos(a) * 24) - 3, top - 8 + int(math.sin(a) * 6), 6, 6))

    def draw_fx(self, s):
        for e in self.fx:
            t = e["t"]
            if e["type"] == "boom":
                r = max(2, int(e["R"] * min(1.0, t / 0.12)))
                fade = max(0.0, 1 - t / 0.45)
                surf = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
                pygame.draw.circle(surf, (255, 150, 40, int(190 * fade)), (r, r), r)
                pygame.draw.circle(surf, (255, 235, 120, int(230 * fade)), (r, r), max(1, int(r * 0.6)))
                s.blit(surf, (int(e["x"]) - r, int(e["y"]) - r))
            elif e["type"] == "hit":  # быстрое кольцо в месте удара
                r = int(8 + 20 * min(1.0, t / 0.16))
                if t < 0.16:
                    pygame.draw.circle(s, (255, 255, 255), (int(e["x"]), int(e["y"])), r, 3)
            else:  # волна от звонка
                r = int(560 * min(1.0, t / 0.4))
                if r > 4:
                    pygame.draw.circle(s, (255, 225, 90), (int(e["x"]), int(e["y"])), r, 6)

    def draw_zombie(self, s, z):
        sp = self.sprites
        r = z.rect
        if z.bite_cd > 0.75:
            frame = "bite"  # только что укусил
        elif not z.on_ground:
            frame = "walk1"
        else:
            frame = f"walk{int(z.anim / 18) % 4}"
        if z.flash > 0:
            frame += "_flash"
        img = sp.zombie[frame]
        if z.face > 0:
            s.blit(img, (r.centerx - 24, r.bottom - img.get_height()))
        else:
            s.blit(pygame.transform.flip(img, True, False), (r.centerx - 28, r.bottom - img.get_height()))
        if z.stun_t > 0:
            self.draw_stars(s, r.centerx, r.y)
        elif z.slow_t > 0:  # замедлен пеной — белые пузырьки
            for i in range(3):
                bx = r.x + 6 + i * 12
                pygame.draw.rect(s, (235, 245, 255), (bx, r.y - 6 - (pygame.time.get_ticks() // 200 + i) % 3 * 3, 6, 6))

    def draw_boss(self, s):
        sp, b = self.sprites, self.boss
        r = b.rect
        if b.state == "hide":
            return
        if b.state == "dying":
            img = sp.boss["walk1"]
            if b.face < 0:
                img = pygame.transform.flip(img, True, False)
            fall = -b.face  # падает спиной вперёд
            img = pygame.transform.rotate(img, -90 * fall * min(1.0, b.t / 0.4))
            if b.t > 0.8:
                img.set_alpha(int(255 * (1 - (b.t - 0.8) / 0.6)))
            s.blit(img, img.get_rect(midbottom=(r.centerx, r.bottom)))
            return
        if b.state == "throw":
            name = "throw"
        elif b.state in ("windup", "charge"):
            name = "charge"
        elif b.state == "tired" or b.stun_t > 0:
            name = "walk1"
        else:
            name = f"walk{int(b.anim / 26) % 4}"
        if b.flash > 0 or (b.state == "windup" and int(b.t * 14) % 2):
            name += "_flash"  # белая вспышка при ударе; мигает перед тараном
        img = sp.boss[name]
        dx = random.choice((-4, 4)) if b.state == "windup" else 0  # трясётся
        if b.face > 0:
            s.blit(img, (r.centerx - 36 + dx, r.bottom - img.get_height()))
        else:
            s.blit(pygame.transform.flip(img, True, False), (r.centerx - 42 + dx, r.bottom - img.get_height()))
        if b.state == "tired" or b.stun_t > 0:
            self.draw_stars(s, r.centerx, r.y)

    def draw_actor(self, s, a, cx, moving):
        sp, face, kind, pose = self.sprites, a["face"], a["kind"], a.get("pose")
        if kind == "hero" or kind in sp.humans:  # люди: ты, три хулигана, девочка
            frames = sp.player if kind == "hero" else sp.humans[kind]
            if pose == "fallen":
                img = frames["idle"]
                if face < 0:
                    img = pygame.transform.flip(img, True, False)
                img = pygame.transform.rotate(img, 90 * face)  # лежит на асфальте
                s.blit(img, img.get_rect(midbottom=(cx, FLOOR)))
                return
            img = frames[f"walk{int(abs(cx) / 30) % 4}" if moving else "idle"]
            if face < 0:
                img = pygame.transform.flip(img, True, False)
            s.blit(img, (cx - img.get_width() // 2, FLOOR - img.get_height()))
        elif kind == "mini":
            img = sp.mini[("attack" if pose == "attack" else "walk0") + "_111"]
            s.blit(img, img.get_rect(midbottom=(cx, FLOOR)))
        elif kind == "zombie":
            frames = sp.zombie_v.get(a.get("color"), sp.zombie)
            frame = "bite" if pose == "bite" else (f"walk{int(cx / 18) % 4}" if moving else "walk1")
            img = frames[frame]
            if face > 0:
                s.blit(img, (cx - 24, FLOOR - img.get_height()))
            else:
                s.blit(pygame.transform.flip(img, True, False), (cx - 28, FLOOR - img.get_height()))
        else:  # boss
            if pose == "fallen":
                img = sp.boss["walk1"]
                if face < 0:
                    img = pygame.transform.flip(img, True, False)
                img = pygame.transform.rotate(img, 90 * face)  # лежит на спине
                s.blit(img, img.get_rect(midbottom=(cx, FLOOR)))
                return
            name = pose if pose in ("throw", "charge") else (f"walk{int(cx / 26) % 4}" if moving else "walk1")
            img = sp.boss[name]
            if face > 0:
                s.blit(img, (cx - 36, FLOOR - img.get_height()))
            else:
                s.blit(pygame.transform.flip(img, True, False), (cx - 42, FLOOR - img.get_height()))

    def draw_cutscene(self, s, font):
        cut = self.cut
        scene = cut["scene"]
        kind, variant = scene["bg"]
        theme = THEMES[kind]
        theme["back"](s, variant)
        for rect, fk in theme["build"](variant):
            draw_furniture(s, rect, fk)
        beat = scene["beats"][cut["i"]]
        t = cut["t"]
        prog = min(1.0, t / 1.2)
        base_w = {"mini": 120, "boss": 92, "zombie": 56}
        for a in cut["actors"]:  # тени под ногами
            if a.get("pose") != "fallen":
                draw_shadow(s, a["x"] + (a["to"] - a["x"]) * prog, FLOOR, FLOOR, base_w.get(a["kind"], 62))
        for a in cut["actors"]:
            self.draw_actor(s, a, a["x"] + (a["to"] - a["x"]) * prog, a["to"] != a["x"] and prog < 1.0)
        beams = theme.get("beams", [])
        s.blit(make_overlay(beams), (0, 0))
        if kind not in self.cut_motes:
            self.cut_motes[kind] = make_motes(beams, 22, seed=3)
        draw_motes(s, self.cut_motes[kind], pygame.time.get_ticks() / 1000)

        # чёрные полосы, как в кино
        pygame.draw.rect(s, (0, 0, 0), (0, 0, W, 36))
        pygame.draw.rect(s, (0, 0, 0), (0, H - 36, W, 36))

        # подпись: имя и текст, который «печатается»
        who, text = beat.get("who", ""), beat["text"]
        words, lines, cur = text.split(" "), [], ""
        for w in words:
            trial = (cur + " " + w).strip()
            if font.size(trial)[0] > W - 80:
                lines.append(cur)
                cur = w
            else:
                cur = trial
        lines.append(cur)
        box_h = 24 + (30 if who else 0) + len(lines) * 30
        box = pygame.Surface((W - 40, box_h), pygame.SRCALPHA)
        box.fill((15, 15, 25, 228))
        s.blit(box, (20, 46))
        pygame.draw.rect(s, (255, 255, 255), (20, 46, W - 40, box_h), 2)
        y = 56
        if who:
            s.blit(font.render(who, True, SPEAKERS.get(who, (255, 255, 255))), (36, y))
            y += 30
        left = int(t * TYPE_SPEED)
        for line in lines:
            s.blit(font.render(line[:max(0, left)], True, (255, 255, 255)), (36, y))
            left -= len(line) + 1
            y += 30
        small = pixel_font(16)
        done = int(t * TYPE_SPEED) >= len(text)
        hint = ("Тапни — дальше" if touch.enabled else "Enter / клик — дальше") if done else "Enter — показать всё"
        tip = small.render(hint + ("" if touch.enabled else "      Esc — пропустить"), True, (200, 205, 220))
        s.blit(tip, tip.get_rect(midbottom=(W // 2, H - 8)))

    def draw_corpse(self, s, c):
        t = c["t"]
        img = self.sprites.zombie["walk1_flash" if t < 0.12 else "walk1"]
        if c["face"] < 0:
            img = pygame.transform.flip(img, True, False)
        angle = -90 * c["fall"] * min(1.0, t / 0.3)  # падает в сторону удара
        img = pygame.transform.rotate(img, angle)
        if t > 0.5:
            img.set_alpha(int(255 * (1 - (t - 0.5) / (CORPSE_TIME - 0.5))))
        s.blit(img, img.get_rect(midbottom=(c["cx"], c["bottom"])))


async def main():
    pygame.init()
    screen = pygame.display.set_mode((W, H))
    pygame.display.set_caption("Зомби-школа")
    font = pixel_font(24)
    big = pixel_font(64)
    clock = pygame.time.Clock()
    game = Game()
    if "--test" in sys.argv:  # python game.py --test — проверка оружия
        game.test_mode, game.cutscenes = True, False
        game.start_room("c1")
        game.msg = ["Режим проверки: Q — следующее оружие", 3.0]
    elif "--boss" in sys.argv:  # python game.py --boss — сразу к директору, с дубиной в руках
        game.player.weapon = CLUB
        game.play_scene("boss_intro", ("room", "office"))
    elif "--mini" in sys.argv:  # python game.py --mini — сразу мини-босс (Класс 7)
        game.cutscenes = False
        game.player.weapon = CLUB
        game.start_room("c7")
    elif "--final" in sys.argv:  # python game.py --final — сразу финал со школой
        game.cutscenes = False
        game.player.weapon = CLUB
        game.start_room("school")
    elif "--school" in sys.argv:  # python game.py --school — сразу «ты против школы» (круг 2, у босса 50%)
        game.round, game.cutscenes = 2, False
        game.player.weapon = CLUB
        game.start_room("office")
        game.boss.hp = game.boss.maxhp // 2
    else:
        game.begin()
    keys_map = (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN,
                pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE)
    def click(pos):
        """Нажатие мышью или пальцем в местах, где нет джойстика: карта, катсцена, победа, поражение."""
        if game.state == "map":
            game.map_hover(pos)
            game.map_click(pos)
        elif game.state == "cutscene":
            if touch.enabled and SKIP_RECT.collidepoint(pos):
                game.skip_scene()
            else:
                game.advance_scene()
        elif game.state == "win":
            if touch.enabled:
                game.next_round()
        elif game.over and touch.enabled and RESTART_RECT.collidepoint(pos):
            game.restart()

    last_state = (None, None)
    while True:
        dt = clock.tick(FPS) / 1000
        if (game.state, game.over) != last_state:  # сменилась сцена — отпускаем кнопки на экране
            touch.reset()
            last_state = (game.state, game.over)
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if touch.handle(e, game.state == "play" and not game.over):
                pass
            elif e.type == pygame.FINGERDOWN:
                click((e.x * W, e.y * H))
            elif e.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEMOTION) and getattr(e, "touch", False):
                pass  # копию мыши от пальца не берём: палец уже обработан выше
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                click(e.pos)
            elif e.type == pygame.MOUSEMOTION and game.state == "map":
                game.map_hover(e.pos)
            key = e.key if e.type == pygame.KEYDOWN else None
            if key == pygame.K_r:
                game.restart()
            elif game.state == "map":
                if key in keys_map:
                    game.map_key(key)
            elif game.state == "cutscene":
                if key == pygame.K_ESCAPE:
                    game.skip_scene()
                elif key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                    game.advance_scene()
            elif game.state == "win":
                if key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    game.next_round()
            elif key == pygame.K_e:
                game.take_weapon()
            elif key == pygame.K_q and game.test_mode:
                game.cycle_weapon()
            elif key == pygame.K_m:
                game.open_map()
            elif key == pygame.K_b and not game.over:
                game.start_room("office")
        for act in touch.take_pending():
            if game.state == "play" and not game.over:
                game.take_weapon() if act == "take" else game.open_map()
        mouse_down = pygame.mouse.get_pressed()[0] and not touch.enabled  # при кнопках на экране мышь не бьёт
        game.update(dt, MergedKeys(pygame.key.get_pressed()), mouse_down)
        game.draw(screen, font, big)
        touch.draw(screen, game.state, game.over)
        pygame.display.flip()
        await asyncio.sleep(0)  # нужно для веб-версии (браузер), на компьютере ничего не меняет


if __name__ == "__main__":
    asyncio.run(main())
