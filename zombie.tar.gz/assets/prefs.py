"""Настройки игрока: режим, скин, переключатели. Запоминаются между запусками.

На компьютере лежат в файле `.zombie_school.json` в домашней папке, в браузере телефона — в localStorage.
Любая ошибка чтения/записи тихо игнорируется: игра должна работать, даже если сохранить нельзя.
"""
import json
import os
import sys

DEFAULTS = {
    "mode": "normal",    # normal — умер: комната заново; hardcore — умер: всё сначала
    "skin": "blue",
    "shake": True,       # тряска экрана
    "light": True,       # лучи света, пылинки и тёмные края
    "buttons": "auto",   # экранные кнопки: auto (появляются при касании), on, off
    "easy": "auto",      # лёгкие боссы: auto (на телефоне), on, off
    "opacity": 1,        # прозрачность кнопок: 0 сильная, 1 средняя, 2 слабая
    "coins": 0,          # монеты: за них покупают скины и классы
    "owned_skins": ["blue"],
    "owned_classes": ["normal"],
    "klass": "normal",   # выбранный класс героя
    "ch1_done": False,   # глава 1 пройдена: открывает главу 2
    "fps": False,        # показывать счётчик кадров в секунду (чтобы понять, тормозит ли игра)
}
KEY = "zombie_school"
data = dict(DEFAULTS)
READONLY = False   # режим проверки (--all): ничего не сохраняем, настоящий прогресс не портится


def _path():
    return os.path.join(os.path.expanduser("~"), ".zombie_school.json")


def load():
    if os.environ.get("ZOMBIE_NO_SAVE"):  # тесты: всегда настройки по умолчанию
        return
    try:
        if sys.platform == "emscripten":
            import platform
            raw = platform.window.localStorage.getItem(KEY)
            saved = json.loads(str(raw)) if raw else {}
        else:
            with open(_path(), encoding="utf-8") as fh:
                saved = json.load(fh)
        for k, v in saved.items():
            if k in DEFAULTS and type(v) is type(DEFAULTS[k]):
                data[k] = v
        # скины раньше были бесплатными: тот, что уже выбран, оставляем у игрока
        data["owned_skins"] = list(data["owned_skins"])
        if data["skin"] not in data["owned_skins"]:
            data["owned_skins"].append(data["skin"])
    except Exception:
        pass


def save():
    if READONLY or os.environ.get("ZOMBIE_NO_SAVE"):  # тесты не должны трогать настоящие настройки
        return
    try:
        text = json.dumps(data, ensure_ascii=False)
        if sys.platform == "emscripten":
            import platform
            platform.window.localStorage.setItem(KEY, text)
        else:
            with open(_path(), "w", encoding="utf-8") as fh:
                fh.write(text)
    except Exception:
        pass


def get(key):
    return data.get(key, DEFAULTS[key])


def set(key, value):
    data[key] = value
    save()


load()
