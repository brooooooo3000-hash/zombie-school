"""Пиксельные буквы.

Хитрость простая: рисуем текст маленьким шрифтом БЕЗ сглаживания, потом увеличиваем каждый пиксель
в 2 или 4 раза. Получаются резкие «квадратные» буквы, как в старых играх, и русские тоже.

pixel_font(24) работает как обычный шрифт pygame: .render(текст, True, цвет) и .size(текст).
Хочешь другой вид букв — поменяй FONT_NAME (например "verdana" или "consolas").
"""
import os

import pygame

FONT_NAME = "tahoma"
_fonts = {}


class PixelFont:
    def __init__(self, size):
        # size — «обычный» размер текста; k — во сколько раз увеличиваем пиксели
        self.k = 4 if size >= 48 else (2 if size >= 20 else 1)
        base = max(9, round(size / self.k * (0.5 if self.k == 2 and size < 30 else 1.0)))
        if self.k == 1:
            base = max(10, round(size * 0.82))
        if self.k == 4:
            base = round(size / 4)
        path = pygame.font.match_font(FONT_NAME, bold=True)
        if path:
            self.font = pygame.font.Font(path, base)
        else:  # нет Tahoma (веб-версия, телефон) — берём шрифт из pygame, в нём есть русские буквы
            self.font = pygame.font.Font(os.path.join(os.path.dirname(pygame.__file__), "freesansbold.ttf"), base)
        self.cache = {}

    def size(self, text):
        w, h = self.font.size(text)
        return w * self.k, h * self.k

    def get_height(self):
        return self.font.get_height() * self.k

    def render(self, text, antialias=True, color=(255, 255, 255)):
        """antialias игнорируется: пиксельный шрифт всегда резкий."""
        key = (text, tuple(color))
        surf = self.cache.get(key)
        if surf is None:
            small = self.font.render(text, False, color)
            surf = small if self.k == 1 else pygame.transform.scale(
                small, (small.get_width() * self.k, small.get_height() * self.k))
            if len(self.cache) > 500:  # чтобы память не росла от «печатающегося» текста
                self.cache.clear()
            self.cache[key] = surf
        return surf


def pixel_font(size):
    if size not in _fonts:
        _fonts[size] = PixelFont(size)
    return _fonts[size]
