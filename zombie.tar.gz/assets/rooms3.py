"""Глава 2 «Мегамаркет»: отделы магазина ночью. У каждого свой вид, как в настоящих магазинах.

Как в rooms.py: build_xxx — мебель (на неё можно запрыгнуть), back_xxx — фон, THEMES3 — тема комнаты.
Отделы: овощи и фрукты, мясной, молочный, пекарня, бакалея, бытовая химия, игрушки, электроника,
туалет для сотрудников и склад (босс).
"""
import math

import pygame

import rooms
from pixelfont import pixel_font
from rooms import box
from settings import FLOOR, H, INK, W

MARKET_KINDS = ("produce", "meat", "dairy", "bakery", "grocery", "chem", "toys", "electro", "mtoilet", "warehouse")
KINDS3 = ("apples", "veg", "meatcase", "fridge", "breadrack", "aisle", "chemshelf", "toyshelf", "tvwall", "pallet",
          "cartpl")


# ---------------------------------------------------------------- общие кусочки магазина
def ceiling(s, lamp=(235, 240, 255), dark=(70, 74, 88), off_every=4):
    """Потолок с лампами дневного света. Часть ламп выключена: магазин работает ночью."""
    pygame.draw.rect(s, dark, (0, 0, W, 46))
    pygame.draw.rect(s, INK, (0, 44, W, 3))
    tick = pygame.time.get_ticks()
    for i, x in enumerate(range(40, W - 60, 150)):
        on = (i % off_every != 1) or (tick // 130 + i) % 9 > 1   # одна лампа мигает
        pygame.draw.rect(s, INK, (x - 2, 22, 104, 14))
        pygame.draw.rect(s, lamp if on else (110, 112, 125), (x, 24, 100, 10))


def sign(s, cx, text, fill, ink=(255, 255, 255), y=56):
    """Вывеска отдела на цепочках."""
    f = pixel_font(24)
    t = f.render(text, True, ink)
    r = pygame.Rect(0, y, t.get_width() + 40, 40)
    r.centerx = cx
    for x in (r.x + 14, r.right - 14):
        pygame.draw.rect(s, INK, (x - 2, 46, 4, y - 46))
    box(s, r, fill)
    s.blit(t, t.get_rect(center=r.center))


def store_floor(s, base, line, step=60):
    pygame.draw.rect(s, base, (0, FLOOR, W, H - FLOOR))
    for tx in range(0, W, step):
        pygame.draw.rect(s, line, (tx, FLOOR + 2, 3, H - FLOOR))
    for ty in range(FLOOR + 34, H, 34):
        pygame.draw.rect(s, line, (0, ty, W, 3))
    pygame.draw.rect(s, INK, (0, FLOOR, W, 4))


def goods_row(s, x, y, w, colors, h=30, bw=22):
    """Ряд коробок и банок на полке."""
    pygame.draw.rect(s, INK, (x, y + h, w, 6))
    for i, bx in enumerate(range(x + 4, x + w - bw, bw + 4)):
        c = colors[i % len(colors)]
        pygame.draw.rect(s, INK, (bx, y + 4, bw, h - 4))
        pygame.draw.rect(s, c, (bx + 2, y + 6, bw - 4, h - 8))
        pygame.draw.rect(s, (255, 255, 255), (bx + 4, y + 10, bw - 8, 5))


def wall(s, color, panel, panel_y=330):
    s.fill(color)
    pygame.draw.rect(s, panel, (0, panel_y, W, FLOOR - panel_y))
    pygame.draw.rect(s, INK, (0, panel_y, W, 4))


# ---------------------------------------------------------------- 1. ОВОЩИ И ФРУКТЫ
def build_produce(variant=0):
    return [(pygame.Rect(90, 405, 150, 14), "apples"), (pygame.Rect(330, 405, 130, 14), "veg"),
            (pygame.Rect(540, 405, 150, 14), "apples"), (pygame.Rect(740, 405, 130, 14), "apples"),
            (pygame.Rect(400, 320, 120, 14), "aisle")]


def back_produce(s, variant=0):
    wall(s, (205, 232, 190), (176, 210, 160))
    for x in range(30, W - 60, 300):  # плакаты с овощами
        box(s, (x, 110, 90, 100), (250, 245, 220))
        pygame.draw.circle(s, (215, 50, 55), (x + 30, 160), 18)
        pygame.draw.circle(s, (240, 140, 40), (x + 64, 170), 14)
        pygame.draw.rect(s, (60, 140, 60), (x + 26, 138, 8, 8))
    sign(s, 480, "ОВОЩИ И ФРУКТЫ", (70, 150, 70))
    ceiling(s)
    store_floor(s, (190, 200, 175), (160, 172, 145))


# ---------------------------------------------------------------- 2. МЯСНОЙ ОТДЕЛ
def build_meat(variant=0):
    return [(pygame.Rect(70, 400, 190, 14), "meatcase"), (pygame.Rect(330, 340, 130, 14), "aisle"),
            (pygame.Rect(540, 400, 190, 14), "meatcase"), (pygame.Rect(790, 340, 120, 14), "aisle")]


def back_meat(s, variant=0):
    wall(s, (240, 218, 215), (225, 195, 192))
    for y in range(110, FLOOR - 20, 40):  # кафельные полосы
        pygame.draw.rect(s, (205, 175, 172), (0, y, W, 2))
    pygame.draw.rect(s, INK, (0, 112, W, 6))
    for x in range(60, W - 40, 110):  # крюки с колбасой
        pygame.draw.line(s, INK, (x, 118), (x, 140), 3)
        pygame.draw.rect(s, (190, 70, 60), (x - 8, 140, 16, 44))
        pygame.draw.rect(s, INK, (x - 8, 140, 16, 44), 3)
    sign(s, 480, "МЯСНОЙ ОТДЕЛ", (170, 45, 55))
    ceiling(s, lamp=(255, 225, 225))
    store_floor(s, (210, 190, 190), (180, 160, 160))


# ---------------------------------------------------------------- 3. МОЛОЧНЫЙ ОТДЕЛ
def build_dairy(variant=0):
    return [(pygame.Rect(60, 395, 150, 14), "fridge"), (pygame.Rect(290, 340, 140, 14), "aisle"),
            (pygame.Rect(500, 395, 150, 14), "fridge"), (pygame.Rect(740, 335, 150, 14), "fridge")]


def back_dairy(s, variant=0):
    wall(s, (215, 232, 250), (190, 212, 238))
    for x in range(40, W - 100, 160):  # стена из холодильников с молоком
        box(s, (x, 110, 140, 200), (235, 245, 255))
        for r in range(3):
            goods_row(s, x + 6, 118 + r * 62, 128, [(250, 250, 255), (120, 170, 240), (250, 200, 120)], h=40, bw=18)
    sign(s, 480, "МОЛОЧНЫЙ ОТДЕЛ", (60, 110, 190))
    ceiling(s, lamp=(225, 240, 255))
    store_floor(s, (200, 215, 235), (170, 190, 215))


# ---------------------------------------------------------------- 4. ПЕКАРНЯ
def build_bakery(variant=0):
    return [(pygame.Rect(80, 400, 160, 14), "breadrack"), (pygame.Rect(320, 345, 130, 14), "aisle"),
            (pygame.Rect(530, 400, 160, 14), "breadrack"), (pygame.Rect(760, 345, 130, 14), "aisle")]


def back_bakery(s, variant=0):
    wall(s, (245, 225, 185), (225, 195, 150))
    pulse = 0.5 + 0.5 * math.sin(pygame.time.get_ticks() / 400)
    for x in (80, 700):  # печи: за стеклом огонь
        box(s, (x, 150, 170, 150), (80, 70, 70))
        pygame.draw.rect(s, (255, int(120 + 80 * pulse), 40), (x + 14, 168, 142, 100))
        pygame.draw.rect(s, INK, (x + 14, 168, 142, 100), 3)
        for i in range(3):
            pygame.draw.rect(s, (200, 120, 50), (x + 24 + i * 44, 215, 34, 22), border_radius=8)
    box(s, (400, 130, 120, 90), (240, 235, 215))
    pygame.draw.circle(s, INK, (460, 175), 28, 4)
    pygame.draw.line(s, INK, (460, 175), (460, 155), 4)
    pygame.draw.line(s, INK, (460, 175), (476, 183), 4)
    sign(s, 480, "ПЕКАРНЯ", (200, 120, 50))
    ceiling(s, lamp=(255, 240, 200))
    store_floor(s, (215, 195, 160), (185, 165, 130))


# ---------------------------------------------------------------- 5. БАКАЛЕЯ
def build_grocery(variant=0):
    return [(pygame.Rect(70, 400, 160, 14), "aisle"), (pygame.Rect(300, 340, 150, 14), "aisle"),
            (pygame.Rect(520, 400, 150, 14), "cartpl"), (pygame.Rect(720, 340, 170, 14), "aisle")]


def back_grocery(s, variant=0):
    wall(s, (240, 232, 200), (222, 210, 168))
    colors = [(220, 80, 70), (240, 200, 70), (90, 170, 90), (80, 140, 220), (200, 120, 190)]
    for row in range(3):  # высокие стеллажи с крупами и макаронами
        goods_row(s, 20, 110 + row * 66, W - 40, colors[row:] + colors[:row], h=46, bw=30)
    sign(s, 480, "БАКАЛЕЯ", (200, 160, 40), ink=(40, 30, 10))
    ceiling(s)
    store_floor(s, (205, 200, 185), (175, 170, 155))


# ---------------------------------------------------------------- 6. БЫТОВАЯ ХИМИЯ
def build_chem(variant=0):
    return [(pygame.Rect(70, 400, 160, 14), "chemshelf"), (pygame.Rect(310, 335, 140, 14), "chemshelf"),
            (pygame.Rect(540, 400, 160, 14), "chemshelf"), (pygame.Rect(770, 335, 130, 14), "aisle")]


def back_chem(s, variant=0):
    wall(s, (225, 215, 245), (200, 190, 230))
    colors = [(90, 200, 220), (240, 120, 180), (120, 220, 120), (250, 220, 80), (160, 120, 230)]
    for row in range(2):
        pygame.draw.rect(s, INK, (20, 150 + row * 90, W - 40, 8))
        for i, x in enumerate(range(30, W - 50, 36)):  # бутылки
            c = colors[(i + row) % 5]
            pygame.draw.rect(s, INK, (x, 98 + row * 90, 28, 54))
            pygame.draw.rect(s, c, (x + 2, 104 + row * 90, 24, 46))
            pygame.draw.rect(s, INK, (x + 8, 90 + row * 90, 12, 10))
    pygame.draw.polygon(s, (250, 220, 60), [(850, 320), (880, 270), (910, 320)])   # знак «осторожно»
    pygame.draw.polygon(s, INK, [(850, 320), (880, 270), (910, 320)], 4)
    sign(s, 480, "БЫТОВАЯ ХИМИЯ", (120, 80, 190))
    ceiling(s)
    store_floor(s, (215, 210, 235), (185, 180, 210))


# ---------------------------------------------------------------- 7. ИГРУШКИ
def build_toys(variant=0):
    return [(pygame.Rect(70, 400, 150, 14), "toyshelf"), (pygame.Rect(280, 340, 140, 14), "toyshelf"),
            (pygame.Rect(500, 400, 150, 14), "toyshelf"), (pygame.Rect(720, 340, 160, 14), "toyshelf")]


def back_toys(s, variant=0):
    wall(s, (250, 220, 235), (240, 195, 220))
    for i, (x, c) in enumerate(((60, (240, 80, 90)), (130, (80, 160, 240)), (800, (250, 210, 60)), (870, (110, 210, 120)))):
        pygame.draw.circle(s, INK, (x, 160 + i % 2 * 20), 28)   # воздушные шарики
        pygame.draw.circle(s, c, (x, 160 + i % 2 * 20), 25)
        pygame.draw.line(s, INK, (x, 188 + i % 2 * 20), (x + 6, 280), 2)
    # огромный плюшевый мишка
    pygame.draw.circle(s, INK, (480, 250), 70)
    pygame.draw.circle(s, (190, 130, 80), (480, 250), 66)
    for dx in (-52, 52):
        pygame.draw.circle(s, INK, (480 + dx, 196), 26)
        pygame.draw.circle(s, (190, 130, 80), (480 + dx, 196), 22)
    pygame.draw.circle(s, (235, 200, 160), (480, 270), 28)
    pygame.draw.circle(s, INK, (460, 236), 6)
    pygame.draw.circle(s, INK, (500, 236), 6)
    pygame.draw.circle(s, INK, (480, 262), 8)
    sign(s, 480, "ИГРУШКИ", (220, 90, 160))
    ceiling(s, lamp=(255, 235, 245))
    store_floor(s, (240, 215, 230), (215, 185, 205))


# ---------------------------------------------------------------- 8. ЭЛЕКТРОНИКА
def build_electro(variant=0):
    return [(pygame.Rect(60, 400, 160, 14), "tvwall"), (pygame.Rect(300, 340, 130, 14), "aisle"),
            (pygame.Rect(520, 400, 160, 14), "tvwall"), (pygame.Rect(750, 340, 140, 14), "tvwall")]


NEWS = [  # бегущая строка на экранах: в городе что-то происходит
    "СРОЧНО: В городе происходит что-то странное",
    "Жителям советуют не выходить из домов",
    "Очевидцы видят червяков в яблоках",
    "Мэр призывает сохранять спокойствие",
]
NEWS_TVS = ((1, 0), (2, 0), (3, 0), (4, 0), (2, 1), (3, 1), (4, 1), (5, 1))   # какие телевизоры показывают эфир (колонка, ряд)


def news_screen(s, rect, k, tick):
    """Один телевизор с новостями: ведущий, красная плашка «ЭФИР» и бегущая строка."""
    pygame.draw.rect(s, (35, 60, 120), rect)
    cx = rect.centerx + (k % 3 - 1) * 4
    pygame.draw.rect(s, (30, 30, 60), (cx - 20, rect.bottom - 28, 40, 18))               # костюм
    pygame.draw.rect(s, (240, 240, 245), (cx - 4, rect.bottom - 28, 8, 10))              # рубашка
    pygame.draw.circle(s, (240, 200, 170), (cx, rect.y + 24), 10)                        # голова
    pygame.draw.rect(s, (70, 50, 40), (cx - 10, rect.y + 13, 20, 7))                     # волосы
    mouth = 2 + (tick // 140 + k) % 3
    pygame.draw.rect(s, (140, 50, 60), (cx - 3, rect.y + 28, 6, mouth))                  # говорит
    tag = pygame.Rect(rect.x + 3, rect.y + 3, 30, 12)
    pygame.draw.rect(s, (210, 40, 50), tag)
    live = pixel_font(12).render("ЭФИР", True, (255, 255, 255))
    s.blit(live, live.get_rect(center=tag.center))
    band = pygame.Rect(rect.x, rect.bottom - 14, rect.w, 14)
    pygame.draw.rect(s, (210, 40, 50), band)
    text = pixel_font(12).render(NEWS[(k // 2) % len(NEWS)], True, (255, 255, 255))
    shift = (tick // 18 + k * 40) % (rect.w + text.get_width())
    old = s.get_clip()
    s.set_clip(band)
    s.blit(text, (rect.right - shift, band.y + (14 - text.get_height()) // 2))
    s.set_clip(old)


def back_electro(s, variant=0):
    wall(s, (60, 70, 110), (45, 52, 90))
    tick = pygame.time.get_ticks()
    for r in range(2):  # стена из телевизоров: часть показывает эфир новостей, часть помехи
        for c in range(8):
            x, y = 30 + c * 114, 100 + r * 100
            box(s, (x, y, 100, 82), (30, 32, 44))
            screen_rect = pygame.Rect(x + 6, y + 6, 88, 62)
            if (c, r) in NEWS_TVS:
                news_screen(s, screen_rect, c + r * 8, tick)
                continue
            noisy = (r * 8 + c + tick // 400) % 5 == 0
            col = (170, 175, 190) if noisy else (40 + c * 10, 80 + r * 40, 170 - c * 10)
            pygame.draw.rect(s, col, screen_rect)
            if noisy:
                for i in range(6):
                    pygame.draw.rect(s, (60, 62, 76), (x + 6, y + 8 + i * 10 + (tick // 90 + i) % 4, 88, 3))
    sign(s, 480, "ЭЛЕКТРОНИКА", (60, 90, 190))
    ceiling(s, lamp=(210, 225, 255))
    store_floor(s, (90, 100, 130), (68, 76, 104))


# ---------------------------------------------------------------- 9. ТУАЛЕТ ДЛЯ СОТРУДНИКОВ
def build_mtoilet(variant=0):
    return rooms.build_toilet(variant)


def back_mtoilet(s, variant=0):
    rooms.back_toilet(s, variant)
    t = pixel_font(20).render("ТОЛЬКО ДЛЯ СОТРУДНИКОВ", True, (170, 45, 55))
    plate = t.get_rect(center=(455, 152)).inflate(32, 18)
    box(s, plate, (235, 235, 245))
    s.blit(t, t.get_rect(center=plate.center))


# ---------------------------------------------------------------- 10. СКЛАД (босс)
def build_warehouse(variant=0):
    return [(pygame.Rect(60, 395, 160, 14), "pallet"), (pygame.Rect(300, 335, 140, 14), "pallet"),
            (pygame.Rect(520, 395, 160, 14), "pallet"), (pygame.Rect(760, 335, 140, 14), "pallet")]


def back_warehouse(s, variant=0):
    wall(s, (150, 150, 158), (122, 122, 132), panel_y=300)
    for x in range(0, W, 120):  # стальные балки и высокие стеллажи
        pygame.draw.rect(s, INK, (x, 46, 10, 254))
        pygame.draw.rect(s, (210, 130, 40), (x + 2, 48, 6, 250))
    for y in (110, 190, 270):
        pygame.draw.rect(s, INK, (0, y, W, 10))
        pygame.draw.rect(s, (230, 150, 50), (0, y + 2, W, 6))
    for i, x in enumerate(range(30, W - 60, 140)):  # коробки на стеллажах
        for y in (66, 146, 226):
            pygame.draw.rect(s, INK, (x, y, 80, 38))
            pygame.draw.rect(s, (200, 160, 110), (x + 3, y + 3, 74, 32))
            pygame.draw.rect(s, (240, 230, 200), (x + 30, y + 3, 14, 32))
    sign(s, 480, "СКЛАД", (200, 120, 40), ink=(40, 30, 10))
    ceiling(s, lamp=(255, 235, 200), dark=(50, 52, 64), off_every=2)
    store_floor(s, (130, 132, 140), (108, 110, 118), step=80)
    for x in range(0, W, 80):  # жёлтая разметка на полу
        pygame.draw.rect(s, (240, 200, 50), (x, FLOOR + 40, 40, 6))


# ---------------------------------------------------------------- мебель
def draw_furniture3(s, r, kind):
    if kind == "apples":
        box(s, (r.x, r.y, r.w, FLOOR - r.y), (170, 125, 75))   # ящик до пола
        pygame.draw.rect(s, (130, 90, 50), (r.x + 6, r.y + 26, r.w - 12, 4))
        for i, x in enumerate(range(r.x + 8, r.right - 18, 22)):   # яблоки сверху
            pygame.draw.circle(s, INK, (x + 9, r.y - 5), 10)
            pygame.draw.circle(s, (215, 50, 55) if i % 3 else (240, 190, 60), (x + 9, r.y - 5), 8)
            pygame.draw.rect(s, (60, 140, 60), (x + 10, r.y - 16, 4, 4))
    elif kind == "veg":
        box(s, (r.x, r.y, r.w, FLOOR - r.y), (150, 115, 70))
        for i, x in enumerate(range(r.x + 8, r.right - 20, 26)):
            c = (90, 180, 80) if i % 2 else (240, 140, 50)
            pygame.draw.circle(s, INK, (x + 10, r.y - 4), 11)
            pygame.draw.circle(s, c, (x + 10, r.y - 4), 9)
    elif kind == "meatcase":
        box(s, (r.x, r.y, r.w, FLOOR - r.y), (225, 230, 240))
        box(s, (r.x + 8, r.y - 24, r.w - 16, 26), (190, 215, 235))   # стекло
        for x in range(r.x + 16, r.right - 40, 34):
            pygame.draw.ellipse(s, INK, (x, r.y - 20, 30, 18))
            pygame.draw.ellipse(s, (205, 70, 70), (x + 2, r.y - 18, 26, 14))
        pygame.draw.rect(s, (160, 170, 185), (r.x + 10, r.y + 30, r.w - 20, 6))
    elif kind == "fridge":
        box(s, (r.x, r.y, r.w, FLOOR - r.y), (235, 242, 252))
        for x in range(r.x + 8, r.right - 20, 24):
            pygame.draw.rect(s, INK, (x, r.y - 26, 18, 26))
            pygame.draw.rect(s, (250, 250, 255), (x + 2, r.y - 24, 14, 22))
            pygame.draw.rect(s, (90, 140, 230), (x + 2, r.y - 24, 14, 6))
        pygame.draw.rect(s, (150, 180, 220), (r.x + 8, r.y + 20, r.w - 16, 4))
    elif kind == "breadrack":
        box(s, (r.x, r.y, r.w, FLOOR - r.y), (190, 140, 80))
        for x in range(r.x + 10, r.right - 30, 36):
            pygame.draw.ellipse(s, INK, (x, r.y - 20, 34, 20))
            pygame.draw.ellipse(s, (225, 165, 80), (x + 2, r.y - 18, 30, 16))
            pygame.draw.line(s, (180, 115, 50), (x + 10, r.y - 16), (x + 14, r.y - 6), 2)
            pygame.draw.line(s, (180, 115, 50), (x + 20, r.y - 16), (x + 24, r.y - 6), 2)
    elif kind == "aisle":
        box(s, r, (175, 180, 195))
        for lx in (r.x + 10, r.right - 16):
            box(s, (lx, r.bottom, 6, 14), (130, 135, 150), border=2)
        colors = [(220, 80, 70), (240, 200, 70), (90, 170, 90), (80, 140, 220)]
        for i, x in enumerate(range(r.x + 8, r.right - 20, 22)):
            pygame.draw.rect(s, INK, (x, r.y - 24, 18, 24))
            pygame.draw.rect(s, colors[i % 4], (x + 2, r.y - 22, 14, 20))
    elif kind == "chemshelf":
        box(s, (r.x, r.y, r.w, FLOOR - r.y), (205, 195, 235))
        for i, x in enumerate(range(r.x + 8, r.right - 20, 20)):
            c = [(90, 200, 220), (240, 120, 180), (120, 220, 120), (250, 220, 80)][i % 4]
            pygame.draw.rect(s, INK, (x, r.y - 28, 16, 28))
            pygame.draw.rect(s, c, (x + 2, r.y - 26, 12, 24))
            pygame.draw.rect(s, INK, (x + 5, r.y - 33, 6, 6))
    elif kind == "toyshelf":
        box(s, (r.x, r.y, r.w, FLOOR - r.y), (245, 200, 225))
        for i, x in enumerate(range(r.x + 10, r.right - 28, 32)):
            c = [(240, 80, 90), (80, 160, 240), (250, 210, 60), (110, 210, 120)][i % 4]
            pygame.draw.rect(s, INK, (x, r.y - 26, 26, 26))
            pygame.draw.rect(s, c, (x + 3, r.y - 23, 20, 20))
            pygame.draw.rect(s, (255, 255, 255), (x + 8, r.y - 18, 10, 6))
    elif kind == "tvwall":
        box(s, (r.x, r.y, r.w, FLOOR - r.y), (50, 55, 75))
        for x in range(r.x + 8, r.right - 40, 46):
            pygame.draw.rect(s, INK, (x, r.y - 34, 42, 34))
            pygame.draw.rect(s, (80, 140, 220), (x + 3, r.y - 31, 36, 26))
    elif kind == "pallet":
        box(s, (r.x, r.y, r.w, FLOOR - r.y), (180, 140, 90))
        for x in range(r.x + 8, r.right - 40, 44):
            pygame.draw.rect(s, INK, (x, r.y - 36, 40, 36))
            pygame.draw.rect(s, (205, 165, 115), (x + 3, r.y - 33, 34, 30))
            pygame.draw.rect(s, (240, 230, 200), (x + 15, r.y - 33, 10, 30))
    elif kind == "cartpl":
        box(s, r, (190, 195, 205))
        for x in range(r.x + 8, r.right - 10, 12):
            pygame.draw.rect(s, (110, 115, 130), (x, r.y + 2, 3, 40))
        pygame.draw.circle(s, INK, (r.x + 24, FLOOR - 10), 10)
        pygame.draw.circle(s, INK, (r.right - 24, FLOOR - 10), 10)


# ---------------------------------------------------------------- темы
LOOT = {
    "produce": {"pie": 16, "toygun": 4, "ball": 5, "trash": 6, "mop": 5, "watergun": 4, "piebomb": 3, "foamgun": 2},
    "meat": {"pie": 14, "cart": 5, "pony": 4, "mop": 6, "extinguisher": 4, "dumbbell": 4},
    "dairy": {"pie": 16, "foamgun": 6, "watergun": 6, "trash": 5, "cart": 3, "toygun": 3},
    "bakery": {"pie": 28, "piebomb": 8, "mop": 4, "slipper": 3, "club": 4},
    "grocery": {"pie": 14, "cart": 6, "chalk": 4, "textbook": 5, "ball": 5, "trash": 5, "pony": 4},
    "chem": {"pie": 12, "acid": 8, "extinguisher": 8, "mop": 8, "watergun": 6, "foamgun": 4},
    "toys": {"pie": 12, "pony": 10, "toygun": 10, "ball": 8, "jumprope": 6, "plane": 6},
    "electro": {"pie": 14, "cart": 5, "extinguisher": 5, "slingshot": 5, "club": 3, "bell": 3},
    "mtoilet": {"pie": 22, "mop": 10, "trash": 8, "watergun": 10, "slipper": 6, "foamgun": 5, "acid": 5},
    "warehouse": {"pie": 26, "piebomb": 8, "cart": 8, "foamgun": 6, "acid": 6, "extinguisher": 6, "pony": 6},
}
_BUILD = {"produce": (build_produce, back_produce, 70), "meat": (build_meat, back_meat, 70),
          "dairy": (build_dairy, back_dairy, 70), "bakery": (build_bakery, back_bakery, 60),
          "grocery": (build_grocery, back_grocery, 70), "chem": (build_chem, back_chem, 70),
          "toys": (build_toys, back_toys, 60), "electro": (build_electro, back_electro, 80),
          "mtoilet": (build_mtoilet, back_mtoilet, 70), "warehouse": (build_warehouse, back_warehouse, 90)}
THEMES3 = {k: {"build": b, "back": bk, "beams": [], "loot": LOOT[k], "tint": tint, "hides": []}
           for k, (b, bk, tint) in _BUILD.items()}
rooms.THEMES.update(THEMES3)
