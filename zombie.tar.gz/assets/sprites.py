"""Пиксельные спрайты, нарисованные текстом.

Каждая буква — один пиксель, точка — прозрачность. Цвета — в PALETTE.
Хочешь поменять героя — просто правь буквы в таблицах ниже.
Спрайты смотрят ВПРАВО, для «влево» их отзеркаливаем.
"""
import os
import sys

import pygame

SCALE = 4  # один пиксель спрайта = 4x4 пикселя на экране

PALETTE = {
    "K": (30, 30, 40),      # контур
    "S": (250, 215, 180),   # кожа
    "H": (90, 55, 30),      # волосы
    "B": (70, 110, 220),    # футболка
    "C": (140, 190, 255),   # рукав ближней руки (светлый, чтобы руку было видно)
    "n": (35, 60, 140),     # дальняя рука (тёмная)
    "P": (60, 60, 110),     # штаны
    "O": (230, 230, 230),   # кроссовки
    "p": (40, 40, 85),      # дальняя нога (темнее — видно глубину)
    "q": (170, 170, 175),   # дальний кроссовок
    "G": (110, 190, 110),   # кожа зомби
    "g": (70, 140, 80),     # тень зомби
    "Y": (240, 230, 70),    # глаза зомби
    "R": (150, 80, 110),    # лохмотья зомби
    "D": (70, 70, 100),     # штаны зомби
    "E": (40, 40, 70),      # дальняя нога зомби
    "M": (200, 40, 60),     # открытый рот зомби
    "W": (255, 255, 255),   # белый (вспышка при ударе)
    "r": (230, 60, 80),     # сердце
    "x": (90, 90, 100),     # пустое сердце
    "b": (150, 95, 50),     # дерево дубины
    "d": (105, 65, 30),     # тёмное дерево
    "f": (240, 200, 160),   # кулак
    "y": (240, 220, 100),   # линейка
    "w": (205, 205, 215),   # тряпка швабры
    "o": (225, 160, 70),    # корочка пирожка
    "c": (255, 225, 160),   # начинка пирожка
    "J": (55, 55, 85),      # пиджак директора
    "j": (35, 35, 60),      # дальний рукав директора
    "L": (235, 235, 240),   # рубашка
    "T": (210, 45, 55),     # галстук
    "h": (200, 200, 205),   # седые волосы
    "A": (140, 230, 60),    # кислота (яркая)
    "a": (80, 170, 40),     # кислота (тёмная)
    "e": (210, 50, 50),     # красный баллон огнетушителя
    "i": (150, 155, 165),   # сталь
    "k": (80, 85, 95),      # тёмно-серый (мусорка, бомба)
    "l": (110, 170, 255),   # вода
    "m": (60, 90, 170),     # обложка учебника
    "N": (240, 200, 60),    # золото (звонок)
    "s": (230, 130, 170),   # тапок
    "t": (245, 245, 240),   # бумага
    "v": (190, 140, 80),    # светлое дерево
    "z": (235, 245, 255),   # пена
    "F": (255, 140, 40),    # искра фитиля
    "1": (190, 55, 55),     # красная толстовка
    "2": (65, 140, 80),     # зелёная толстовка
    "3": (60, 60, 72),      # чёрная толстовка
    "4": (225, 112, 160),   # розовая кофта (девочка)
    "6": (232, 125, 125),   # рукав красной
    "7": (135, 205, 145),   # рукав зелёной
    "8": (112, 112, 128),   # рукав чёрной
    "9": (248, 172, 205),   # рукав розовой
    "0": (206, 160, 72),    # русые волосы девочки
}


def _grid(rows):
    width = max(len(r) for r in rows)
    return [r.ljust(width, ".") for r in rows]


PLAYER_HEAD = [
    "..KKKKKK..",
    ".KHHHHHHK.",
    ".KHSSSSSK.",
    ".KSSSSKSK.",
    ".KSSSSSSK.",
    "..KKKKKK..",
]
GIRL_HEAD = [               # у девочки волосы до плеч
    "..KKKKKK..",
    ".KHHHHHHK.",
    "KHHSSSSHHK",
    "KHSSSSKSHK",
    "KHSSSSSSHK",
    ".KHKKKKHK.",
]
PLAYER_TORSO = [
    ".KBBBBBBK.",
    "..KBBBBK..",
    "..KBBBBK..",
    "..KBBBBK..",
    "..KBBBBK..",
    "..KPPPPK..",
]
PLAYER_W, PLAYER_H = 12, 15


def _outline(grid):
    """Пустая клетка рядом с цветной (не контурной) становится чёрной — получается обводка."""
    h, w = len(grid), len(grid[0])
    out = [row[:] for row in grid]
    for y in range(h):
        for x in range(w):
            if grid[y][x] != ".":
                continue
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nx, ny = x + dx, y + dy
                if 0 <= nx < w and 0 <= ny < h and grid[ny][nx] not in ".K":
                    out[y][x] = "K"
                    break
    return ["".join(row) for row in out]


def player_frame(by=0, back=0, front=0, lift_b=0, lift_f=0, lean=False, arm=0, head=None):
    """Собирает кадр героя из частей.

    by      — на сколько пикселей опущено тело (приседание в момент шага)
    back    — на сколько клеток дальняя нога отставлена от стойки (вперёд +, назад -)
    front   — то же для ближней ноги
    lift_b / lift_f — на сколько пикселей поднята ступня (шаг в воздухе)
    lean    — наклон вперёд (для бега)
    arm     — куда смотрит кисть ближней руки: + вперёд, - назад, 0 вниз.
              Дальняя рука машет в обратную сторону.
    """
    grid = [["."] * PLAYER_W for _ in range(PLAYER_H)]

    def put(x, y, ch):
        if 0 <= x < PLAYER_W and 0 <= y < PLAYER_H:
            grid[y][x] = ch

    def put_arm(sx, sy, hand_dx, sleeve, hand):
        # рука из 4 клеток вниз от плеча, нижняя — кисть; низ уезжает на hand_dx
        for i in range(4):
            x = sx + round(hand_dx * i / 3)
            put(x, sy + i, hand if i == 3 else sleeve)
            put(x + 1, sy + i, hand if i == 3 else sleeve)

    shoulder = 5 + (1 if lean else 0)
    put_arm(shoulder, by + 7, -arm, "n", "q")  # дальняя рука — под туловищем

    for i, row in enumerate((head or PLAYER_HEAD) + PLAYER_TORSO):
        shift = 2 if lean and i < 9 else 1  # голову и грудь тянем вперёд
        for x, ch in enumerate(row):
            if ch != ".":
                put(x + shift, i + by, ch)

    put_arm(shoulder, by + 7, arm, "C", "S")  # ближняя рука — поверх

    length = 3 - by
    for base, d, lift, pants, shoe in ((4, back, lift_b, "p", "q"), (6, front, lift_f, "P", "O")):
        x = base + d
        n = length - lift
        for r in range(n):
            y = 12 + by + r
            if r == n - 1:
                for sx in range(3):
                    put(x + sx, y, shoe)
            else:
                put(x, y, pants)
                put(x + 1, y, pants)

    return _outline(grid)


# Ходьба — 4 кадра: шаг, переход, шаг другой ногой, переход
PLAYER_POSES = {
    "idle": dict(back=-1, front=0),
    "walk0": dict(by=1, back=-3, front=2, arm=-2),
    "walk1": dict(back=0, front=0, lift_b=1, arm=0),
    "walk2": dict(by=1, back=5, front=-4, arm=2),
    "walk3": dict(back=0, front=0, lift_f=1, arm=0),
    # Бег — тело наклонено, шаги шире, есть момент полёта, руки машут сильнее
    "run0": dict(by=1, back=-3, front=3, lean=True, arm=-3),
    "run1": dict(back=0, front=0, lift_b=1, lift_f=1, lean=True, arm=0),
    "run2": dict(by=1, back=5, front=-5, lean=True, arm=3),
    "run3": dict(back=3, front=-3, lift_b=1, lift_f=1, lean=True, arm=0),
    # Прыжок — ноги поджаты, рука вперёд
    "jump": dict(back=-2, front=2, lift_b=1, lift_f=1, arm=3),
}
PLAYER_FRAMES = {k: player_frame(**v) for k, v in PLAYER_POSES.items()}
GIRL_FRAMES = {k: player_frame(head=GIRL_HEAD, **v) for k, v in PLAYER_POSES.items()}

# Другие люди в катсценах — тот же скелет, другая одежда: буква -> буква палитры
HUMAN_STYLES = {
    "bully1": {"B": "1", "C": "6"},            # Чунгук — красная толстовка
    "bully2": {"B": "2", "C": "7"},            # Мингук — зелёная
    "bully3": {"B": "3", "C": "8"},            # Дундук — чёрная
    "girl": {"B": "4", "C": "9", "H": "0"},    # девочка — розовая кофта, русые волосы
}
ZOMBIE_COLORS = {"red": "1", "green": "2", "dark": "3"}  # зомби в той самой толстовке

ZOMBIE_HEAD = [
    "..KKKKKK..",
    ".KGGGGGGK.",
    ".KGGYKGYK.",
    ".KGGGGGGK.",
    ".KGKKKKGK.",   # рот закрыт (в кадре укуса меняется на открытый)
    "..KKKKKK..",
]
ZOMBIE_TORSO = [
    ".KRRRRRRK.",
    "..KRRRRK..",
    "..KRGRRK..",   # дыра в лохмотьях
    "..KRRRRK..",
    "..KDDDDK..",
]
ZOMBIE_W, ZOMBIE_H = 13, 14


def zombie_frame(by=0, back=0, front=0, lift_b=0, lift_f=0, dy=0, hs=2, bite=False,
                 head=None, torso=None, arms=("G", "g")):
    """Кадр зомби. Те же идеи, что у героя, плюс:

    dy   — руки вперёд качаются вверх (-) и вниз (+)
    hs   — насколько голова выдвинута вперёд (сутулость)
    bite — рот открыт, кусает
    head, torso, arms — свои части тела (так сделан босс)
    """
    grid = [["."] * ZOMBIE_W for _ in range(ZOMBIE_H)]

    def put(x, y, ch):
        if 0 <= x < ZOMBIE_W and 0 <= y < ZOMBIE_H:
            grid[y][x] = ch

    def arm(row, ch):
        for x in range(8, 13):
            put(x, row, ch)
            put(x, row + 1, ch)

    arm(by + 6 - dy, arms[1])  # дальняя рука — позади, качается в противоход

    head = list(head or ZOMBIE_HEAD)
    if bite:
        head[4] = ".KGMMMMGK."
    for i, row in enumerate(head + list(torso or ZOMBIE_TORSO)):
        shift = hs if i < 6 else (hs - 1 if i == 6 else 1)
        for x, ch in enumerate(row):
            if ch != ".":
                put(x + shift, i + by, ch)

    arm(by + 8 + dy, arms[0])  # ближняя рука — поверх

    length = 3 - by
    for base, d, lift, pants, foot in ((4, back, lift_b, "E", "g"), (6, front, lift_f, "D", "G")):
        x = base + d
        n = length - lift
        for r in range(n):
            y = 11 + by + r
            if r == n - 1:
                for sx in range(3):
                    put(x + sx, y, foot)
            else:
                put(x, y, pants)
                put(x + 1, y, pants)
    return _outline(grid)


# Шаркающая походка — 4 кадра. Руки вперёд покачиваются, голова вынесена вперёд.
ZOMBIE_FRAMES = {
    "walk0": zombie_frame(by=1, back=-2, front=2, dy=-1),
    "walk1": zombie_frame(back=0, front=0, lift_b=1, dy=0),
    "walk2": zombie_frame(by=1, back=4, front=-4, dy=1),
    "walk3": zombie_frame(back=0, front=0, lift_f=1, dy=0),
    "bite": zombie_frame(back=-1, front=1, dy=-1, hs=3, bite=True),
}

# ---- Директор-зомби (босс): тот же скелет, что у зомби, но другая одежда ----
BOSS_HEAD = [
    "..KKKKKK..",
    ".KhhhhhhK.",
    ".KGKYKKYK.",   # очки
    ".KGGGGGGK.",
    ".KGKKKKGK.",
    "..KKKKKK..",
]
BOSS_TORSO = [
    ".KJJJJJJK.",
    "..KJLTLK..",   # рубашка и галстук
    "..KJJTJK..",
    "..KJJTJK..",
    "..KDDDDK..",
]


def _boss(**kw):
    return zombie_frame(head=BOSS_HEAD, torso=BOSS_TORSO, arms=("J", "j"), **kw)


BOSS_FRAMES = {
    "walk0": _boss(by=1, back=-2, front=2, dy=-1),
    "walk1": _boss(back=0, front=0, lift_b=1, dy=0),
    "walk2": _boss(by=1, back=4, front=-4, dy=1),
    "walk3": _boss(back=0, front=0, lift_f=1, dy=0),
    "throw": _boss(back=-1, front=1, dy=-2, hs=3, bite=True),   # замах: руки вверх, рот открыт
    "charge": _boss(by=1, back=-3, front=3, dy=-1, hs=3),       # таран: наклон вперёд
}

# Двойка — снаряд босса
CARD = [
    "KKKKKKK",
    "KrrrrrK",
    "KrWWWrK",
    "KrrrWrK",
    "KrWWWrK",
    "KrWrrrK",
    "KrWWWrK",
    "KrrrrrK",
    "KKKKKKK",
]


CLUB = [
    "....KKKKKKKKKKKK",
    "..KKbbbbbbbbbddK",
    "KKbbbbbbbbbbbddK",
    "..KKbbbbbbbbbddK",
    "....KKKKKKKKKKKK",
]
RULER = [
    "KKKKKKKKKKKKKK",
    "KyyyyyyyyyyyyK",
    "KyKyyKyyKyyKyK",
    "KKKKKKKKKKKKKK",
]
MOP = [
    "..............KKKKK.",
    "KKKKKKKKKKKKKKwwwwwK",
    "KbbbbbbbbbbbbKwwwwwK",
    "KKKKKKKKKKKKKKKKKKKK",
]
PIE = [
    "..KKK..",
    ".KoooK.",
    "KoocooK",
    "KoooooK",
    ".KKKKK.",
]
FIST = [
    "KKKK",
    "KffK",
    "KffK",
    "KKKK",
]
HEART = [
    ".rr.rr.",
    "rrrrrrr",
    "rrrrrrr",
    ".rrrrr.",
    "..rrr..",
    "...r...",
]


# ---- оружие, которое бьёт (ширина картинки * 5 = дальность удара) ----
EXTINGUISHER = [
    "..KKKKKKKKKKKKK...",
    "KKeeeeeeeeeeeeeKKK",
    "KiKeeWWeeeeeeeeKii",
    "KKeeeeeeeeeeeeeKKK",
    "..KKKKKKKKKKKKK...",
]
POINTER = [
    "K" * 25,
    "K" + "v" * 20 + "iii" + "K",
    "K" * 25,
]
CHAIR = [
    "KKK............",
    "KvK............",
    "KvK............",
    "KvKKKKKKKKKKKK.",
    "KvvvvvvvvvvvvvK",
    "KKKKKKKKKKKKKKK",
    "KvK.........KvK",
    "KKK.........KKK",
]
SLIPPER = [
    "..KKKKKKK...",
    ".KsssssssKK.",
    "KssssKKKKssK",
    "KKKKKKKKKKKK",
]
NOTEBOOK = [
    "KKKKKKK",
    "KmmmmmK",
    "KmWWWmK",
    "KmmmmmK",
    "KmWWWmK",
    "KmmmmmK",
    "KmWWWmK",
    "KmmmmmK",
    "KKKKKKK",
]

# ---- стреляет и кидается ----
SLINGSHOT = [
    "KK...KK",
    "KbK.KbK",
    ".KbKbK.",
    "..KbK..",
    "..KbK..",
    "..KKK..",
]
WATERGUN = [
    "KKKKKKKK.",
    "KllllllKK",
    "KKKKKllK.",
    "...KllK..",
    "...KKKK..",
]
FOAMGUN = [
    "..KKKKKKKKKK..",
    "KKeeeeeeeeeeKK",
    "KiKeeeeeeeKzzK",
    "KKeeeeeeeeeeKK",
    "..KKKKKKKKKK..",
]
CHALK = [
    "KKKKKK",
    "KWWWWK",
    "KKKKKK",
]
TEXTBOOK = [
    "KKKKKKKKK",
    "KmmmmmmmK",
    "KmWWWWWmK",
    "KmmmmmmmK",
    "KmmmmmmmK",
    "KKKKKKKKK",
]
PLANE = [
    "KK.......",
    "KtKKK....",
    "KtttKKKK.",
    "KKKtttttK",
    "..KKKKKK.",
]
TRASH = [
    "..KKKK..",
    ".KKKKKK.",
    "KkkkkkkK",
    "KkikkikK",
    "KkikkikK",
    "KkikkikK",
    ".KkkkkK.",
    ".KKKKKK.",
]
ACID = [
    "..KK..",
    "..KK..",
    ".KaaK.",
    "KaAAaK",
    "KAAAAK",
    "KAAAAK",
    ".KAAK.",
    "..KK..",
]
BELL = [
    "...KK...",
    "..KNNK..",
    ".KNNNNK.",
    ".KNNNNK.",
    ".KNNNNK.",
    "KNNNNNNK",
    "KKKKKKKK",
    "...KK...",
]
PIEBOMB = [
    ".....F..",
    "....K...",
    "..KKKK..",
    ".KkkkkK.",
    "KkkWkkkK",
    "KooooooK",
    ".KKKKKK.",
]

# ---- из спортзала ----
DUMBBELL = [
    "KKK......KKK",
    "KkkK....KkkK",
    "KkkKiiiiKkkK",
    "KkkK....KkkK",
    "KKK......KKK",
]
JUMPROPE = [
    "KKK..........KKK",
    "KrKvvvvvvvvvvKrK",
    "KKK..........KKK",
]
BALL = [
    "..KKK..",
    ".KoKoK.",
    "KooKooK",
    "KKKKKKK",
    "KooKooK",
    ".KoKoK.",
    "..KKK..",
]

# Снаряды, которые выглядят не так, как оружие в руке
CLIP = ["KKKK", "iiii", "KKKK"]
DROP = [".ll.", "llll", ".ll."]
FOAM = [".KK.", "KzzK", "KzzK", ".KK."]

# оружие: имя -> (картинка, масштаб большой картинки для удара; None — только маленькая)
WEAPON_ART = {
    "club": (CLUB, 5), "ruler": (RULER, 5), "mop": (MOP, 5),
    "extinguisher": (EXTINGUISHER, 5), "pointer": (POINTER, 5),
    "chair": (CHAIR, 5), "slipper": (SLIPPER, 5), "notebook": (NOTEBOOK, 5),
    "slingshot": (SLINGSHOT, None), "watergun": (WATERGUN, None), "foamgun": (FOAMGUN, None),
    "chalk": (CHALK, None), "textbook": (TEXTBOOK, None), "plane": (PLANE, None),
    "trash": (TRASH, None), "acid": (ACID, None), "bell": (BELL, None), "piebomb": (PIEBOMB, None),
    "dumbbell": (DUMBBELL, 5), "jumprope": (JUMPROPE, 5), "ball": (BALL, None),
}
PROJECTILE_ART = {"slingshot": CLIP, "watergun": DROP, "foamgun": FOAM}


# ---- Мини-босс: Чунгук, Мингук и Дундук слились в одно тело с колоколом на макушке ----
MINI_W, MINI_H = 20, 20
BELL_SMALL = [
    "..KK..",
    ".KNNK.",
    ".KNNK.",
    "KNNNNK",
    "KKKKKK",
]


def _mini_head(hood, dead=False, open_mouth=False):
    skin, eyes = ("g", "K") if dead else ("G", "Y")
    mouth = f"K{skin}MM{skin}K" if open_mouth else f"K{skin}KK{skin}K"
    return [".KKKK.", f"K{hood * 4}K", f"K{skin}{eyes}{skin}{eyes}K", f"K{skin * 4}K", mouth, ".KKKK."]


def mini_frame(mask="111", pose="walk0"):
    """mask — какие головы живы (слева направо: красная, зелёная, чёрная); pose — walk0/walk1/attack."""
    grid = [["."] * MINI_W for _ in range(MINI_H)]

    def put(x, y, ch):
        if 0 <= x < MINI_W and 0 <= y < MINI_H:
            grid[y][x] = ch

    def blit(rows, ox, oy):
        for dy, row in enumerate(rows):
            for dx, ch in enumerate(row):
                if ch != ".":
                    put(ox + dx, oy + dy, ch)

    # руки (под головами и телом)
    top = 8 if pose == "attack" else 13
    for y in range(top, top + 5):
        for x in (0, 1, 18, 19):
            put(x, y, "G")
    # туловище — три цвета толстовок в одном теле
    for y in range(12, 18):
        put(2, y, "K")
        put(17, y, "K")
        for x in range(3, 17):
            put(x, y, "1" if x < 8 else ("2" if x < 12 else "3"))
    for x in range(8, 12):
        put(x, 11, "2")
    # головы: левая, средняя (чуть выше), правая; вырубленная голова поникла
    for i, (ox, oy) in enumerate(((1, 6), (7, 5), (13, 6))):
        alive = mask[i] == "1"
        blit(_mini_head("123"[i], dead=not alive, open_mouth=(pose == "attack" and alive)), ox, oy + (0 if alive else 1))
    blit(BELL_SMALL, 7, 0)  # колокол на макушке
    # ноги
    for x0, short in ((4, pose == "walk1"), (12, False)):
        for x in range(x0, x0 + 4):
            put(x, 18, "D")
            if not short:
                put(x, 19, "g")
    return _outline(grid)


MINI_FRAMES = {f"{pose}_{mask}": mini_frame(mask, pose)
               for mask in ("111", "110", "100") for pose in ("walk0", "walk1", "attack")}

# Ключ от кабинета директора (выпадает из мини-босса)
KEY = [
    ".KKKK.........",
    "KNNNNKKKKKKKKK",
    "KN..NNNNNNNNNK",
    "KNNNNKKKKNKNKK",
    ".KKKK...KNKNK.",
    "........KKKKK.",
]

# Парта (летает, когда школа оживает)
DESK = [
    "KKKKKKKKKKKKKK",
    "KvvvvvvvvvvvvK",
    "KKKKKKKKKKKKKK",
    ".KvK......KvK.",
    ".KvK......KvK.",
    ".KvK......KvK.",
    ".KKK......KKK.",
]

def build(rows, scale=SCALE, flash=False, recolor=None):
    rows = _grid(rows)
    surf = pygame.Surface((len(rows[0]), len(rows)), pygame.SRCALPHA)
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch == ".":
                continue
            if recolor and ch in recolor:
                ch = recolor[ch]
            if flash and ch not in "K":
                ch = "W"
            surf.set_at((x, y), PALETTE[ch])
    return pygame.transform.scale(surf, (surf.get_width() * scale, surf.get_height() * scale))


# ---------------------------------------------------------------- свои модельки (рисует Вова)
CUSTOM_FOLDER = "мои"  # сюда кладём свои картинки с теми же именами, что в «экранный_размер»


def default_custom_dirs():
    """Где игра ищет твои картинки: рядом с программой и в папке проекта."""
    base_exe = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else None
    base_src = os.path.dirname(os.path.abspath(__file__))
    dirs = []
    for base in (base_exe, base_src):
        if base:
            dirs.append(os.path.join(base, "Модельки Зомби-школы", CUSTOM_FOLDER))
            dirs.append(os.path.join(base, "модельки", CUSTOM_FOLDER))
    return dirs


def load_custom(path, size):
    """Загружает картинку и подгоняет под нужный размер.
    Если в файле нет прозрачности (так сохраняет Paint), фон — цвет левого верхнего пикселя
    (удобно залить фон розовым 255,0,255) — он станет прозрачным."""
    img = pygame.image.load(path).convert_alpha()
    mask = pygame.mask.from_surface(img, 254)  # непрозрачные пиксели
    if mask.count() == img.get_width() * img.get_height():  # прозрачности нет — красим фон в прозрачный
        flat = img.convert()
        flat.set_colorkey(flat.get_at((0, 0))[:3])
        img = flat.convert_alpha()
    if img.get_size() != size:
        ratio = img.get_width() / size[0]
        if ratio == int(ratio) and img.get_height() == size[1] * int(ratio):
            img = pygame.transform.scale(img, size)  # целое число раз крупнее: сохраняем резкие пиксели
        else:
            img = pygame.transform.smoothscale(img, size)
    return img


def whiten(img):
    """Белый силуэт картинки — вспышка при ударе."""
    mask = pygame.mask.from_surface(img)
    return mask.to_surface(setcolor=(255, 255, 255, 255), unsetcolor=(0, 0, 0, 0))


class SpriteSet:
    """Все картинки игры. Создаётся один раз после pygame.display.set_mode()."""

    def __init__(self, custom_dirs=None):
        self.player = {k: build(rows) for k, rows in PLAYER_FRAMES.items()}
        self.zombie = {}
        for k, rows in ZOMBIE_FRAMES.items():
            self.zombie[k] = build(rows)
            self.zombie[k + "_flash"] = build(rows, flash=True)
        self.zombie_v = {c: {k: build(rows, recolor={"R": key}) for k, rows in ZOMBIE_FRAMES.items()}
                         for c, key in ZOMBIE_COLORS.items()}
        self.humans = {name: {k: build(rows, recolor=style)
                              for k, rows in (GIRL_FRAMES if name == "girl" else PLAYER_FRAMES).items()}
                       for name, style in HUMAN_STYLES.items()}
        girl = self.humans["girl"]  # девочка ниже и младше: уменьшаем на 10%
        for k, img in girl.items():
            girl[k] = pygame.transform.scale(img, (int(img.get_width() * 0.9), int(img.get_height() * 0.9)))
        # оружие: имя -> (большая картинка для удара/щита, маленькая для земли и «в руке»)
        self.weapon, self.proj = {}, {}
        for name, (rows, big_scale) in WEAPON_ART.items():
            small = build(rows, scale=3 if big_scale else 4)
            self.weapon[name] = (build(rows, scale=big_scale) if big_scale else small, small)
            self.proj[name] = build(PROJECTILE_ART[name], scale=3) if name in PROJECTILE_ART else small
        self.pie = build(PIE, scale=4)
        self.school = {"desk": build(DESK, scale=5), "chair": self.weapon["chair"][0]}  # что летит в «школе»
        self.big_bell = build(BELL, scale=8)  # слабое место школы в финале
        self.key = build(KEY, scale=3)
        self.mini = {}
        for k, rows in MINI_FRAMES.items():
            self.mini[k] = build(rows, scale=5)
            self.mini[k + "_flash"] = build(rows, scale=5, flash=True)
        self.big_bell_flash = build(BELL, scale=8, flash=True)
        self.boss = {}
        for k, rows in BOSS_FRAMES.items():
            self.boss[k] = build(rows, scale=6)
            self.boss[k + "_flash"] = build(rows, scale=6, flash=True)
        self.card = build(CARD, scale=3)
        self.fist = build(FIST, scale=4)
        self.heart = build(HEART, scale=3)
        self.heart_empty = build(HEART, scale=3, recolor={"r": "x"})
        self.custom = []  # какие картинки подхватили из твоей папки
        self.apply_custom(default_custom_dirs() if custom_dirs is None else custom_dirs)

    def registry(self):
        """Список всех картинок игры: (имя файла, словарь/объект, ключ). По имени ищем твои версии."""
        items = []
        for k in self.player:
            items.append((f"hero_{k}", self.player, k))
        for k in self.zombie:
            if not k.endswith("_flash"):
                items.append((f"zombie_{k}", self.zombie, k))
        for name in self.humans:
            for k in ("idle", "walk0", "walk1", "walk2", "walk3"):
                items.append((f"{name}_{k}", self.humans[name], k))
        for k in self.boss:
            if not k.endswith("_flash"):
                items.append((f"boss_{k}", self.boss, k))
        for k in self.mini:
            if not k.endswith("_flash"):
                items.append((f"mini_{k}", self.mini, k))
        for k, (big, small) in self.weapon.items():
            if big is not small:
                items.append((f"weapon_{k}", ("big", k), None))
            items.append((f"weapon_{k}_small", ("small", k), None))
        for attr in ("pie", "key", "heart", "heart_empty", "card", "big_bell", "fist"):
            items.append((attr, self, attr))
        items.append(("school_desk", self.school, "desk"))
        return items

    def apply_custom(self, dirs):
        """Если в папке «мои» лежит файл с таким же именем, как у картинки, берём его вместо моей."""
        for folder in dirs:
            if not os.path.isdir(folder):
                continue
            for name, holder, key in self.registry():
                path = os.path.join(folder, name + ".png")
                if not os.path.isfile(path):
                    continue
                try:
                    if isinstance(holder, tuple):  # оружие: (большая, маленькая)
                        part, wkey = holder
                        big, small = self.weapon[wkey]
                        img = load_custom(path, (big if part == "big" else small).get_size())
                        if part == "big":
                            self.weapon[wkey] = (img, small)
                        else:  # у неударного оружия большая и маленькая — одна и та же картинка
                            self.weapon[wkey] = (img if big is small else big, img)
                            if wkey not in PROJECTILE_ART:
                                self.proj[wkey] = img
                    elif holder is self:
                        setattr(self, key, load_custom(path, getattr(self, key).get_size()))
                    else:
                        holder[key] = load_custom(path, holder[key].get_size())
                        if (key + "_flash") in holder:
                            holder[key + "_flash"] = whiten(holder[key])
                    if name == "big_bell":
                        self.big_bell_flash = whiten(self.big_bell)
                    self.custom.append(name)
                except Exception as err:  # плохой файл не должен ломать игру
                    print(f"не удалось загрузить {path}: {err}")
