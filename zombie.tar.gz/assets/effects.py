"""Эффекты, которые делают картинку «дороже»: тени, луч света, пылинки, искры, пыль, виньетка.
Тряска экрана и красная вспышка при уроне — в game.py, они используют эти кусочки.

Хочешь сильнее или слабее? Крути числа:
  - alpha (4-е число в цвете луча) — яркость света,
  - VIGNETTE_STRENGTH — насколько темнеют края экрана,
  - MAX_PARTICLES — сколько частиц одновременно.
"""
import math
import random

import pygame

from settings import FLOOR, H, W

VIGNETTE_STRENGTH = 110   # 0 — без виньетки
MAX_PARTICLES = 400

_shadow_cache = {}
_overlay_cache = {}
_red_vignette = None


# ---------------------------------------------------------------- тени
def ground_below(platforms, left, right, feet_y):
    """Где под ногами земля: пол или верх платформы, на которую можно встать."""
    top = FLOOR
    for pl in platforms:
        if pl.left < right and pl.right > left and pl.top >= feet_y - 3:
            top = min(top, pl.top)
    return top


def draw_shadow(s, cx, feet_y, ground_y, base_w):
    """Мягкая тень на земле. Чем выше прыгнул, тем меньше и бледнее."""
    height = max(0, ground_y - feet_y)
    k = max(0.35, 1.0 - height / 320)
    w = max(12, int(base_w * k))
    alpha = int(95 * k)
    key = (w, alpha)
    surf = _shadow_cache.get(key)
    if surf is None:
        h = max(6, int(w * 0.24))
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.ellipse(surf, (20, 14, 10, alpha), surf.get_rect())
        pygame.draw.ellipse(surf, (20, 14, 10, alpha), surf.get_rect().inflate(-w // 3, -h // 3))  # плотнее в центре
        _shadow_cache[key] = surf
    s.blit(surf, surf.get_rect(center=(int(cx), int(ground_y) + 1)))


# ---------------------------------------------------------------- свет и виньетка
def make_overlay(beams):
    """Лучи света из окон + тёмные края. Рисуется один раз и запоминается."""
    key = repr(beams)
    surf = _overlay_cache.get(key)
    if surf is None:
        surf = pygame.Surface((W, H), pygame.SRCALPHA)
        for pts, color in beams:
            pygame.draw.polygon(surf, color, pts)
        if VIGNETTE_STRENGTH:
            steps = 60
            for i in range(steps):
                a = int(VIGNETTE_STRENGTH * (1 - i / steps) ** 2)
                pygame.draw.rect(surf, (10, 8, 20, a), (i, i, W - 2 * i, H - 2 * i), 1)
        _overlay_cache[key] = surf
    return surf


def red_vignette():
    """Красные края — вспышка, когда тебе больно."""
    global _red_vignette
    if _red_vignette is None:
        surf = pygame.Surface((W, H), pygame.SRCALPHA)
        steps = 90
        for i in range(steps):
            a = int(210 * (1 - i / steps) ** 2.2)
            pygame.draw.rect(surf, (200, 20, 30, a), (i, i, W - 2 * i, H - 2 * i), 1)
        _red_vignette = surf
    return _red_vignette


def make_motes(beams, n=26, seed=1):
    """Пылинки, которые плавают в лучах света."""
    rng = random.Random(seed)
    motes = []
    for _ in range(n if beams else 0):
        pts, _color = rng.choice(beams)
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        motes.append([rng.uniform(min(xs), max(xs)), rng.uniform(min(ys), max(ys)),
                      rng.uniform(4, 10), rng.uniform(0, math.tau), rng.choice((2, 2, 3))])
    return motes


def draw_motes(s, motes, t):
    for x0, y0, speed, phase, size in motes:
        x = x0 + math.sin(t * 0.6 + phase) * 9
        y = 120 + ((y0 - 120 - t * speed) % (FLOOR - 140))
        glow = math.sin(t * 1.7 + phase)  # пылинка то видна, то нет: блестит, когда ловит свет
        if glow > -0.2:
            pygame.draw.rect(s, (255, 250, 225), (int(x), int(y), size, size))


# ---------------------------------------------------------------- частицы: искры, пыль, блёстки
class Particles:
    def __init__(self):
        self.items = []

    def clear(self):
        self.items.clear()

    def emit(self, x, y, n, colors, speed=(40, 200), life=(0.25, 0.5), size=(3, 6),
             grav=300.0, angle=0.0, spread=math.tau):
        """n частиц из точки (x, y). angle — куда летят, spread — насколько широко."""
        for _ in range(n):
            if len(self.items) >= MAX_PARTICLES:
                return
            a = angle + random.uniform(-spread / 2, spread / 2)
            v = random.uniform(*speed)
            life_t = random.uniform(*life)
            self.items.append({"x": float(x), "y": float(y), "vx": math.cos(a) * v, "vy": math.sin(a) * v,
                               "life": life_t, "max": life_t, "grav": grav,
                               "size": random.uniform(*size), "color": random.choice(colors)})

    def update(self, dt):
        for p in self.items:
            p["life"] -= dt
            p["vy"] += p["grav"] * dt
            p["x"] += p["vx"] * dt
            p["y"] += p["vy"] * dt
        self.items = [p for p in self.items if p["life"] > 0]

    def draw(self, s):
        for p in self.items:
            k = p["life"] / p["max"]
            size = max(1, int(p["size"] * (0.4 + 0.6 * k)))
            pygame.draw.rect(s, p["color"], (int(p["x"]) - size // 2, int(p["y"]) - size // 2, size, size))
