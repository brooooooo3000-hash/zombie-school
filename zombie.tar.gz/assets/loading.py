"""Загрузочный экран: ночная школа, название игры и полоска загрузки, по которой бежит герой, а за ним зомби.

Две части с одним видом:
  splash()          — заставка в самой игре (на компьютере и в браузере после страницы загрузки);
  make_web_assets() — картинки для страницы загрузки в браузере (их кладёт в index.html build_web.py).
Картинки и герой с зомби те же, что в игре, поэтому переход от страницы к игре незаметен.

Хочешь другой текст? Правь TAGLINE и переводы в translations.py. Время заставки — MIN_TIME.
"""
import asyncio
import io

import pygame

import i18n
import menu_bg
import sprites as SP
from pixelfont import pixel_font
from settings import H, INK, W

MIN_TIME = 1.2                     # столько секунд (минимум) показывается заставка в игре
TITLE = "ЗОМБИ-ШКОЛА"
TAGLINE = "Школа ожила. А ты опоздал."
LOADING = "Загрузка"                # к ней добавляются бегущие точки
TAP = "Тапни, чтобы начать"
TRACK = pygame.Rect(60, 520, W - 120, 10)   # полоска загрузки внизу, на земле
LABEL_Y = 300                      # где надпись «Загрузка...» / «Тапни, чтобы начать»
FEET = 512                         # на какой высоте стоят ноги героя и зомби
BLOOD = (200, 40, 60)
_cache = {}


def hero_frames():
    """Герой: 4 кадра бега и один стоя."""
    if "hero" not in _cache:
        _cache["hero"] = [SP.build(SP.PLAYER_FRAMES[f"run{i}"]) for i in range(4)] + [SP.build(SP.PLAYER_FRAMES["idle"])]
    return _cache["hero"]


def zombie_frames():
    if "zombie" not in _cache:
        _cache["zombie"] = [SP.build(SP.ZOMBIE_FRAMES[f"walk{i}"]) for i in range(4)]
    return _cache["zombie"]


def scene():
    """Ночная школа без текста (фон меню, чуть темнее)."""
    if "scene" not in _cache:
        s = menu_bg.build_sky()
        s.blit(menu_bg.build_front(), (0, 0))
        shade = pygame.Surface((W, H), pygame.SRCALPHA)
        shade.fill((4, 5, 16, 90))
        s.blit(shade, (0, 0))
        _cache["scene"] = s
    return _cache["scene"]


def outlined(text, size, color, shadow=None, outline=4):
    """Надпись с чёрной обводкой (и красной «кровавой» тенью, если задана)."""
    img = pixel_font(size).render(text, True, color)
    pad = outline + (4 if shadow else 0)
    out = pygame.Surface((img.get_width() + 2 * pad, img.get_height() + 2 * pad), pygame.SRCALPHA)
    mask = pygame.mask.from_surface(img).to_surface(setcolor=INK, unsetcolor=(0, 0, 0, 0))
    if shadow:
        sh = pygame.mask.from_surface(img).to_surface(setcolor=shadow, unsetcolor=(0, 0, 0, 0))
        for dx in range(-outline, outline + 1):
            for dy in range(-outline, outline + 1):
                out.blit(mask, (pad + dx, pad + dy + 4))
        out.blit(sh, (pad, pad + 4))
    else:
        for dx in range(-outline, outline + 1):
            for dy in range(-outline, outline + 1):
                out.blit(mask, (pad + dx, pad + dy))
    out.blit(img, (pad, pad))
    return out


def title_image():
    """Название и подпись (на выбранном языке), с прозрачным фоном."""
    key = ("title", i18n.LANG)
    if key not in _cache:
        t = outlined(i18n.tr(TITLE), 64, (255, 255, 255), shadow=BLOOD)
        tag = outlined(i18n.tr(TAGLINE), 24, (214, 220, 245), outline=3)
        out = pygame.Surface((max(t.get_width(), tag.get_width()), t.get_height() + tag.get_height() - 4), pygame.SRCALPHA)
        out.blit(t, t.get_rect(midtop=(out.get_width() // 2, 0)))
        out.blit(tag, tag.get_rect(midtop=(out.get_width() // 2, t.get_height() - 4)))
        _cache[key] = out
    return _cache[key]


def label_image(text, translate=True):
    key = ("label", text, translate, i18n.LANG)
    if key not in _cache:
        _cache[key] = outlined(i18n.tr(text) if translate else text, 28, (255, 232, 140), outline=3)
    return _cache[key]


def draw_bar(s, progress):
    """Полоска: чёрная рамка и зелёные деления."""
    pygame.draw.rect(s, INK, TRACK.inflate(8, 8))
    pygame.draw.rect(s, (18, 20, 40), TRACK)
    w = int(TRACK.w * max(0.0, min(1.0, progress)))
    for x in range(0, w, 16):
        pygame.draw.rect(s, (110, 226, 130), (TRACK.x + x, TRACK.y, min(12, w - x), TRACK.h))
        pygame.draw.rect(s, (70, 170, 90), (TRACK.x + x, TRACK.y + TRACK.h - 3, min(12, w - x), 3))


def draw(s, progress, t, ready=False):
    """Один кадр заставки: progress от 0 до 1, t — время в секундах (для шагов бега).
    ready — всё загружено: герой стоит, а надпись «Тапни, чтобы начать» мигает."""
    s.blit(scene(), (0, 0))
    ti = title_image()
    s.blit(ti, ti.get_rect(midtop=(W // 2, 46)))
    if ready:
        if int(t * 2) % 2 == 0:
            lab = label_image(TAP)
            s.blit(lab, lab.get_rect(midtop=(W // 2, LABEL_Y)))
    else:   # «Загрузка...» с бегущими точками (место под три точки занято всегда, чтобы надпись не прыгала)
        base = i18n.tr(LOADING)
        left = W // 2 - label_image(base + "...", False).get_width() // 2
        s.blit(label_image(base + "." * (int(t * 3) % 4), False), (left, LABEL_Y))
    draw_bar(s, progress)
    x = TRACK.x + progress * TRACK.w
    step = int(t * 9)
    for k, dist in ((1, 120), (0, 62)):   # два зомби гонятся за героем
        zimg = zombie_frames()[(step + k) % 4]
        s.blit(zimg, zimg.get_rect(midbottom=(int(x - dist), FEET + 4)))
    himg = hero_frames()[4 if ready else step % 4]
    s.blit(himg, himg.get_rect(midbottom=(int(x), FEET)))


async def splash(screen, clock, tasks, min_time=MIN_TIME):
    """Показывает заставку и между кадрами выполняет задачи загрузки (по одной). Любая клавиша или клик — пропустить."""
    t0 = pygame.time.get_ticks()
    done = 0
    skip = False   # нажали во время загрузки: пропустим, как только всё будет готово
    while True:
        t = (pygame.time.get_ticks() - t0) / 1000
        progress = min(1.0, t / min_time)
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                raise SystemExit
            if e.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                skip = True
        draw(screen, progress, t)
        pygame.display.flip()
        if done < len(tasks) and progress >= done / max(1, len(tasks)):
            tasks[done]()   # следующая задача загрузки (картинки, фон меню...)
            done += 1
        elif done >= len(tasks) and (progress >= 1.0 or skip):
            return
        clock.tick(60)
        await asyncio.sleep(0)


# ---------------------------------------------------------------- страница загрузки в браузере
def png(surface):
    buf = io.BytesIO()
    pygame.image.save(surface, buf, "x.png")
    return buf.getvalue()


def strip(frames):
    """Кадры в одну ленту (для анимации в CSS): ширина ленты = кадры * ширину кадра."""
    w, h = frames[0].get_size()
    out = pygame.Surface((w * len(frames), h), pygame.SRCALPHA)
    for i, f in enumerate(frames):
        out.blit(f, (i * w, 0))
    return out


def make_web_assets():
    """Картинки для страницы загрузки: {имя: PNG в байтах}. Названия и подписи — на трёх языках."""
    assets = {"scene": png(scene()), "hero": png(strip(hero_frames())), "zombie": png(strip(zombie_frames()))}
    old = i18n.LANG
    for code, _ in i18n.LANGS:
        i18n.set_lang(code)
        assets[f"title_{code}"] = png(title_image())
        assets[f"loading_{code}"] = png(label_image(i18n.tr(LOADING) + "...", False))
        assets[f"tap_{code}"] = png(label_image(TAP))
    i18n.set_lang(old)
    return assets
