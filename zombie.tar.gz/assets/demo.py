"""Режим показа: игра сама показывает себя, а ты рассказываешь (удобно для проектора на презентации).

Запуск: `python game.py --demo`, в браузере адрес с `?demo=1`, или клавиша P в главном меню.
Выйти: Esc. Больше ничего нажимать не надо.

Круг показа: меню, классы с уровнями, квесты, поезд (заставка, карта, бой с хулиганами), школа, бесконечный режим
с модификаторами. Язык показа только корейский (список LANGS). Прогресс игрока при показе не
трогается: настройки временные и после выхода возвращаются.

Герой в показе играет сам (класс Bot) и не умирает: когда сердец мало, ему подливают.
"""
import collections
import copy
import random

import pygame

import classes
import modifiers
import prefs
from settings import FLOOR
from weapons import WEAPONS

TYPE_SPEED = 45   # как печатается текст в катсценах (должно совпадать с game.TYPE_SPEED)
PHASES = [("menu", 5.0), ("classes", 7.0), ("quests", 4.0), ("train", 70.0), ("school", 35.0), ("endless", 45.0)]
LANGS = ["ko"]   # показ идёт только по-корейски (презентация Вовы на корейском); добавь "ru", "en", чтобы язык менялся по кругу
SHOW_LEVELS = {"normal": 3, "joker": 5, "nerd": 4, "taekwondo": 5, "gamer": 5}   # уровни классов для показа
SHOW_ORDER = ["normal", "joker", "nerd", "taekwondo", "gamer"]


class Bot:
    """Герой-автомат: идёт к ближайшему врагу, бьёт, прыгает, берёт оружие и пирожки."""

    def __init__(self):
        self.jump_t = 1.0
        self.pick_t = 0.0
        self.retreat_t = 0.0     # сколько ещё отступать (чтобы не дёргаться на месте, когда враг вплотную)
        self.retreat_dir = 1
        self.idle = 0.0          # сколько секунд подряд никому не стало хуже (застряли?)
        self.last_score = None
        self.panic_t = 0.0       # «встряска»: если застряли, бежим в случайную сторону и прыгаем
        self.panic_dir = 1

    def keys(self, g, dt):
        keys = collections.defaultdict(bool)
        p = g.player
        if g.state != "play" or g.over:
            return keys
        p.hp = max(p.hp, min(3, p.max_hp))   # в показе герой не умирает
        cx = p.x + p.w / 2
        self.pick_t -= dt
        if self.pick_t <= 0:   # оружие на полу: берём, если руки пустые
            self.pick_t = 0.8
            item = g.weapon_item_near() if p.weapon.get("key") == "fists" else None
            if item is not None:   # берём только то, чем можно бить (не звонок, не щит и не пони)
                w = WEAPONS[item["kind"]]
                if w["type"] in ("melee", "shot", "throw") and w.get("dmg", 0) > 0:
                    g.take_weapon()
        targets = g.targets()
        score = sum(max(0.0, t.hp) for t in targets) + 100 * len(targets)
        if self.last_score is not None and score < self.last_score - 1e-6:
            self.idle = 0.0                                  # кому-то стало хуже: всё идёт как надо
        elif targets:
            self.idle += dt
        self.last_score = score
        if self.idle > 2.5:                                  # давно никого не ударили: встряхнёмся
            self.idle, self.panic_t, self.panic_dir = 0.0, 1.0, random.choice((-1, 1))
        if self.panic_t > 0:
            self.panic_t -= dt
            keys[pygame.K_d if self.panic_dir > 0 else pygame.K_a] = True
            keys[pygame.K_SPACE] = True
            return keys
        goal = None
        if p.hp < p.max_hp - 1:   # ранен: сначала пирожок (только тот, что лежит на полу: на мебель автомат не лазает)
            pies = [i for i in g.pickups if i["kind"] == "pie" and i["rect"].bottom >= FLOOR - 6]
            if pies:
                goal = min(pies, key=lambda i: abs(i["rect"].centerx - cx))["rect"].centerx
        if goal is None and targets:
            t = min(targets, key=lambda z: abs(z.x + z.w / 2 - cx))
            tx = t.x + t.w / 2
            dx = tx - cx
            melee = p.eff()["type"] == "melee"
            reach = p.eff().get("reach", 45) if melee else 330
            face = 1 if dx > 0 else -1
            if melee:
                self.retreat_t -= dt
                if self.retreat_t > 0:                   # идёт отступление: отходим не дёргаясь
                    keys[pygame.K_d if self.retreat_dir > 0 else pygame.K_a] = True
                elif abs(dx) > reach + 15:               # далеко: подойти
                    keys[pygame.K_d if dx > 0 else pygame.K_a] = True
                elif abs(dx) < 14:                       # вплотную (или враг прямо над или под нами): шаг назад
                    self.retreat_t, self.retreat_dir = 0.3, -face
                elif p.face != face:                     # развернуться к врагу
                    keys[pygame.K_d if dx > 0 else pygame.K_a] = True
                if abs(dx) <= reach + 15 and p.face == face and self.retreat_t <= 0:
                    keys[pygame.K_j] = True
            else:                                        # стрелок: подойти на выстрел, развернуться, стрелять
                if abs(dx) > 300:
                    keys[pygame.K_d if dx > 0 else pygame.K_a] = True
                elif p.face != face:
                    keys[pygame.K_d if dx > 0 else pygame.K_a] = True
                if abs(dx) < 400 and p.face == face:
                    keys[pygame.K_j] = True
            if t.y + t.h < p.y + p.h - 30:   # враг выше (на мебели): прыгаем
                keys[pygame.K_SPACE] = True
        elif goal is None:
            if g.door_open and g.endless is None:   # всех победили: к двери
                keys[pygame.K_d] = True
            elif g.endless is not None:   # на арене ждём следующую волну в центре
                mid = g.ww / 2
                if abs(cx - mid) > 80:
                    keys[pygame.K_d if mid > cx else pygame.K_a] = True
        if goal is not None:
            keys[pygame.K_d if goal > cx else pygame.K_a] = abs(goal - cx) > 18
        self.jump_t -= dt   # изредка просто прыгаем, как живой игрок
        if self.jump_t <= 0:
            self.jump_t = random.uniform(1.6, 3.2)
        elif self.jump_t < 0.25:
            keys[pygame.K_SPACE] = True
        return keys


class Demo:
    def __init__(self):
        self.active = False
        self.bot = Bot()
        self.round = 0           # какой по счёту круг показа (от него язык и класс)
        self.i = 0               # номер фазы
        self.t = 0.0             # сколько секунд идёт фаза
        self.map_wait = 0.0
        self.cut_wait = 0.0
        self.menu_wait = 0.0
        self.saved = None
        self.visited = []        # какие фазы уже прошли (для проверки)

    # ---------- старт и конец
    def start(self, game):
        """Включаем показ: запоминаем настройки игрока, временно делаем свои, ничего не сохраняем."""
        self.saved = (copy.deepcopy(prefs.data), prefs.READONLY)
        prefs.READONLY = True
        self.active = True
        self.round, self.i = 0, 0
        self.begin_phase(game)

    def stop(self, game):
        """Выключаем показ: настройки игрока возвращаются как были."""
        if self.saved:
            data, ro = self.saved
            prefs.data.clear()
            prefs.data.update(data)
            prefs.READONLY = ro
            self.saved = None
        self.active = False
        from menu import apply_prefs
        apply_prefs()
        game.show_menu()

    # ---------- фазы
    @property
    def phase(self):
        return PHASES[self.i][0]

    def begin_phase(self, game):
        name = self.phase
        self.t, self.map_wait, self.cut_wait, self.menu_wait = 0.0, 0.0, 0.0, 0.0
        self.visited.append(name)
        if self.i == 0:   # начало круга: язык, класс и всё открыто (на время показа)
            lang = LANGS[self.round % len(LANGS)]
            klass = SHOW_ORDER[self.round % len(SHOW_ORDER)]
            prefs.data.update(lang=lang, klass=klass, coins=999, ch1_done=True, ch2_done=True, class_levels=dict(SHOW_LEVELS),
                              owned_classes=list(classes.CLASS_KEYS), quests={}, menu_anim=True)
            from menu import apply_prefs
            apply_prefs()
        if name == "menu":
            game.show_menu()
            game.menu.screen, game.menu.sel = "main", 0
        elif name == "classes":
            game.menu.screen, game.menu.sel = "classes", 0
        elif name == "quests":
            game.menu.activate("quests")
        elif name == "train":
            game.cutscenes = True
            game.new_game(3)
        elif name == "school":
            game.cutscenes = False
            game.new_game(1)
        elif name == "endless":
            game.cutscenes = False
            game.start_endless(modifiers.random_pick(6))

    def next_phase(self, game):
        self.i += 1
        if self.i >= len(PHASES):
            self.i, self.round = 0, self.round + 1
        self.begin_phase(game)

    # ---------- каждый кадр
    def update(self, game, dt):
        """Возвращает (клавиши героя, нажата ли мышь) на этот кадр."""
        self.t += dt
        name = self.phase
        if name in ("menu", "classes"):   # выбор в меню бегает по пунктам
            self.menu_wait += dt
            if self.menu_wait >= (0.9 if name == "menu" else 1.3):
                self.menu_wait = 0.0
                import menu as M
                if name == "menu":
                    game.menu.key(pygame.K_DOWN)
                else:
                    game.menu.sel = (game.menu.sel + 1) % len(M.CLASS_KEYS)
        if game.state == "cutscene" and game.cut:   # катсцены листаем сами, когда текст допечатан
            beat = game.cut["scene"]["beats"][game.cut["i"]]
            import i18n
            done = game.cut["t"] * TYPE_SPEED >= len(i18n.tr(beat["text"]))
            self.cut_wait = self.cut_wait + dt if done else 0.0
            if self.cut_wait > 1.6:
                self.cut_wait = 0.0
                game.advance_scene()
        elif game.state == "map":   # на карте выбираем следующий вагон или комнату
            self.map_wait += dt
            if self.map_wait > 2.5:
                self.map_wait = 0.0
                game.selected = game.next_open_room()
                game.enter_room(game.selected)
        if game.state == "win":
            self.t = 1e9   # сюжет кончился: сразу следующая фаза
        if self.t >= PHASES[self.i][1]:
            self.next_phase(game)
        return self.bot.keys(game, dt), False

    def after_update(self, game):
        """После кадра: если герой всё-таки погиб, тихо начинаем комнату заново (экран поражения не показываем)."""
        if game.over:
            game.retry()
