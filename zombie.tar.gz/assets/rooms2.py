"""Глава 2 «Блэкаут»: места, где происходит ночь. Квартира, лестница, подъезд, магазин и улица.

Всё как в rooms.py: build_xxx — мебель (на неё можно запрыгнуть), back_xxx — фон.
Новое здесь:
  dark   — насколько темно (0 — светло, 255 — чёрная ночь). Видно только круг света от телефона.
  hides  — места, где можно спрятаться (кнопка E).
"""
import math

import pygame

import rooms
from pixelfont import pixel_font
from rooms import box
from settings import FLOOR, H, INK, W

NIGHT_KINDS = ("apt", "stairs", "lobby", "shop")
KINDS = ("pc_desk", "shelf2", "bed", "closet", "landing", "crate", "goods", "counter2")

ROOMS2 = [
    {"id": "apt", "name": "Квартира, 40 этаж", "kind": "apt"},
    {"id": "stairs", "name": "Лестница, этажи 30–20", "kind": "stairs"},
    {"id": "lobby", "name": "Подъезд, этажи 10–0", "kind": "lobby"},
    {"id": "shop", "name": "Магазин", "kind": "shop"},
]
ROOM2_BY_ID = {r["id"]: r for r in ROOMS2}
ORDER2 = [r["id"] for r in ROOMS2]


# ---------------------------------------------------------------- общие кусочки
def night_window(s, x, y, w, h, lights=True):
    """Окно ночью: чёрное небо, луна, тёмные дома и редкие огоньки фонариков."""
    pygame.draw.rect(s, INK, (x - 4, y - 4, w + 8, h + 8))
    pygame.draw.rect(s, (14, 18, 42), (x, y, w, h))
    pygame.draw.circle(s, (225, 228, 200), (x + w - 28, y + 26), 11)
    pygame.draw.circle(s, (14, 18, 42), (x + w - 22, y + 22), 10)
    for i, (bx, bh) in enumerate(((0, 60), (26, 90), (58, 50), (84, 80), (112, 66))):
        if bx + 24 <= w:
            pygame.draw.rect(s, (8, 10, 24), (x + bx, y + h - bh, 24, bh))
    if lights:
        for lx, ly in ((20, 0.75), (70, 0.6), (104, 0.82)):
            if lx < w - 6:
                pygame.draw.rect(s, (255, 225, 120), (x + lx, y + int(h * ly), 3, 3))
    pygame.draw.rect(s, INK, (x + w // 2 - 3, y, 6, h))
    pygame.draw.rect(s, INK, (x, y + h // 2 - 3, w, 6))


def tile_floor(s, color, line, step=48):
    pygame.draw.rect(s, color, (0, FLOOR, W, H - FLOOR))
    for tx in range(0, W, step):
        pygame.draw.rect(s, line, (tx, FLOOR + 2, 3, H - FLOOR))
    for ty in range(FLOOR + 34, H, 34):
        pygame.draw.rect(s, line, (0, ty, W, 3))
    pygame.draw.rect(s, INK, (0, FLOOR, W, 4))


# ---------------------------------------------------------------- КВАРТИРА (40 этаж)
def build_apt(variant=0):
    return [
        (pygame.Rect(250, 400, 170, 14), "pc_desk"),
        (pygame.Rect(450, 330, 110, 14), "shelf2"),
        (pygame.Rect(740, 424, 150, 14), "bed"),
        (pygame.Rect(570, FLOOR - 176, 110, 12), "closet"),
    ]


BALCONY_ZONE = pygame.Rect(10, FLOOR - 180, 150, 180)
APT_HIDES = [pygame.Rect(545, FLOOR - 170, 160, 170)]


def back_apt(s, variant=0):
    s.fill((52, 56, 84))
    pygame.draw.rect(s, (42, 46, 70), (0, 330, W, FLOOR - 330))
    pygame.draw.rect(s, INK, (0, 330, W, 4))
    # балконная дверь слева: стекло, за ним чёрный город
    pygame.draw.rect(s, INK, (14, FLOOR - 196, 142, 196))
    pygame.draw.rect(s, (16, 20, 44), (22, FLOOR - 188, 126, 188))
    pygame.draw.rect(s, INK, (82, FLOOR - 188, 6, 188))
    pygame.draw.circle(s, (225, 228, 200), (118, FLOOR - 150), 9)
    pygame.draw.rect(s, (80, 60, 90), (22, FLOOR - 188, 20, 188))  # край шторы
    night_window(s, 200, 96, 140, 130)
    # постер с игрой
    box(s, (400, 110, 90, 120), (70, 60, 110))
    pygame.draw.rect(s, (150, 230, 120), (418, 128, 54, 8))
    pygame.draw.rect(s, (230, 90, 100), (418, 150, 54, 40))
    tile_floor(s, (92, 66, 48), (70, 50, 36), step=40)


# ---------------------------------------------------------------- ЛЕСТНИЦА (этажи 30–20)
def build_stairs(variant=0):
    return [
        (pygame.Rect(170, 385, 150, 14), "landing"),
        (pygame.Rect(440, 330, 130, 14), "landing"),
        (pygame.Rect(690, 385, 150, 14), "landing"),
    ]


def back_stairs(s, variant=0):
    s.fill((96, 104, 100))
    pygame.draw.rect(s, (78, 86, 82), (0, 300, W, FLOOR - 300))
    pygame.draw.rect(s, INK, (0, 300, W, 4))
    # лестничные марши на фоне: ступени уходят вверх
    for i in range(14):
        x = 40 + i * 62
        y = 330 - i * 12
        pygame.draw.rect(s, (66, 72, 70), (x, y, 62, 14))
        pygame.draw.rect(s, INK, (x, y, 62, 14), 2)
    pygame.draw.line(s, INK, (40, 300), (900, 130), 6)  # перила
    pygame.draw.line(s, (150, 150, 155), (40, 296), (900, 126), 3)
    # надписи на стене: номер этажа
    f = pixel_font(48)
    t = f.render("ЭТАЖ 30", True, (200, 205, 200))
    s.blit(t, (380, 110))
    # двери квартир
    for dx in (60, 800):
        box(s, (dx, FLOOR - 150, 80, 150), (110, 76, 60))
        pygame.draw.rect(s, (230, 200, 70), (dx + 60, FLOOR - 76, 8, 8))
    # окно на площадке
    night_window(s, 560, 120, 110, 100, lights=True)
    tile_floor(s, (112, 116, 112), (88, 92, 88))


# ---------------------------------------------------------------- ПОДЪЕЗД (этажи 10–0)
def build_lobby(variant=0):
    return [
        (pygame.Rect(380, 408, 130, 14), "crate"),
        (pygame.Rect(150, 360, 120, 14), "crate"),
    ]


LOBBY_HIDES = [pygame.Rect(590, FLOOR - 140, 150, 140)]


def back_lobby(s, variant=0):
    s.fill((62, 76, 80))
    pygame.draw.rect(s, (50, 62, 66), (0, 320, W, FLOOR - 320))
    pygame.draw.rect(s, INK, (0, 320, W, 4))
    # почтовые ящики
    for row in range(2):
        for col in range(8):
            x, y = 40 + col * 30, 190 + row * 36
            box(s, (x, y, 26, 32), (120, 130, 140), border=2)
            pygame.draw.rect(s, (30, 34, 40), (x + 7, y + 6, 12, 3))
    # под лестницей — тёмная ниша, там можно спрятаться
    pygame.draw.polygon(s, INK, [(570, FLOOR), (570, 300), (760, 300), (760, FLOOR)])
    pygame.draw.polygon(s, (24, 28, 34), [(578, FLOOR), (578, 308), (752, 308), (752, FLOOR)])
    for i in range(6):
        y = 300 - i * 22
        pygame.draw.rect(s, (90, 96, 100), (760 + i * 24, y, 40, 14))
        pygame.draw.rect(s, INK, (760 + i * 24, y, 40, 14), 2)
    # аварийная красная лампа: мигает
    pulse = 0.5 + 0.5 * math.sin(pygame.time.get_ticks() / 380)
    pygame.draw.circle(s, INK, (480, 70), 22)
    pygame.draw.circle(s, (int(110 + 130 * pulse), 30, 30), (480, 70), 17)
    # окно рядом с дверью: разбито
    night_window(s, 300, 120, 120, 90, lights=False)
    tile_floor(s, (84, 92, 96), (60, 68, 72))


# ---------------------------------------------------------------- МАГАЗИН
def build_shop(variant=0):
    return [
        (pygame.Rect(110, 395, 190, 14), "goods"),
        (pygame.Rect(340, 335, 170, 14), "goods"),
        (pygame.Rect(650, 425, 210, 14), "counter2"),
    ]


SHOP_HIDES = [pygame.Rect(630, FLOOR - 100, 250, 100)]
GIRL_POS = (735, FLOOR)  # где сидит девочка (за прилавком)


def back_shop(s, variant=0):
    s.fill((58, 66, 84))
    pygame.draw.rect(s, (46, 54, 72), (0, 330, W, FLOOR - 330))
    pygame.draw.rect(s, INK, (0, 330, W, 4))
    # витрина-окно с чёрной улицей
    night_window(s, 560, 80, 190, 140, lights=True)
    # вывеска
    box(s, (330, 40, 180, 44), (200, 70, 80))
    t = pixel_font(24).render("МАГАЗИН", True, (255, 240, 200))
    s.blit(t, t.get_rect(center=(420, 62)))
    # полки с товарами на стене
    colors = [(220, 80, 80), (80, 150, 220), (230, 200, 70), (90, 190, 110), (190, 110, 200)]
    for row in range(2):
        pygame.draw.rect(s, INK, (30, 130 + row * 80, 300, 8))
        for i in range(10):
            pygame.draw.rect(s, INK, (36 + i * 29, 96 + row * 80, 26, 36))
            pygame.draw.rect(s, colors[(i + row * 2) % 5], (38 + i * 29, 98 + row * 80, 22, 32))
    tile_floor(s, (150, 150, 160), (120, 120, 132), step=60)


# ---------------------------------------------------------------- УЛИЦА (только для катсцен)
def back_street(s, variant=0):
    dawn = variant == 1
    sky_top, sky_bot = ((70, 90, 150), (250, 170, 110)) if dawn else ((8, 10, 28), (22, 26, 52))
    for y in range(0, FLOOR, 6):  # небо слоями
        k = y / FLOOR
        c = tuple(int(sky_top[i] + (sky_bot[i] - sky_top[i]) * k) for i in range(3))
        pygame.draw.rect(s, c, (0, y, W, 6))
    if dawn:
        pygame.draw.circle(s, (255, 230, 150), (700, 330), 60)
    else:
        pygame.draw.circle(s, (225, 228, 200), (780, 90), 26)
        pygame.draw.circle(s, (12, 14, 34), (790, 84), 24)
        for sx, sy in ((120, 60), (260, 120), (420, 50), (560, 100), (880, 160)):
            pygame.draw.rect(s, (200, 200, 230), (sx, sy, 3, 3))
    house = (30, 34, 50) if not dawn else (70, 70, 100)
    for bx, bw, bh in ((20, 130, 250), (170, 100, 190), (290, 150, 290), (460, 110, 210), (590, 140, 260),
                       (750, 120, 200), (890, 90, 240)):
        pygame.draw.rect(s, INK, (bx - 3, FLOOR - bh - 3, bw + 6, bh + 3))
        pygame.draw.rect(s, house, (bx, FLOOR - bh, bw, bh))
        for wy in range(FLOOR - bh + 18, FLOOR - 40, 38):
            for wx in range(bx + 14, bx + bw - 20, 30):
                lit = (wx * 7 + wy * 3) % 11 == 0
                pygame.draw.rect(s, (255, 220, 120) if (lit and not dawn) else (14, 16, 30) if not dawn else (120, 140, 190),
                                 (wx, wy, 12, 18))
    # фонарные столбы (не горят) и машина
    for lx in (230, 540, 830):
        pygame.draw.rect(s, INK, (lx, FLOOR - 190, 8, 190))
        pygame.draw.rect(s, INK, (lx - 14, FLOOR - 196, 40, 10))
    box(s, (400, FLOOR - 44, 130, 40), (60, 70, 90))
    pygame.draw.circle(s, INK, (430, FLOOR - 4), 14)
    pygame.draw.circle(s, INK, (500, FLOOR - 4), 14)
    pygame.draw.rect(s, (60, 62, 72), (0, FLOOR, W, H - FLOOR))
    for x in range(0, W, 90):
        pygame.draw.rect(s, (110, 112, 126), (x, FLOOR + 40, 50, 8))
    pygame.draw.rect(s, INK, (0, FLOOR, W, 4))


def build_street(variant=0):
    return []


# ---------------------------------------------------------------- мебель
def draw_furniture2(s, r, kind):
    if kind == "pc_desk":
        box(s, r, (110, 80, 55))
        for lx in (r.x + 8, r.right - 16):
            box(s, (lx, r.bottom, 8, FLOOR - r.bottom), (80, 58, 40), border=2)
        # выключенный монитор и клавиатура
        box(s, (r.x + 40, r.y - 56, 76, 52), (24, 26, 36))
        pygame.draw.rect(s, (12, 14, 22), (r.x + 46, r.y - 50, 64, 38))
        pygame.draw.rect(s, (60, 62, 76), (r.x + 70, r.y - 6, 18, 6))
        box(s, (r.x + 30, r.y - 8, 96, 8), (70, 72, 86), border=2)
    elif kind == "shelf2":
        box(s, r, (96, 68, 44))
        for lx in (r.x + 10, r.right - 16):
            box(s, (lx, r.bottom, 6, 16), (70, 50, 34), border=2)
    elif kind == "bed":
        for lx in (r.x + 6, r.right - 14):
            box(s, (lx, r.bottom, 8, FLOOR - r.bottom), (70, 52, 38), border=2)
        box(s, (r.x, r.y - 22, r.w, 36), (64, 84, 150))
        box(s, (r.x + 6, r.y - 34, 44, 18), (210, 215, 230), border=2)
    elif kind == "closet":
        top = r.y
        box(s, (r.x, top, r.w, FLOOR - top), (90, 66, 48))
        pygame.draw.rect(s, INK, (r.centerx - 2, top + 6, 4, FLOOR - top - 12))
        for hx in (r.centerx - 14, r.centerx + 8):
            pygame.draw.rect(s, (230, 200, 70), (hx, top + 90, 6, 20))
    elif kind == "landing":
        box(s, r, (130, 134, 138))
        pygame.draw.rect(s, (90, 94, 98), (r.x + 6, r.bottom, r.w - 12, 8))
    elif kind == "crate":
        box(s, r, (120, 96, 64))
        for lx in (r.x + 10, r.right - 18):
            box(s, (lx, r.bottom, 8, FLOOR - r.bottom), (90, 70, 46), border=2)
    elif kind == "goods":
        box(s, r, (170, 170, 182))
        for lx in (r.x + 10, r.right - 18):
            box(s, (lx, r.bottom, 8, FLOOR - r.bottom), (120, 120, 134), border=2)
        colors = [(220, 80, 80), (80, 150, 220), (230, 200, 70), (90, 190, 110)]
        for i, bx in enumerate(range(r.x + 12, r.right - 24, 26)):
            pygame.draw.rect(s, INK, (bx, r.y - 28, 22, 28))
            pygame.draw.rect(s, colors[i % 4], (bx + 2, r.y - 26, 18, 24))
    elif kind == "counter2":
        box(s, (r.x, r.y, r.w, FLOOR - r.y), (170, 175, 192))  # прилавок до пола: за ним можно спрятаться
        pygame.draw.rect(s, (130, 135, 152), (r.x + 8, r.y + 24, r.w - 16, FLOOR - r.y - 34), 3)
        box(s, (r.x + r.w - 70, r.y - 30, 56, 30), (50, 56, 70))  # касса
        pygame.draw.rect(s, (90, 220, 120), (r.x + r.w - 62, r.y - 24, 24, 10))
        pygame.draw.rect(s, (230, 230, 240), (r.x + 20, r.y - 12, 36, 12))  # весы/коробка на прилавке


# ---------------------------------------------------------------- темы
THEMES2 = {
    "apt": {"build": build_apt, "back": back_apt, "beams": [], "loot": {"pie": 1}, "dark": 238, "tint": 90,
            "hides": APT_HIDES},
    "stairs": {"build": build_stairs, "back": back_stairs, "beams": [], "loot": {"pie": 6, "powerbank": 4},
               "dark": 205, "tint": 70, "hides": []},
    "lobby": {"build": build_lobby, "back": back_lobby, "beams": [],
              "loot": {"pie": 10, "powerbank": 5, "toygun": 3}, "dark": 244, "tint": 100, "hides": LOBBY_HIDES},
    "shop": {"build": build_shop, "back": back_shop, "beams": [], "loot": {"pie": 12, "powerbank": 5, "toygun": 3},
             "dark": 238, "tint": 90, "hides": SHOP_HIDES},
    "street": {"build": build_street, "back": back_street, "beams": [], "loot": {"pie": 1}, "tint": 40,
               "hides": []},
}
rooms.THEMES.update(THEMES2)
