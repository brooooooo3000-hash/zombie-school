"""Глава 2 «Мегамаркет»: карта магазина, отделы, враги и сюрпризы.

Как в главе 1: карта комнат, отделы открываются по порядку, в конце босс.
  Туалет для сотрудников — бонус (открыт сразу): лут и кошелёк на 60 монет.
  Отделы 1-8: овощи, мясной, молочный, пекарня, бакалея, бытовая химия, игрушки, электроника.
  Склад (10-й) — босс, открывается, когда зачищены все 8 отделов.
Враги: обычные зомби, червяки-мутанты (лезут из яблок), мясные зомби (куры, коровы, барашки) и мимики.
Сюрпризы: мимики (пирожок кусается), «акция» в бакалее (толпа с обеих сторон), объявления по громкоговорителю.
"""
import math
import random

import pygame

from pixelfont import pixel_font
from school_map import _check, _lock
from settings import FLOOR, H, INK, W

# Порядок = порядок выбора стрелками (верхний ряд слева направо, потом нижний)
MAP_ROOMS2 = [
    {"id": "mtoilet", "name": "Туалет", "kind": "mtoilet", "rect": pygame.Rect(61, 130, 150, 120)},
    {"id": "produce", "name": "Овощи и фрукты", "kind": "produce", "num": 1, "rect": pygame.Rect(233, 130, 150, 120)},
    {"id": "meat", "name": "Мясной отдел", "kind": "meat", "num": 2, "rect": pygame.Rect(405, 130, 150, 120)},
    {"id": "dairy", "name": "Молочный отдел", "kind": "dairy", "num": 3, "rect": pygame.Rect(577, 130, 150, 120)},
    {"id": "bakery", "name": "Пекарня", "kind": "bakery", "num": 4, "rect": pygame.Rect(749, 130, 150, 120)},
    {"id": "grocery", "name": "Бакалея", "kind": "grocery", "num": 5, "rect": pygame.Rect(61, 330, 150, 120)},
    {"id": "chem", "name": "Бытовая химия", "kind": "chem", "num": 6, "rect": pygame.Rect(233, 330, 150, 120)},
    {"id": "toys", "name": "Игрушки", "kind": "toys", "num": 7, "rect": pygame.Rect(405, 330, 150, 120)},
    {"id": "electro", "name": "Электроника", "kind": "electro", "num": 8, "rect": pygame.Rect(577, 330, 150, 120)},
    {"id": "warehouse", "name": "Склад", "kind": "warehouse", "rect": pygame.Rect(749, 330, 150, 120)},
]
ORDER2 = [r["id"] for r in MAP_ROOMS2]
ROOM2_BY_ID = {r["id"]: r for r in MAP_ROOMS2}
TOP_ROW = ORDER2[:5]
BOTTOM_ROW = ORDER2[5:]
DEPTS = ["produce", "meat", "dairy", "bakery", "grocery", "chem", "toys", "electro"]   # отделы по порядку

KIND_COLOR = {"mtoilet": (170, 215, 235), "produce": (170, 215, 140), "meat": (235, 150, 150),
              "dairy": (180, 205, 245), "bakery": (245, 200, 130), "grocery": (235, 215, 120),
              "chem": (200, 170, 240), "toys": (245, 170, 215), "electro": (130, 160, 235),
              "warehouse": (200, 120, 60)}
LOCKED_COLOR = (72, 78, 100)
DONE_COLOR = (130, 205, 140)
YELLOW = (255, 230, 90)

# Сколько врагов в отделе: (вид, сколько). В отделе овощей червяки ещё вылезают из яблок.
SPAWN = {
    "mtoilet": [("zombie", 3)],
    "produce": [("zombie", 2)],
    "meat": [("chicken", 3), ("lamb", 2), ("cow", 1), ("zombie", 2)],
    "dairy": [("worm", 3), ("cow", 1), ("zombie", 3)],
    "bakery": [("zombie", 4), ("worm", 3)],
    "grocery": [("zombie", 3), ("lamb", 2)],
    "chem": [("zombie", 4), ("worm", 4)],
    "toys": [("zombie", 4), ("worm", 2)],
    "electro": [("zombie", 5), ("worm", 3), ("lamb", 2), ("chicken", 1)],
    "warehouse": [("worm", 2)],
}
ROUND_EXTRA = 2          # на сколько зомби больше в каждом новом круге

# Объявления по громкоговорителю: звучат по ходу боя
PA_LINES = [
    "ОБЪЯВЛЕНИЕ: Внимание! Скидка на червяков: два по цене одного!",
    "ОБЪЯВЛЕНИЕ: Уважаемые покупатели, просим не кормить мутантов.",
    "ОБЪЯВЛЕНИЕ: Касса номер 3 свободна. Касса номер 3 съела кассира.",
    "ОБЪЯВЛЕНИЕ: Сотрудников просим не паниковать. Паника на складе, скидка 20%.",
    "ОБЪЯВЛЕНИЕ: Потерялась корова. Она нашлась. Она очень злая.",
    "ОБЪЯВЛЕНИЕ: Магазин закрыт. Уборщик не придёт. Уборщик тоже закрыт.",
    "ОБЪЯВЛЕНИЕ: Покупателя в синей толстовке просим пройти на кассу. Он справляется.",
]
SALE_LINE = "АКЦИЯ! Всё по одной монете! Налетай!"


def room_at(pos):
    for r in MAP_ROOMS2:
        if r["rect"].collidepoint(pos):
            return r["id"]
    return None


def move_selection(selected, key):
    """Стрелки: по ряду и между рядами (как на карте школы)."""
    row = TOP_ROW if selected in TOP_ROW else BOTTOM_ROW
    i = row.index(selected)
    if key == pygame.K_LEFT:
        return row[max(0, i - 1)]
    if key == pygame.K_RIGHT:
        return row[min(len(row) - 1, i + 1)]
    if key in (pygame.K_UP, pygame.K_DOWN):
        other = BOTTOM_ROW if row is TOP_ROW else TOP_ROW
        if (key == pygame.K_DOWN) == (row is TOP_ROW):
            cx = ROOM2_BY_ID[selected]["rect"].centerx
            return min(other, key=lambda rid: abs(ROOM2_BY_ID[rid]["rect"].centerx - cx))
    return selected


def status_of(rid, cleared):
    """done — зачищен, open — можно идти, locked — закрыт."""
    if rid in cleared:
        return "done"
    if rid in ("mtoilet", "produce"):
        return "open"
    if rid == "warehouse":
        return "open" if all(d in cleared for d in DEPTS) else "locked"
    prev = DEPTS[DEPTS.index(rid) - 1]
    return "open" if prev in cleared else "locked"


def lock_reason(rid):
    if rid == "warehouse":
        return "Закрыто: сначала зачисти все 8 отделов"
    prev = DEPTS[DEPTS.index(rid) - 1]
    return "Закрыто: сначала зачисти отдел «%s»" % ROOM2_BY_ID[prev]["name"]


# ---------------------------------------------------------------- карта
def _draw_room(s, room, status, selected, tick):
    r = room["rect"]
    top_row = room["id"] in TOP_ROW
    fill = {"locked": LOCKED_COLOR, "done": DONE_COLOR}.get(status, KIND_COLOR[room["kind"]])
    bob = int(math.sin(tick / 180) * 3) if selected else 0
    box = r.move(0, -bob if top_row else bob)
    pygame.draw.rect(s, INK, box.inflate(8, 8))
    pygame.draw.rect(s, fill, box)
    if selected:
        pygame.draw.rect(s, YELLOW, box.inflate(12, 12), 6)
    door_color = YELLOW if status == "open" else (110, 115, 135)
    door = pygame.Rect(box.centerx - 16, box.bottom - 6 if top_row else box.top - 2, 32, 8)
    pygame.draw.rect(s, door_color, door)
    ink = (30, 30, 40) if status != "locked" else (150, 155, 175)
    name = pixel_font(18).render(room["name"], True, ink)
    if name.get_width() > box.w - 12:
        name = pixel_font(14).render(room["name"], True, ink)
    s.blit(name, name.get_rect(center=(box.centerx, box.centery - 22)))
    if room["kind"] == "mtoilet":
        sub, col = "бонус: лут и кошелёк", ink
    elif room["kind"] == "warehouse":
        sub, col = "БОСС", (170, 40, 40) if status != "locked" else ink
    else:
        num = pixel_font(44).render(str(room["num"]), True, ink)
        s.blit(num, num.get_rect(center=(box.centerx, box.centery + 14)))
        sub = None
    if sub:
        small = pixel_font(15).render(sub, True, col)
        if small.get_width() > box.w - 8:
            small = pixel_font(12).render(sub, True, col)
        s.blit(small, small.get_rect(center=(box.centerx, box.centery + (4 if room["kind"] == "mtoilet" else 20))))
    if status == "locked":
        _lock(s, box.right - 28, box.bottom - 30)
    elif status == "done":
        _check(s, box.right - 34, box.bottom - 30)


def draw_map2(s, status, selected, done_count, msg, weapon_text, hp, sprites, max_hp=5):
    s.fill((26, 38, 52))
    for x in range(0, W, 40):
        pygame.draw.line(s, (36, 50, 68), (x, 0), (x, H))
    for y in range(0, H, 40):
        pygame.draw.line(s, (36, 50, 68), (x if False else 0, y), (W, y))
    title = pixel_font(36).render("ПЛАН МЕГАМАРКЕТА", True, (255, 255, 255))
    s.blit(title, title.get_rect(midtop=(W // 2, 18)))
    for y in (250, 330):  # проходы между рядами
        pygame.draw.rect(s, (225, 225, 200), (10, y - 3, W - 20, 6))
    hint = pixel_font(17).render("Отделы по порядку. Склад открывается, когда зачищены все 8 отделов.", True, (170, 190, 210))
    s.blit(hint, hint.get_rect(center=(W // 2, 290)))
    tick = pygame.time.get_ticks()
    for room in MAP_ROOMS2:
        _draw_room(s, room, status(room["id"]), room["id"] == selected, tick)
    for i in range(max_hp):
        img = sprites.heart if i < hp else sprites.heart_empty
        s.blit(img, (20 + i * 32, H - 62))
    info = pixel_font(20).render(f"Оружие: {weapon_text}      Зачищено: {done_count}/{len(MAP_ROOMS2)}", True, (255, 255, 255))
    s.blit(info, (max(190, 20 + max_hp * 32 + 16), H - 60))
    tip = pixel_font(17).render("Мышка или стрелки + Enter — выбрать комнату", True, (170, 190, 210))
    s.blit(tip, tip.get_rect(midbottom=(W // 2, H - 10)))
    if msg:
        txt = pixel_font(22).render(msg, True, (255, 255, 255))
        box = txt.get_rect(center=(W // 2, 290)).inflate(28, 14)
        pygame.draw.rect(s, (160, 50, 60), box, border_radius=8)
        pygame.draw.rect(s, INK, box, 3, border_radius=8)
        s.blit(txt, txt.get_rect(center=box.center))


# ---------------------------------------------------------------- события в отделе
class Store:
    """Что происходит в отделе: враги, червяки из яблок, мимики, акция, объявления."""

    def __init__(self, game, rid):
        from game import Zombie
        self.Zombie = Zombie
        self.g, self.rid = game, rid
        self.t = 0.0
        self.spawn_q = []        # [время, x, вид]: кто ещё придёт
        self.nests = []          # гнёзда червяков в яблочных ящиках
        self.pa_t = random.uniform(14, 22)
        self.sale_done = False
        self.idle_t = 0.0
        extra = ROUND_EXTRA * (game.round - 1)
        for kind, n in SPAWN[rid]:
            for _ in range(n + (extra if kind == "zombie" else 0)):
                game.zombies.append(self.make(kind, random.randint(500, W - 80)))
        for rect, kind in game.furniture:
            if kind == "apples" and rid == "produce":
                self.nests.append({"rect": rect, "sprung": False})

    def make(self, kind, x):
        return self.Zombie(x, kind)

    # ---- лут по сюжету: оружие, кошелёк, мимики
    def setup_loot(self):
        g = self.g
        guaranteed = {"produce": [("toygun", 460, 320)], "meat": [("pony", 465, 340)],
                      "grocery": [("cart", 600, 470)], "toys": [("pony", 350, 340), ("toygun", 790, 340)],
                      "warehouse": [("cart", 300, 470), ("pony", 480, 470)]}.get(self.rid, [])
        for kind, x, y in guaranteed:
            g.add_loot(kind, x, y)
        if self.rid == "mtoilet":
            g.add_loot("wallet", 370, 360, uses=None)   # кошелёк работника лежит на кабинке
        want = {"toys": 2, "bakery": 1}.get(self.rid, 0)   # сюрприз: часть пирожков — мимики
        pies = [i for i in g.pickups if i["kind"] == "pie"]
        while len(pies) < want:
            g.add_loot("pie", random.randint(150, 850), FLOOR)
            pies = [i for i in g.pickups if i["kind"] == "pie"]
        for item in random.sample(pies, want):
            item["mimic"] = True

    # ---- каждый кадр
    def update(self, dt):
        g, p = self.g, self.g.player
        self.t += dt
        # объявления по громкоговорителю
        self.pa_t -= dt
        if self.pa_t <= 0 and not g.msg and g.state == "play":
            g.msg = [random.choice(PA_LINES), 4.5]
            self.pa_t = random.uniform(26, 38)
        # очередь пришедших врагов
        for item in list(self.spawn_q):
            if self.t >= item[0]:
                g.zombies.append(self.make(item[2], item[1]))
                self.spawn_q.remove(item)
        # гнёзда червяков в яблоках: лопаются, когда подходишь (или сами, если всех победил)
        pending = [n for n in self.nests if not n["sprung"]]
        self.idle_t = self.idle_t + dt if (not g.zombies and pending) else 0.0
        for n in pending:
            r = n["rect"]
            if abs(p.x + p.w / 2 - r.centerx) < 150 or self.idle_t > 1.2:
                n["sprung"] = True
                for k in range(2):
                    z = self.make("worm", r.centerx - 20 + k * 30)
                    z.y = r.top - z.h - 12
                    z.vy = -260
                    g.zombies.append(z)
                g.puff(r.centerx, r.top, 10, (215, 50, 55))
                g.add_shake(3, 0.2)
                if not getattr(self, "told", False):
                    self.told = True
                    g.msg = ["Из яблок лезут червяки!", 2.5]
                self.idle_t = 0.0
                break
        # мимик: пирожок оказался зубастым
        for item in list(g.pickups):
            if item.get("mimic") and p.rect.inflate(30, 10).colliderect(item["rect"]):
                g.pickups.remove(item)
                z = self.make("mimic", item["rect"].centerx)
                z.vy = -380
                g.zombies.append(z)
                g.msg = ["Это был мимик!", 2.5]
                g.add_shake(5, 0.25)
                g.puff(item["rect"].centerx, item["rect"].centery, 12, (225, 160, 70))
        # акция в бакалее: толпа с двух сторон
        if self.rid == "grocery" and not self.sale_done and self.t > 8:
            self.sale_done = True
            g.msg = [SALE_LINE, 3.0]
            g.add_shake(4, 0.3)
            kinds = ["zombie", "worm", "zombie", "lamb", "zombie", "chicken"]
            for i, k in enumerate(kinds):
                self.spawn_q.append([self.t + 0.8 * i, 40 if i % 2 else W - 60, k])

    def exit_ready(self):
        """Можно выходить, когда нет ни врагов, ни гнёзд, ни тех, кто ещё придёт (и после акции)."""
        sale_pending = self.rid == "grocery" and not self.sale_done
        return not self.spawn_q and not sale_pending and all(n["sprung"] for n in self.nests)
