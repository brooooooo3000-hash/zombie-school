"""Ежедневные квесты: каждый день новый случайный набор из 6 заданий (3 лёгких, 2 средних, 1 сложное).

Награда монетами падает сразу, как задание выполнено. Выполнил все 6 — ещё бонус.
Набор зависит только от даты, поэтому в течение дня он один и тот же, а завтра совсем другой.
Прогресс хранится в prefs.data["quests"].

Хочешь свой квест? Добавь запись в QUESTS:
  text   — что написано; {0} — число (или название), если есть {1}, то {0} название, а {1} число
  goals  — цели для лёгкого, среднего и сложного уровня
  event  — какое событие считать (их шлёт игра через Game.quest)
  mode   — "add": складывать, "max": запоминать наибольшее (как «дойти до волны»)
  param  — "weapon" или "mod": что подставлять в {0}
  match  — условие, какие события считаются (получает то, что прислала игра, и параметр)
Не забудь перевод в translations.py (текст-шаблон) и вызов Game.quest(...) там, где это происходит.
"""
import datetime
import random

import classes
import modifiers
import prefs
from weapons import WEAPONS

PER_DAY = 6
TIERS = (0, 0, 0, 1, 1, 2)          # лёгкие, средние, сложный
TIER_REWARD = (15, 30, 60)          # монет за уровень
ALL_BONUS = 50                      # бонус, если выполнены все
KILL_WEAPONS = ["ruler", "piebomb", "slingshot", "watergun", "foamgun", "chalk", "textbook", "pointer", "mop",
                "club", "toygun"]


def _kind(name):
    return lambda kw, param: kw.get("kind") == name


QUESTS = {
    "kill": dict(text="Убить врагов: {0}", goals=(25, 50, 100), event="kill", mode="add"),
    "kill_worm": dict(text="Убить червяков: {0}", goals=(6, 12, 20), event="kill", mode="add", match=_kind("worm")),
    "kill_chicken": dict(text="Убить кур: {0}", goals=(5, 10, 16), event="kill", mode="add", match=_kind("chicken")),
    "kill_lamb": dict(text="Убить барашков: {0}", goals=(4, 8, 14), event="kill", mode="add", match=_kind("lamb")),
    "kill_cow": dict(text="Убить коров: {0}", goals=(2, 4, 7), event="kill", mode="add", match=_kind("cow")),
    "kill_fists": dict(text="Убить кулаками: {0}", goals=(8, 20, 40), event="kill", mode="add",
                       match=lambda kw, param: kw.get("weapon") == "fists"),
    "kill_weapon": dict(text="Убить оружием «{0}»: {1}", goals=(6, 14, 28), event="kill", mode="add", param="weapon",
                        match=lambda kw, param: kw.get("weapon") == param),
    "pie": dict(text="Съесть пирожков: {0}", goals=(3, 6, 12), event="pie", mode="add"),
    "room": dict(text="Зачистить комнат: {0}", goals=(2, 4, 7), event="room", mode="add"),
    "nohit": dict(text="Комнат без урона: {0}", goals=(1, 2, 3), event="nohit", mode="add"),
    "jump": dict(text="Прыжков: {0}", goals=(40, 100, 200), event="jump", mode="add"),
    "coins": dict(text="Заработать монет: {0}", goals=(40, 100, 200), event="coins", mode="add"),
    "boss": dict(text="Победить боссов: {0}", goals=(1, 1, 2), event="boss", mode="add"),
    "pickup": dict(text="Подобрать оружия: {0}", goals=(5, 10, 20), event="pickup", mode="add"),
    "wave": dict(text="Бесконечный режим: дойти до волны {0}", goals=(3, 6, 10), event="wave", mode="max"),
    "runs": dict(text="Бесконечный режим: забегов {0}", goals=(1, 2, 3), event="run", mode="add"),
    "mod_wave": dict(text="Бесконечный режим с «{0}»: дойти до волны {1}", goals=(3, 5, 8), event="wave", mode="max",
                     param="mod", match=lambda kw, param: param in kw.get("mods", ())),
}


def _today():
    return datetime.date.today().isoformat()


def today():
    return _today()


def generate(day):
    """Набор заданий на день (одинаковый для одной и той же даты). Прогресса ещё нет."""
    rng = random.Random(day)
    keys = rng.sample(list(QUESTS), PER_DAY)
    items = []
    for key, tier in zip(keys, TIERS):
        q = QUESTS[key]
        param = None
        if q.get("param") == "weapon":
            param = rng.choice(KILL_WEAPONS)
        elif q.get("param") == "mod":
            param = rng.choice(modifiers.KEYS)
        items.append({"key": key, "tier": tier, "goal": q["goals"][tier], "param": param, "progress": 0, "done": False})
    return items


def ensure():
    """Сегодняшние квесты (если день сменился, набор новый)."""
    day = _today()
    data = prefs.data.get("quests")
    if not isinstance(data, dict) or data.get("day") != day:
        data = {"day": day, "items": generate(day), "bonus": False}
        prefs.data["quests"] = data
    return data


def reward(item):
    return TIER_REWARD[item["tier"]]


def param_name(item):
    """Название для {0}: имя оружия или модификатора (по-русски, переводится при показе)."""
    if item["param"] is None:
        return None
    if QUESTS[item["key"]].get("param") == "weapon":
        return WEAPONS[item["param"]]["name"]
    return modifiers.BY_KEY[item["param"]][1]


def text(item):
    """Текст задания по-русски (в игре он проходит через перевод как шаблон)."""
    tmpl = QUESTS[item["key"]]["text"]
    name = param_name(item)
    return tmpl.format(item["goal"]) if name is None else tmpl.format(name, item["goal"])


def progress(event, n=1, **kw):
    """Игра сообщает, что случилось. Возвращает (список только что выполненных заданий, дан ли бонус за все).
    Монеты за выполненное сразу кладутся в копилку."""
    data = ensure()
    finished = []
    for item in data["items"]:
        q = QUESTS[item["key"]]
        if item["done"] or q["event"] != event:
            continue
        match = q.get("match")
        if match and not match(kw, item["param"]):
            continue
        value = kw.get("value", n) if q["mode"] == "max" else n
        item["progress"] = max(item["progress"], value) if q["mode"] == "max" else item["progress"] + value
        if item["progress"] >= item["goal"]:
            item["progress"], item["done"] = item["goal"], True
            classes.add_coins(reward(item))
            finished.append(item)
    bonus = False
    if finished and not data["bonus"] and all(i["done"] for i in data["items"]):
        data["bonus"] = bonus = True
        classes.add_coins(ALL_BONUS)
    if finished:
        prefs.save()
    return finished, bonus


def done_count():
    return sum(1 for i in ensure()["items"] if i["done"])
