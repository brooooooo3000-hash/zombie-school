"""Глава 3 «Поезд»: заражённый скоростной поезд Сеул — Пусан. Идёшь по вагонам к кабине машиниста.

Класс Train живёт, пока ты в вагоне. Он ведёт волны врагов, тоннели (свет гаснет) и стоп-кран.
Game вызывает его каждый кадр (update), рисует тьму тоннеля (draw_dark) и интерфейс (draw_hud).

Хочешь свой вагон? Добавь запись в CARRIAGES (волны, тоннель) и вагон в rooms_train.py.
  waves   — список волн: сколько врагов каждого вида ("zombie", "runner" — быстрый), "hp" — прибавка здоровья
  tunnel  — (раз в сколько секунд, на сколько секунд гаснет свет) или None
  lever   — есть ли стоп-кран (одно нажатие на вагон: все враги замирают)
  boss    — в конце выходит босс (кабина машиниста)
"""
import math
import random

import pygame

from darkness import draw_darkness
from pixelfont import pixel_font
from rooms_train import LEVER_ZONE
from settings import FLOOR, INK, W

TUNNEL_LIGHT_R = 190    # радиус света в тоннеле
BRAKE_STUN = 4.0        # на сколько секунд замирают враги от стоп-крана

CARRIAGES = {
    "seats": {"waves": [{"zombie": 4}, {"zombie": 5, "runner": 1}, {"zombie": 6, "runner": 1}],
              "tunnel": None,
              "lever": True, "objective": "Отбейся от заражённых пассажиров", "intro": "Вагон 1: пассажиры заражены"},
    "cafe": {"waves": [{"zombie": 4, "runner": 1}, {"zombie": 5, "runner": 2}], "tunnel": (18, 4), "lever": True,
             "objective": "Пробейся через вагон-кафе", "intro": "Вагон-кафе: свет мигает"},
    "sleeper": {"waves": [{"zombie": 5, "runner": 2}, {"zombie": 5, "runner": 3}, {"zombie": 6, "runner": 3}],
                "tunnel": (16, 5), "lever": True, "objective": "В спальном вагоне уже никто не спит",
                "intro": "Спальный вагон: койки пустые"},
    "luggage": {"waves": [{"zombie": 6, "runner": 2}, {"zombie": 6, "runner": 4}], "tunnel": (14, 5),
                "lever": True, "objective": "Пробейся через багажный вагон", "intro": "Багажный вагон: чемоданы падают"},
    "cab": {"waves": [{"runner": 2}], "tunnel": None, "lever": False, "boss": True,
            "objective": "Останови поезд: победи машиниста", "intro": "Кабина машиниста"},
}


# хулиганы в первом вагоне: каждый кричит свои фразы по очереди сам, ничего нажимать не надо
BULLY_PHRASES = {"bully1": ["На тебе!", "Отдай!", "Получай!"],
                 "bully2": ["Это моё!", "Аааааа!", "Не лезь!"],
                 "bully3": ["На, получай!", "Ща как дам!", "Аааааа!"]}
PHRASE_TIME = 2.4       # сколько секунд висит одна фраза
BRAWL_SCALE = 0.82      # на заднем плане все чуть меньше
BRAWL_FEET = FLOOR - 14  # и стоят чуть дальше от зрителя (выше по экрану)
BRAWL_SPOTS = (610, 740, 870)   # где дерётся каждый из троих
_scaled = {}


def small(img, flip):
    """Картинка поменьше (для заднего плана), в нужную сторону. Запоминаем, чтобы не считать каждый кадр."""
    key = (id(img), flip)
    if key not in _scaled:
        w, h = img.get_size()
        out = pygame.transform.smoothscale(img, (int(w * BRAWL_SCALE), int(h * BRAWL_SCALE)))
        _scaled[key] = pygame.transform.flip(out, True, False) if flip else out
    return _scaled[key]


class Brawl:
    """Три хулигана вламываются в вагон и дерутся с заражёнными на заднем плане (на бой героя не влияют).

    Каждый бьёт по очереди ногой, рукой и стулом, а заражённые отлетают и поднимаются. Фразы над головами
    меняются сами."""
    ENTER = 2.6      # сколько секунд хулиганы заходят в вагон
    CYCLE = 1.8      # один круг драки: удар, отлёт, подъём

    def __init__(self):
        self.t = 0.0

    def update(self, dt):
        self.t += dt

    @staticmethod
    def phrase(kind, t, stagger):
        """Какую фразу говорит этот хулиган сейчас."""
        lines = BULLY_PHRASES[kind]
        return lines[int((t + stagger) / PHRASE_TIME) % len(lines)]

    def draw(self, s, sp):
        t = self.t
        for i, kind in enumerate(("bully1", "bully2", "bully3")):
            gx = BRAWL_SPOTS[i]
            k = min(1.0, t / self.ENTER)   # заходят справа
            x = gx + (1 - k) * (W + 90 - gx) + i * 40 * (1 - k)
            cyc = (t + i * 0.6) / self.CYCLE
            phase = cyc % 1.0
            blow = int(cyc) % 3          # 0 — ногой, 1 — рукой, 2 — стулом
            walking = k < 1.0
            frames = sp.humans[kind]
            if walking:
                img = frames[f"run{int(x / 36) % 4}"]
            elif phase < 0.3:   # замах и удар
                img = frames["jump"] if blow == 0 else frames["walk0"]
            else:
                img = frames["idle"]
            img = small(img, True)
            if not walking:   # жертвы: два заражённых слева от каждого хулигана
                for j, (dx, off) in enumerate(((-64, 0.0), (-128, 0.5))):
                    zph = (cyc + off) % 1.0
                    hit = zph < 0.45     # сначала отлетает, потом поднимается
                    back = math.sin(zph / 0.45 * math.pi) * 38 if hit else 0.0
                    ang = math.sin(zph / 0.45 * math.pi) * 62 if hit else 0.0
                    zimg = pygame.transform.rotate(small(sp.zombie[f"walk{int(t * 6 + j) % 4}"], False), ang)
                    zx = x + dx - back
                    s.blit(zimg, zimg.get_rect(midbottom=(int(zx), BRAWL_FEET - int(back * 0.3))))
            s.blit(img, img.get_rect(midbottom=(int(x), BRAWL_FEET)))
            if not walking and phase < 0.3:   # чем бьёт
                if blow == 2:   # стул
                    chair = small(sp.weapon["chair"][0], True)
                    chair = pygame.transform.rotate(chair, 50 - phase / 0.3 * 100)
                    s.blit(chair, chair.get_rect(center=(int(x - 44), BRAWL_FEET - 52)))
                elif blow == 1:  # кулак
                    fist = small(sp.fist, True)
                    s.blit(fist, fist.get_rect(center=(int(x - 36), BRAWL_FEET - 44)))
            if not walking:   # фраза над головой
                text = self.phrase(kind, t, i * 0.8)
                lab = pixel_font(16).render(text, True, (30, 30, 40))
                box = lab.get_rect(midbottom=(int(x), BRAWL_FEET - 108)).inflate(16, 10)
                pygame.draw.rect(s, INK, box.inflate(4, 4), border_radius=8)
                pygame.draw.rect(s, (250, 250, 245), box, border_radius=6)
                pygame.draw.polygon(s, (250, 250, 245), [(int(x) - 5, box.bottom - 1), (int(x) + 5, box.bottom - 1),
                                                         (int(x), box.bottom + 7)])
                s.blit(lab, lab.get_rect(center=box.center))


class Train:
    """Сюжет и правила одного вагона."""

    def __init__(self, game, rid):
        self.g, self.rid = game, rid
        self.cfg = CARRIAGES[rid]
        self.t = 0.0
        self.wave = 0
        self.spawn_q = []          # очередь врагов: [время, x, вид, прибавка здоровья]
        self.ready = False
        self.boss_started = False
        self.finished = False
        tun = self.cfg.get("tunnel")
        self.tunnel_t = tun[0] if tun else None   # сколько до следующего тоннеля
        self.dark_left = 0.0                       # сколько ещё темно
        self.brake = 1 if self.cfg.get("lever") else 0
        self.brawl = None          # драка хулиганов на заднем плане (только в первом вагоне)
        self.objective = self.cfg["objective"]
        game.msg = [self.cfg["intro"], 3.0]

    # ------------------------------------------------ стоп-кран
    def near_lever(self):
        return self.brake > 0 and self.g.player.rect.colliderect(LEVER_ZONE)

    def pull_brake(self):
        """Кнопка E у красного крана: все враги замирают. Возвращает True, если нажатие обработано."""
        if not self.near_lever():
            return False
        g = self.g
        self.brake -= 1
        for z in g.zombies:
            z.stun_t = max(z.stun_t, BRAKE_STUN)
        if g.boss is not None:
            g.boss.stun_t = max(g.boss.stun_t, 1.5)
        g.add_shake(7, 0.5)
        g.puff(W - 100, FLOOR - 60, 14, (230, 230, 240))
        g.msg = ["Стоп-кран! Все замерли", 2.0]
        return True

    def setup_loot(self):
        """Возле стоп-крана вещей не кладём: иначе кнопка E взяла бы оружие вместо рывка крана."""
        zone = LEVER_ZONE.inflate(60, 0)
        self.g.pickups = [i for i in self.g.pickups if not i["rect"].colliderect(zone)]

    def take_label(self):
        """Подпись на кнопке «взять» (на телефоне)."""
        if self.near_lever() and not self.g.weapon_item_near():
            return "СТОП-КРАН"
        return "ВЗЯТЬ"

    # ------------------------------------------------ враги
    def spawn(self, x, kind, hp_bonus=0):
        from game import Zombie
        z = Zombie(x, kind)
        z.hp += hp_bonus
        self.g.zombies.append(z)

    def start_wave(self):
        g, p = self.g, self.g.player
        wave = self.cfg["waves"][self.wave]
        self.wave += 1
        kinds = [k for k in ("zombie", "runner") for _ in range(wave.get(k, 0))]
        random.shuffle(kinds)
        near, far = (60, W - 60) if p.x > W / 2 else (W - 60, 60)   # враги выходят из дверей по обе стороны вагона
        self.spawn_q = [[self.t + 1.2 + 1.1 * i, far if i % 2 == 0 else near, kind, wave.get("hp", 0)]
                        for i, kind in enumerate(kinds)]
        if len(self.cfg["waves"]) > 1:
            g.msg = [f"Волна {self.wave} из {len(self.cfg['waves'])}", 2.0]

    def exit_ready(self):
        return self.ready

    # ------------------------------------------------ каждый кадр
    def update(self, dt, keys):
        g = self.g
        self.t += dt
        for item in list(self.spawn_q):   # враги выходят по очереди
            if self.t >= item[0]:
                self.spawn(item[1], item[2], item[3])
                self.spawn_q.remove(item)
        if self.tunnel_t is not None:     # тоннели: свет гаснет на несколько секунд
            if self.dark_left > 0:
                self.dark_left -= dt
                if self.dark_left <= 0:
                    self.tunnel_t = self.cfg["tunnel"][0]
            else:
                self.tunnel_t -= dt
                if self.tunnel_t <= 0:
                    self.dark_left = self.cfg["tunnel"][1]
                    g.msg = ["Тоннель! Свет погас", 2.0]
        if self.brawl is not None:
            self.brawl.update(dt)
        elif self.rid == "seats" and self.wave >= 2:   # со второй волной в вагон вламываются хулиганы
            self.brawl = Brawl()
            g.msg = ["В вагон вломились хулиганы!", 3.0]
        if self.spawn_q or g.zombies or g.boss is not None or self.ready:
            return
        if self.wave < len(self.cfg["waves"]):
            self.start_wave()
        elif self.cfg.get("boss") and not self.boss_started:
            self.boss_started = True   # враги кончились: из-за пульта поворачивается машинист
            g.spawn_driver()
        else:
            self.ready = True
            self.objective = "Вагон свободен: иди к двери справа"
            if self.cfg.get("boss") and not self.finished:   # в кабине дверь не нужна: поезд остановлен
                self.finished = True
                g.finish_room()

    # ------------------------------------------------ рисование
    def draw_back(self, s):
        """Задний план: драка хулиганов (рисуется до героя и врагов, поэтому бой героя виден поверх неё)."""
        if self.brawl is not None:
            self.brawl.draw(s, self.g.sprites)

    def draw_dark(self, s):
        """Тоннель: темнота, видно только вокруг героя."""
        if self.dark_left > 0 and self.cfg.get("tunnel"):
            p = self.g.player
            fade = min(1.0, self.dark_left / 0.4, (self.cfg["tunnel"][1] - self.dark_left) / 0.3 + 0.2)
            draw_darkness(s, int(205 * min(1.0, fade)), [(p.x + p.w / 2, p.y + 30, TUNNEL_LIGHT_R)])

    def draw_hud(self, s, font):
        small = pixel_font(20)
        g = self.g
        if self.objective:   # цель сверху по центру
            txt = small.render("Цель: " + self.objective, True, (255, 255, 255))
            box = txt.get_rect(midtop=(W // 2, 58)).inflate(22, 10)
            box.x = max(180, min(box.x, W - box.w - 150))
            back = pygame.Surface(box.size, pygame.SRCALPHA)
            back.fill((15, 15, 25, 190))
            s.blit(back, box)
            s.blit(txt, txt.get_rect(center=box.center))
        # стоп-кран: значок и сколько нажатий осталось
        if self.cfg.get("lever"):
            pygame.draw.rect(s, INK, (14, 58, 156, 34), border_radius=6)
            pygame.draw.rect(s, (40, 44, 60), (17, 61, 150, 28), border_radius=5)
            pygame.draw.rect(s, (210, 50, 50) if self.brake else (90, 60, 60), (24, 65, 14, 20), border_radius=3)
            t = pixel_font(16).render("Стоп-кран", True, (255, 255, 255) if self.brake else (150, 150, 160))
            s.blit(t, t.get_rect(midleft=(46, 75)))
            n = pixel_font(16).render(f" {self.brake}", True, (255, 220, 120) if self.brake else (150, 150, 160))
            s.blit(n, n.get_rect(midleft=(46 + t.get_width(), 75)))
        if self.near_lever() and not g.weapon_item_near() and not g.over:
            t = small.render("E — стоп-кран", True, (255, 255, 255))
            s.blit(t, t.get_rect(center=(g.player.x + g.player.w / 2, g.player.y - 20)))
        if self.tunnel_t is not None and self.dark_left <= 0 and self.tunnel_t < 3.5:   # скоро тоннель
            t = small.render("Тоннель", True, (255, 200, 120))
            s.blit(t, t.get_rect(center=(W // 2, 120)))
