import asyncio

import pygame  # pygbag по этой строке понимает, что нужен pygame

import game

asyncio.run(game.main())
