"""Звуки игры. Сейчас один: «пип-пип-пип» речи, когда в катсцене кто-то говорит.

Звук рисуется кодом (никаких файлов): короткий писк на каждую вторую букву и длинный «пииииб» в конце
предложения. У каждого персонажа свой голос: у директора низкий, у девочки высокий.
Если звука на устройстве нет или он выключен в настройках, игра просто молчит и не ломается.

Хочешь голос новому персонажу? Добавь его имя (как в катсцене) и высоту в Гц в VOICES.
"""
import array
import math
import random

import pygame

import prefs

# высота голоса в герцах: чем больше, тем писклявее
VOICES = {"Ты": 360, "Директор": 105, "Зомби": 85, "Школа": 70, "Дневник": 300, "Повариха": 250, "Борян": 140,
          "Толян": 180, "Колян": 115, "Девочка": 480, "Работник магазина": 200, "Громкоговоритель": 400,
          "Королева": 95, "Диктор": 230}
SHORT = 0.065          # сколько длится обычный писк, секунд
LONG = 0.24            # и «пииииб» в конце предложения
VOLUME = 0.45
JITTER = (0.9, 1.0, 1.1, 1.2)   # голос чуть гуляет по высоте, как живая речь

_cache = {}
_state = {"count": 0, "ok": None, "spec": None, "last": ""}


def _spec():
    """Как настроен звук (частота, число каналов), или None, если звука нет."""
    if _state["ok"] is None:
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(22050, -16, 1, 512)
            init = pygame.mixer.get_init()
            _state["spec"] = init if init and init[1] == -16 else None   # понимаем только 16-битный звук
        except Exception:
            _state["spec"] = None
        _state["ok"] = _state["spec"] is not None
    return _state["spec"]


def make_samples(pitch, seconds, rate=22050, glide=0.12, channels=1):
    """Писк: квадратная волна с быстрым началом и затуханием, высота чуть уходит вверх (или вниз, если glide < 0)."""
    n = int(rate * seconds)
    out = array.array("h")
    phase = 0.0
    for i in range(n):
        t = i / n
        f = pitch * (1 + glide * (t if glide > 0 else t * 1.5))
        phase += f / rate
        wave = 1.0 if (phase % 1.0) < 0.5 else -1.0
        env = min(1.0, i / (rate * 0.004)) * (1.0 - t) ** 0.6   # быстро нарастает и плавно затухает
        v = int(wave * env * VOLUME * 32767 * 0.5)
        out.extend([v] * channels)
    return out


def blip(pitch, long=False):
    """Звук одного писка (запоминаем, чтобы не считать заново)."""
    spec = _spec()
    if spec is None:
        return None
    rate, _, channels = spec
    key = (round(pitch), long, rate, channels)
    snd = _cache.get(key)
    if snd is None:
        samples = make_samples(pitch, LONG if long else SHORT, rate, glide=-0.1 if long else 0.12, channels=channels)
        snd = pygame.mixer.Sound(buffer=samples.tobytes())
        _cache[key] = snd
    return snd


def speak(who, ch):
    """Вызывается на каждую «напечатанную» букву. Возвращает "short", "long" или None (молчим).

    Говорит только тот, у кого есть имя (рассказчик молчит). Писк на каждую вторую букву, на конце
    предложения (. ! ?) один длинный."""
    last, _state["last"] = _state["last"], ch
    if not who or not prefs.get("sound"):
        return None
    if ch in ".!?…":
        if last in ".!?…":   # «...» — один «пииииб», а не три
            return None
        kind = "long"
    elif ch.isalnum():
        _state["count"] += 1
        if _state["count"] % 2:
            return None
        kind = "short"
    else:
        return None
    pitch = VOICES.get(who, 220) * random.choice(JITTER)
    try:
        snd = blip(pitch, kind == "long")
        if snd is not None:
            snd.play()
    except Exception:
        pass
    return kind
