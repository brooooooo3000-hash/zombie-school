"""Классы героя и цены. За монеты (их дают за зомби, комнаты и победы) покупаются скины и классы.

Хочешь свой класс? Добавь запись в CLASSES:
  hp     — сколько сердец
  speed  — множитель скорости (1.2 — быстрее на 20%, 0.7 — медленнее на 30%)
  slots  — сколько мест под оружие (2 — можно носить два и менять кнопкой Q)
  weapon — ключ оружия из weapons.py, которое дают в начале игры (и пополняют в каждой комнате)
  price  — цена в монетах
"""
import prefs

CLASSES = {
    "normal": {"name": "Обыкновенный", "price": 0, "hp": 5, "speed": 1.0, "slots": 1, "weapon": None,
               "desc": ["Без бонусов.", "Просто ты."]},
    "joker": {"name": "Приколист", "price": 250, "hp": 5, "speed": 1.2, "slots": 2, "weapon": "toygun",
              "desc": ["Скорость +20%", "Два места под оружие", "Игрушечный пистолет"]},
    "nerd": {"name": "Ботан", "price": 250, "hp": 7, "speed": 0.7, "slots": 1, "weapon": None,
             "desc": ["7 сердец", "Скорость -30%"]},
}
CLASS_KEYS = list(CLASSES)

SKIN_PRICE = {"blue": 0, "green": 40, "orange": 40, "purple": 80, "pink": 80, "ninja": 150, "dobok": 150,
              "gold": 300}

# промокоды: код (маленькими буквами) -> что открывает. Хочешь свой? Добавь строку.
PROMOS = {
    "zs-k7q4m9": ("class", "joker"),
}

# сколько монет дают
COIN_ZOMBIE = 1
COIN_ROOM = 10
COIN_BOSS_ROOM = {"c7": 40, "office": 60, "apt": 15, "stairs": 10, "lobby": 30, "shop": 100}
COIN_CHAPTER = 100


def current():
    """Выбранный класс (если выбран неизвестный или не купленный, играем обыкновенным)."""
    key = prefs.get("klass")
    if key not in CLASSES or key not in prefs.get("owned_classes"):
        key = "normal"
    return CLASSES[key]


def current_key():
    key = prefs.get("klass")
    return key if key in CLASSES and key in prefs.get("owned_classes") else "normal"


def owns_skin(key):
    return key in prefs.get("owned_skins")


def owns_class(key):
    return key in prefs.get("owned_classes")


def add_coins(n):
    """Монеты копятся в памяти, а на диск пишутся позже (prefs.save()), чтобы не писать файл на каждого зомби."""
    prefs.data["coins"] = prefs.get("coins") + n


def redeem(code):
    """Промокод. Возвращает (статус, текст): "ok" — открыто, "owned" — уже было, "bad" — нет такого, "empty"."""
    code = (code or "").strip().lower()
    if not code:
        return "empty", ""
    found = PROMOS.get(code)
    if not found:
        return "bad", "Такого промокода нет"
    kind, key = found
    if kind == "class":
        owned = list(prefs.get("owned_classes"))
        name = CLASSES[key]["name"]
        if key in owned:
            return "owned", f"Класс {name} уже открыт"
        owned.append(key)
        prefs.set("owned_classes", owned)
        return "ok", f"Промокод принят! Открыт класс {name}"
    return "bad", "Такого промокода нет"


def buy(kind, key):
    """Покупка. kind — "skin" или "class". Возвращает "ok" (куплено), "owned" (уже было) или "poor" (мало монет)."""
    owned_key = "owned_skins" if kind == "skin" else "owned_classes"
    price = SKIN_PRICE[key] if kind == "skin" else CLASSES[key]["price"]
    owned = list(prefs.get(owned_key))
    if key in owned:
        return "owned"
    if prefs.get("coins") < price:
        return "poor"
    prefs.data["coins"] -= price
    owned.append(key)
    prefs.set(owned_key, owned)  # заодно сохраняет и монеты
    return "ok"
