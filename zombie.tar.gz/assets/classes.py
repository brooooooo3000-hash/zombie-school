"""Классы героя и цены. За монеты (их дают за зомби, комнаты и победы) покупаются скины и классы.

Хочешь свой класс? Добавь запись в CLASSES:
  hp     — сколько сердец
  speed  — множитель скорости (1.2 — быстрее на 20%, 0.7 — медленнее на 30%)
  slots  — сколько мест под оружие (2 — можно носить два и менять кнопкой Q)
  weapon — ключ оружия из weapons.py, которое дают в начале игры (и пополняют в каждой комнате)
  price  — цена в монетах
Особые умения (необязательные):
  kick        — True: кулаки бьют сильнее и отбрасывают (удар ногой, Тхэквондист)
  uses_mult   — во сколько раз меньше зарядов у подобранного оружия (0.6 — на 40% меньше)
  double_jump — True: можно прыгнуть второй раз в воздухе (Геймер)
  cd_mult     — множитель паузы между ударами (0.7 — бьёт на 30% быстрее)
"""
import re

import prefs

CLASSES = {
    "normal": {"name": "Обыкновенный", "price": 0, "hp": 5, "speed": 1.0, "slots": 1, "weapon": None,
               "desc": ["Без бонусов.", "Просто ты."]},
    "joker": {"name": "Приколист", "price": 250, "hp": 5, "speed": 1.2, "slots": 2, "weapon": "toygun",
              "desc": ["Скорость +20%", "Два места под оружие", "Игрушечный пистолет"]},
    "nerd": {"name": "Ботан", "price": 250, "hp": 7, "speed": 0.7, "slots": 1, "weapon": None,
             "desc": ["7 сердец", "Скорость -30%"]},
    "taekwondo": {"name": "Тхэквондист", "price": 300, "hp": 6, "speed": 1.0, "slots": 1, "weapon": None,
                  "kick": True, "uses_mult": 0.6,
                  "desc": ["Удар ногой: кулаки сильнее", "6 сердец", "Оружие кончается быстрее"]},
    "gamer": {"name": "Геймер", "price": 300, "hp": 3, "speed": 1.0, "slots": 1, "weapon": None,
              "double_jump": True, "cd_mult": 0.7,
              "desc": ["Двойной прыжок", "Быстрые удары", "Всего 3 сердца"]},
}
CLASS_KEYS = list(CLASSES)

SKIN_PRICE = {"blue": 0, "green": 40, "orange": 40, "purple": 80, "pink": 80, "ninja": 150, "dobok": 150,
              "gold": 300}

# промокоды: код (маленькими буквами) -> что открывает. Хочешь свой? Добавь строку.
PROMOS = {
    "67smeh": ("class", "joker"),       # первый код Вовы
    "zs-k7q4m9": ("class", "joker"),    # второй код (его придумала Verity)
}

# сколько монет дают
COIN_ZOMBIE = 1
COIN_ROOM = 10
COIN_BOSS_ROOM = {"c7": 40, "office": 60, "electro": 20, "warehouse": 120}   # остальные комнаты: COIN_ROOM
COIN_CHAPTER = 100


def current():
    """Выбранный класс (если выбран неизвестный или не купленный, играем обыкновенным)."""
    key = prefs.get("klass")
    if key not in CLASSES or key not in prefs.get("owned_classes"):
        key = "normal"
    return CLASSES[key]


def current_key():
    key = prefs.get("klass")
    return key if key in CLASSES and key in prefs.get("owned_classes") else "normal"


def owns_skin(key):
    return key in prefs.get("owned_skins")


def owns_class(key):
    return key in prefs.get("owned_classes")


def add_coins(n):
    """Монеты копятся в памяти, а на диск пишутся позже (prefs.save()), чтобы не писать файл на каждого зомби."""
    prefs.data["coins"] = prefs.get("coins") + n


# русская раскладка -> те же клавиши на английской (чтобы код работал, даже если набрал не на той раскладке)
_RU_TO_EN = dict(zip("йцукенгшщзхъфывапролджэячсмитьбю", "qwertyuiop[]asdfghjkl;'zxcvbnm,."))


def clean_code(code):
    """Приводим набранный код к простому виду: маленькие буквы, английская раскладка, без пробелов и дефисов."""
    code = (code or "").strip().lower()
    code = "".join(_RU_TO_EN.get(ch, ch) for ch in code)
    return re.sub(r"[\s\-_]", "", code)


def redeem(code):
    """Промокод. Возвращает (статус, текст): "ok" — открыто, "owned" — уже было, "bad" — нет такого, "empty"."""
    code = clean_code(code)
    if not code:
        return "empty", ""
    found = {clean_code(k): v for k, v in PROMOS.items()}.get(code)
    if not found:
        return "bad", "Такого промокода нет"
    kind, key = found
    if kind == "class":
        owned = list(prefs.get("owned_classes"))
        name = CLASSES[key]["name"]
        if key in owned:
            return "owned", f"Класс {name} уже открыт"
        owned.append(key)
        prefs.set("owned_classes", owned)
        return "ok", f"Промокод принят! Открыт класс {name}"
    return "bad", "Такого промокода нет"


def buy(kind, key):
    """Покупка. kind — "skin" или "class". Возвращает "ok" (куплено), "owned" (уже было) или "poor" (мало монет)."""
    owned_key = "owned_skins" if kind == "skin" else "owned_classes"
    price = SKIN_PRICE[key] if kind == "skin" else CLASSES[key]["price"]
    owned = list(prefs.get(owned_key))
    if key in owned:
        return "owned"
    if prefs.get("coins") < price:
        return "poor"
    prefs.data["coins"] -= price
    owned.append(key)
    prefs.set(owned_key, owned)  # заодно сохраняет и монеты
    return "ok"
