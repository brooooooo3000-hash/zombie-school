"""Классы героя и цены. За монеты (их дают за зомби, комнаты и победы) покупаются скины и классы.

Хочешь свой класс? Добавь запись в CLASSES:
  hp     — сколько сердец
  speed  — множитель скорости (1.2 — быстрее на 20%, 0.7 — медленнее на 30%)
  slots  — сколько мест под оружие (2 — можно носить два и менять кнопкой Q)
  weapon — ключ оружия из weapons.py, которое дают в начале игры (и пополняют в каждой комнате)
  price  — цена в монетах
Особые умения (необязательные):
  kick        — True: кулаки бьют сильнее и отбрасывают (удар ногой, Тхэквондист)
  uses_mult   — во сколько раз меньше зарядов у подобранного оружия (0.6 — на 40% меньше)
  double_jump — True: можно прыгнуть второй раз в воздухе (Геймер)
  cd_mult     — множитель паузы между ударами (0.7 — бьёт на 30% быстрее)

Уровни: класс (после покупки он 1-го уровня) можно улучшать за монеты до 5-го. Что даёт каждый уровень, написано
в PERKS: список из четырёх улучшений (для уровней 2, 3, 4, 5). Улучшение — это текст и словарь «что меняется».
Ключи словаря: hp, speed, uses_mult, cd_mult перекрывают числа класса, остальные — новые умения:
  dmg_mult, rage, coin_mult, pie_bonus, kill_pie, weapon_uses, stumble, focus, hurt_mult, pie_heal, kick_dmg,
  kick_both, whirl, combo, revive (что значит каждое, смотри в game.py: Game.apply_class и места, где они читаются).
"""
import re

import prefs

CLASSES = {
    "normal": {"name": "Обыкновенный", "price": 0, "hp": 5, "speed": 1.0, "slots": 1, "weapon": None,
               "desc": ["Без бонусов.", "Просто ты."]},
    "joker": {"name": "Приколист", "price": 85, "hp": 5, "speed": 1.2, "slots": 2, "weapon": "toygun",
              "desc": ["Скорость +20%", "Два места под оружие", "Игрушечный пистолет"]},
    "nerd": {"name": "Ботан", "price": 85, "hp": 7, "speed": 0.7, "slots": 1, "weapon": None,
             "desc": ["7 сердец", "Скорость -30%"]},
    "taekwondo": {"name": "Тхэквондист", "price": 100, "hp": 6, "speed": 1.0, "slots": 1, "weapon": None,
                  "kick": True, "uses_mult": 0.6,
                  "desc": ["Удар ногой: кулаки сильнее", "6 сердец", "Оружие кончается быстрее"]},
    "gamer": {"name": "Геймер", "price": 100, "hp": 3, "speed": 1.0, "slots": 1, "weapon": None,
              "double_jump": True, "cd_mult": 0.7,
              "desc": ["Двойной прыжок", "Быстрые удары", "Всего 3 сердца"]},
}
CLASS_KEYS = list(CLASSES)

PRICE_OLD = {"joker": 250, "nerd": 250, "taekwondo": 300, "gamer": 300}   # цены до удешевления в 3 раза
MAX_LEVEL = 5
UPGRADE_COST = (60, 120, 200, 320)   # сколько монет стоит уровень 2, 3, 4 и 5
PERKS = {   # для каждого класса четыре улучшения: уровни 2, 3, 4, 5 (текст, что меняется)
    "normal": [("Скорость +10%", {"speed": 1.1}), ("Урон +25%", {"dmg_mult": 1.25}), ("6 сердец", {"hp": 6}),
               ("Ярость: на последнем сердце урон ×2", {"rage": True})],
    "joker": [("Пистолет: 40 зарядов", {"weapon_uses": 40}), ("Скорость +30%", {"speed": 1.3}),
              ("Удар может сбить врага с ног", {"stumble": 0.15}),
              ("Фокус: на последнем сердце враги замирают", {"focus": True})],
    "nerd": [("8 сердец", {"hp": 8}), ("Скорость -20%", {"speed": 0.8}), ("После укуса защита дольше", {"hurt_mult": 1.55}),
             ("Пирожки лечат на 2 сердца", {"pie_heal": 2})],
    "taekwondo": [("Удар ногой сильнее", {"kick_dmg": 3}), ("Оружие кончается медленнее", {"uses_mult": 0.8}),
                  ("Нога бьёт и назад", {"kick_both": True}),
                  ("Вертушка: удар в прыжке сбивает всех", {"whirl": True})],
    "gamer": [("4 сердца", {"hp": 4}), ("Удары ещё быстрее", {"cd_mult": 0.6}),
              ("Серия убийств даёт монеты", {"combo": True}), ("Продолжить?: одна лишняя жизнь", {"revive": True})],
}

SKIN_PRICE = {"blue": 0, "green": 40, "orange": 40, "purple": 80, "pink": 80, "ninja": 150, "dobok": 150,
              "gold": 300}

# промокоды: код (маленькими буквами) -> что открывает. Хочешь свой? Добавь строку.
PROMOS = {
    "67smeh": ("class", "joker"),       # первый код Вовы
    "zs-k7q4m9": ("class", "joker"),    # второй код (его придумала Verity)
}

# сколько монет дают
COIN_ZOMBIE = 1
COIN_ROOM = 10
COIN_BOSS_ROOM = {"c7": 40, "office": 60, "electro": 20, "warehouse": 120, "cab": 120}   # остальные комнаты: COIN_ROOM
COIN_CHAPTER = 100


def current():
    """Выбранный класс (если выбран неизвестный или не купленный, играем обыкновенным)."""
    key = prefs.get("klass")
    if key not in CLASSES or key not in prefs.get("owned_classes"):
        key = "normal"
    return CLASSES[key]


def current_key():
    key = prefs.get("klass")
    return key if key in CLASSES and key in prefs.get("owned_classes") else "normal"


def level(key):
    """Уровень класса: 1 сразу после покупки, до MAX_LEVEL. У чужого (не купленного) класса 1."""
    lv = prefs.get("class_levels").get(key, 1) if isinstance(prefs.get("class_levels"), dict) else 1
    return max(1, min(MAX_LEVEL, int(lv)))


def effects(key, lv=None):
    """Всё, что умеет класс на своём уровне: числа класса плюс все улучшения до этого уровня."""
    lv = level(key) if lv is None else lv
    fx = dict(CLASSES[key])
    for _, perk in PERKS[key][:max(0, lv - 1)]:
        fx.update(perk)
    return fx


def next_perk(key):
    """Что даст следующий уровень (текст) или None, если уже максимум."""
    lv = level(key)
    return PERKS[key][lv - 1][0] if lv < MAX_LEVEL else None


def upgrade_cost(key):
    lv = level(key)
    return UPGRADE_COST[lv - 1] if lv < MAX_LEVEL else None


def upgrade(key):
    """Улучшить класс. Возвращает "ok", "max" (уже максимум), "poor" (мало монет) или "locked" (класс не куплен)."""
    if not owns_class(key):
        return "locked"
    cost = upgrade_cost(key)
    if cost is None:
        return "max"
    if prefs.get("coins") < cost:
        return "poor"
    levels = dict(prefs.get("class_levels"))
    levels[key] = level(key) + 1
    prefs.data["coins"] -= cost
    prefs.set("class_levels", levels)   # заодно сохраняет и монеты
    return "ok"


def migrate():
    """Один раз после удешевления классов возвращает разницу тем, кто уже купил по старой цене. Сколько монет вернули."""
    if prefs.get("class_refund"):
        return 0
    back = sum(PRICE_OLD[k] - CLASSES[k]["price"] for k in prefs.get("owned_classes") if k in PRICE_OLD)
    prefs.data["coins"] = prefs.get("coins") + back
    prefs.set("class_refund", True)
    return back


def owns_skin(key):
    return key in prefs.get("owned_skins")


def owns_class(key):
    return key in prefs.get("owned_classes")


def add_coins(n):
    """Монеты копятся в памяти, а на диск пишутся позже (prefs.save()), чтобы не писать файл на каждого зомби."""
    prefs.data["coins"] = prefs.get("coins") + n


# русская раскладка -> те же клавиши на английской (чтобы код работал, даже если набрал не на той раскладке)
_RU_TO_EN = dict(zip("йцукенгшщзхъфывапролджэячсмитьбю", "qwertyuiop[]asdfghjkl;'zxcvbnm,."))


def clean_code(code):
    """Приводим набранный код к простому виду: маленькие буквы, английская раскладка, без пробелов и дефисов."""
    code = (code or "").strip().lower()
    code = "".join(_RU_TO_EN.get(ch, ch) for ch in code)
    return re.sub(r"[\s\-_]", "", code)


def redeem(code):
    """Промокод. Возвращает (статус, текст): "ok" — открыто, "owned" — уже было, "bad" — нет такого, "empty"."""
    code = clean_code(code)
    if not code:
        return "empty", ""
    found = {clean_code(k): v for k, v in PROMOS.items()}.get(code)
    if not found:
        return "bad", "Такого промокода нет"
    kind, key = found
    if kind == "class":
        owned = list(prefs.get("owned_classes"))
        name = CLASSES[key]["name"]
        if key in owned:
            return "owned", f"Класс {name} уже открыт"
        owned.append(key)
        prefs.set("owned_classes", owned)
        return "ok", f"Промокод принят! Открыт класс {name}"
    return "bad", "Такого промокода нет"


def buy(kind, key):
    """Покупка. kind — "skin" или "class". Возвращает "ok" (куплено), "owned" (уже было) или "poor" (мало монет)."""
    owned_key = "owned_skins" if kind == "skin" else "owned_classes"
    price = SKIN_PRICE[key] if kind == "skin" else CLASSES[key]["price"]
    owned = list(prefs.get(owned_key))
    if key in owned:
        return "owned"
    if prefs.get("coins") < price:
        return "poor"
    prefs.data["coins"] -= price
    owned.append(key)
    prefs.set(owned_key, owned)  # заодно сохраняет и монеты
    return "ok"
