"""Глава 4 «Парк аттракционов»: ночной парк в Пусане. Ворота, карусель, горки, дом страха и шатёр талисмана.

Всё как в rooms_train.py: build_xxx — мебель (на неё можно запрыгнуть), back_xxx — фон.
Фон рисуется каждый кадр: на небе вертится колесо обозрения, огоньки мигают.
"""
import math

import pygame

import rooms
from pixelfont import pixel_font
from rooms import box
from rooms_train import LEVER_ZONE
from settings import FLOOR, H, INK, W

PARK_KINDS = ("pgate", "pcarousel", "pcoaster", "phouse", "ptent")
KINDS_PARK = ("phorse", "pbench", "pcrate", "pcar", "pcoffin", "pstage", "pbarrel", "pbooth")

ROOMS_PARK = [
    {"id": "pgate", "name": "Вход в парк", "kind": "pgate"},
    {"id": "pcarousel", "name": "Карусель", "kind": "pcarousel"},
    {"id": "pcoaster", "name": "Горки", "kind": "pcoaster"},
    {"id": "phouse", "name": "Дом страха", "kind": "phouse"},
    {"id": "ptent", "name": "Шатёр", "kind": "ptent"},
]
ROOM_PARK_BY_ID = {r["id"]: r for r in ROOMS_PARK}
ORDER_PARK = [r["id"] for r in ROOMS_PARK]

BUTTON_ZONE = LEVER_ZONE   # большая кнопка аттракциона у выхода справа


# ---------------------------------------------------------------- общие куски
def night_sky(s, wheel=True, day=False):
    """Небо над парком, звёзды, луна и (если надо) далёкое колесо обозрения, которое медленно крутится."""
    top, bot = ((120, 175, 235), (255, 205, 150)) if day else ((14, 18, 46), (70, 40, 90))
    for y in range(0, FLOOR, 6):
        k = y / FLOOR
        pygame.draw.rect(s, tuple(int(top[i] + (bot[i] - top[i]) * k) for i in range(3)), (0, y, W, 6))
    t = pygame.time.get_ticks() / 1000
    if not day:
        for i in range(34):   # звёзды: мерцают
            x, y = (i * 211) % W, (i * 97) % 240
            if (int(t * 2) + i) % 5:
                pygame.draw.rect(s, (240, 240, 255), (x, y, 3, 3))
        pygame.draw.circle(s, (245, 240, 200), (90, 70), 30)
        pygame.draw.circle(s, (14, 18, 46), (102, 62), 28)   # лунный серп
    if wheel:
        ferris(s, 730, 250, 150, t, day)


def ferris(s, cx, cy, r, t, day=False):
    """Колесо обозрения: обод, спицы и кабинки, которые всегда висят прямо."""
    col = (70, 60, 100) if not day else (150, 140, 170)
    pygame.draw.line(s, col, (cx, cy), (cx - r // 2, FLOOR), 8)
    pygame.draw.line(s, col, (cx, cy), (cx + r // 2, FLOOR), 8)
    pygame.draw.circle(s, col, (cx, cy), r, 6)
    pygame.draw.circle(s, col, (cx, cy), r // 2, 3)
    cabs = [(245, 90, 100), (250, 200, 80), (110, 200, 140), (110, 160, 240)]
    for k in range(8):
        a = t * 0.25 + k * math.pi / 4
        x, y = cx + int(math.cos(a) * r), cy + int(math.sin(a) * r)
        pygame.draw.line(s, col, (cx, cy), (x, y), 3)
        pygame.draw.rect(s, INK, (x - 11, y - 2, 22, 20))
        pygame.draw.rect(s, cabs[k % 4], (x - 9, y, 18, 16))
        pygame.draw.rect(s, (255, 245, 190) if (k + int(t)) % 3 else (60, 60, 80), (x - 5, y + 4, 10, 6))
    pygame.draw.circle(s, INK, (cx, cy), 12)
    pygame.draw.circle(s, (250, 220, 90), (cx, cy), 7)


def fairy_lights(s, y, sag=22, step=34):
    """Гирлянда лампочек поперёк комнаты."""
    t = pygame.time.get_ticks() // 350
    pts = [(x, y + int(math.sin(x / W * math.pi) * sag)) for x in range(0, W + 1, 8)]
    pygame.draw.lines(s, INK, False, pts, 3)
    colors = [(250, 90, 100), (250, 220, 90), (110, 220, 150), (110, 170, 250)]
    for i, x in enumerate(range(10, W, step)):
        yy = y + int(math.sin(x / W * math.pi) * sag) + 6
        c = colors[(i + t) % 4]
        pygame.draw.circle(s, INK, (x, yy + 4), 7)
        pygame.draw.circle(s, c, (x, yy + 4), 5)


def paving(s, color, stripe):
    """Дорожка парка: плитка."""
    pygame.draw.rect(s, color, (0, FLOOR, W, H - FLOOR))
    for tx in range(0, W, 60):
        pygame.draw.rect(s, stripe, (tx, FLOOR + 4, 4, H - FLOOR))
    for ty in range(FLOOR + 30, H, 30):
        pygame.draw.rect(s, stripe, (0, ty, W, 3))
    pygame.draw.rect(s, INK, (0, FLOOR, W, 4))


def lamp_post(s, x, color=(255, 232, 150)):
    pygame.draw.rect(s, INK, (x - 4, FLOOR - 190, 8, 190))
    pygame.draw.circle(s, INK, (x, FLOOR - 196), 15)
    pygame.draw.circle(s, color, (x, FLOOR - 196), 11)


def exit_gate(s):
    """Выход вправо: светящаяся арка со стрелкой (следующий аттракцион)."""
    box(s, (W - 70, FLOOR - 150, 70, 150), (60, 70, 110))
    pygame.draw.rect(s, (30, 34, 54), (W - 56, FLOOR - 136, 44, 136))
    t = pygame.time.get_ticks() // 400
    pygame.draw.polygon(s, (250, 220, 90) if t % 2 else (200, 170, 60),
                        [(W - 52, FLOOR - 92), (W - 30, FLOOR - 92), (W - 30, FLOOR - 106), (W - 12, FLOOR - 78),
                         (W - 30, FLOOR - 50), (W - 30, FLOOR - 64), (W - 52, FLOOR - 64)])


def button_panel(s, label, color):
    """Большая кнопка аттракциона на стойке у выхода."""
    z = BUTTON_ZONE
    box(s, (z.x + 28, z.y + 50, 58, 70), (70, 76, 100))
    pygame.draw.circle(s, INK, (z.x + 57, z.y + 44), 24)
    pygame.draw.circle(s, color, (z.x + 57, z.y + 44), 19)
    pygame.draw.circle(s, (255, 255, 255), (z.x + 50, z.y + 37), 5)
    t = pixel_font(14).render(label, True, (255, 255, 255))
    s.blit(t, t.get_rect(center=(z.x + 57, z.y + 92)))


# ---------------------------------------------------------------- ВХОД В ПАРК
def build_pgate(variant=0):
    return [
        (pygame.Rect(90, 414, 120, 12), "pbench"), (pygame.Rect(330, 300, 150, 14), "pbooth"),
        (pygame.Rect(560, 410, 90, 14), "pbarrel"), (pygame.Rect(710, 340, 130, 12), "pbench"),
    ]


def back_pgate(s, variant=0):
    night_sky(s)
    # арка входа с неоновой вывеской
    for ax in (150, 810):
        box(s, (ax - 30, 120, 60, FLOOR - 120), (200, 90, 120))
    box(s, (140, 96, 680, 78), (60, 40, 110))
    t = pixel_font(36).render("ВЕСЁЛЫЙ ПАРК", True, (255, 235, 130) if (pygame.time.get_ticks() // 500) % 6 else (150, 130, 70))
    s.blit(t, t.get_rect(center=(480, 118)))
    fairy_lights(s, 200, 26)
    lamp_post(s, 60)
    lamp_post(s, 900)
    exit_gate(s)
    paving(s, (96, 90, 120), (80, 74, 104))


# ---------------------------------------------------------------- КАРУСЕЛЬ
def build_pcarousel(variant=0):
    return [
        (pygame.Rect(70, 406, 110, 14), "phorse"), (pygame.Rect(250, 356, 110, 14), "phorse"),
        (pygame.Rect(430, 406, 110, 14), "phorse"), (pygame.Rect(610, 340, 110, 14), "phorse"),
    ]


def back_pcarousel(s, variant=0):
    night_sky(s, wheel=False)
    t = pygame.time.get_ticks() / 1000
    # большой шатёр карусели
    pygame.draw.polygon(s, INK, [(100, 190), (480, 70), (860, 190)])
    pygame.draw.polygon(s, (230, 70, 90), [(112, 186), (480, 82), (848, 186)])
    for k in range(7):   # полосы на крыше
        x0 = 112 + k * 105
        pygame.draw.polygon(s, (250, 230, 200), [(x0, 186), (x0 + 52, 186), (480, 82)]) if k % 2 == 0 else None
    pygame.draw.rect(s, INK, (100, 186, 760, 14))
    pygame.draw.circle(s, (250, 220, 90), (480, 70), 9)
    pygame.draw.rect(s, (70, 50, 110), (100, 200, 760, FLOOR - 200))
    for px in range(130, 860, 150):   # золотые столбы
        pygame.draw.rect(s, INK, (px - 6, 200, 12, FLOOR - 200))
        pygame.draw.rect(s, (250, 215, 90), (px - 3, 200, 6, FLOOR - 200))
    for k in range(5):   # лошадки качаются вверх-вниз
        x = 200 + k * 140
        y = 300 + int(math.sin(t * 2 + k) * 20)
        pygame.draw.rect(s, INK, (x - 2, 200, 4, y - 200))
        pygame.draw.ellipse(s, INK, (x - 30, y - 6, 62, 40))
        pygame.draw.ellipse(s, (240, 235, 245) if k % 2 else (250, 190, 210), (x - 27, y - 3, 56, 34))
        pygame.draw.rect(s, (240, 235, 245) if k % 2 else (250, 190, 210), (x + 20, y - 18, 14, 18))
    fairy_lights(s, 60, 14, 40)
    lamp_post(s, 40)
    exit_gate(s)
    button_panel(s, "ПУСК", (250, 200, 70))
    paving(s, (104, 86, 120), (86, 70, 102))


# ---------------------------------------------------------------- ГОРКИ
def build_pcoaster(variant=0):
    return [
        (pygame.Rect(90, 410, 130, 14), "pcrate"), (pygame.Rect(300, 340, 130, 14), "pcar"),
        (pygame.Rect(520, 410, 110, 14), "pcrate"), (pygame.Rect(690, 336, 130, 12), "pcrate"),
    ]


def back_pcoaster(s, variant=0):
    night_sky(s, wheel=False)
    track = (200, 70, 80)
    # рельсы американских горок: подъём, спуск и волна
    pts = []
    for x in range(-20, W + 40, 12):
        y = 250 + int(math.sin(x / 90) * 70) - (x // 8 if x < 300 else 37)
        pts.append((x, y))
    pygame.draw.lines(s, INK, False, [(x, y + 12) for x, y in pts], 8)
    pygame.draw.lines(s, track, False, pts, 5)
    for x, y in pts[::4]:   # опоры
        pygame.draw.line(s, (80, 70, 110), (x, y + 6), (x, FLOOR), 4)
    t = pygame.time.get_ticks() / 1000
    i = int((t * 18) % len(pts))   # вагончик с гостями едет сам, по кругу
    x, y = pts[i]
    pygame.draw.rect(s, INK, (x - 16, y - 18, 34, 20))
    pygame.draw.rect(s, (90, 160, 240), (x - 13, y - 15, 28, 14))
    pygame.draw.circle(s, (250, 220, 90), (x - 3, y - 20), 5)
    box(s, (330, 92, 300, 44), (60, 40, 110))
    tt = pixel_font(30).render("ГОРКИ", True, (255, 235, 130))
    s.blit(tt, tt.get_rect(center=(480, 114)))
    fairy_lights(s, 130, 18, 36)
    lamp_post(s, 50)
    exit_gate(s)
    button_panel(s, "ВАГОН", (240, 90, 80))
    paving(s, (84, 88, 120), (68, 72, 104))


# ---------------------------------------------------------------- ДОМ СТРАХА
def build_phouse(variant=0):
    return [
        (pygame.Rect(80, 400, 90, 14), "pcoffin"), (pygame.Rect(260, 340, 100, 14), "pcoffin"),
        (pygame.Rect(470, 406, 100, 14), "pbarrel"), (pygame.Rect(640, 330, 110, 14), "pcoffin"),
    ]


def back_phouse(s, variant=0):
    s.fill((40, 30, 62))
    pygame.draw.rect(s, (54, 40, 82), (0, 330, W, FLOOR - 330))
    pygame.draw.rect(s, INK, (0, 330, W, 4))
    t = pygame.time.get_ticks()
    # разинутая пасть дома страха на стене
    pygame.draw.ellipse(s, INK, (300, 140, 360, 200))
    pygame.draw.ellipse(s, (120, 30, 70), (312, 152, 336, 176))
    for k in range(9):
        x = 330 + k * 36
        pygame.draw.polygon(s, (240, 235, 225), [(x, 156), (x + 30, 156), (x + 15, 196)])
        pygame.draw.polygon(s, (240, 235, 225), [(x, 324), (x + 30, 324), (x + 15, 288)])
    pygame.draw.circle(s, INK, (440, 236), 20)
    pygame.draw.circle(s, (255, 240, 120) if (t // 400) % 4 else (90, 80, 40), (440, 236), 14)   # глаза мигают
    pygame.draw.circle(s, INK, (520, 236), 20)
    pygame.draw.circle(s, (255, 240, 120) if (t // 400 + 2) % 4 else (90, 80, 40), (520, 236), 14)
    box(s, (320, 92, 320, 40), (30, 20, 50))
    tt = pixel_font(28).render("ДОМ СТРАХА", True, (240, 90, 90))
    s.blit(tt, tt.get_rect(center=(480, 112)))
    for cx, cy in ((0, 0), (W, 0)):   # паутина в углах
        for k in range(1, 5):
            pygame.draw.circle(s, (130, 120, 160), (cx, cy), k * 40, 2)
        for a in range(0, 90, 18):
            pygame.draw.line(s, (130, 120, 160), (cx, cy),
                             (cx + (1 if cx == 0 else -1) * int(math.cos(math.radians(a)) * 160), int(math.sin(math.radians(a)) * 160)), 2)
    for gx in (170, 740):   # надгробия
        pygame.draw.rect(s, INK, (gx - 4, FLOOR - 74, 58, 74))
        pygame.draw.rect(s, (130, 130, 150), (gx, FLOOR - 70, 50, 70))
        pygame.draw.rect(s, INK, (gx + 20, FLOOR - 56, 10, 28))
        pygame.draw.rect(s, INK, (gx + 12, FLOOR - 48, 26, 8))
    exit_gate(s)
    button_panel(s, "СВЕТ", (240, 240, 120))
    paving(s, (50, 40, 70), (40, 32, 58))


# ---------------------------------------------------------------- ШАТЁР ТАЛИСМАНА (босс)
def build_ptent(variant=0):
    return [
        (pygame.Rect(70, 400, 150, 14), "pstage"), (pygame.Rect(340, 340, 120, 12), "pbarrel"),
        (pygame.Rect(600, 400, 150, 14), "pstage"), (pygame.Rect(770, 330, 120, 12), "pbarrel"),
    ]


def back_ptent(s, variant=0):
    s.fill((110, 40, 70))
    for k in range(0, W, 80):   # полосатый купол
        pygame.draw.rect(s, (235, 215, 170), (k, 0, 40, FLOOR))
    pygame.draw.polygon(s, (60, 20, 50), [(0, 0), (W, 0), (W - 120, 120), (120, 120)])
    pygame.draw.rect(s, INK, (0, 118, W, 5))
    fairy_lights(s, 128, 16, 32)
    box(s, (330, 160, 300, 90), (50, 30, 90))   # афиша с талисманом
    pygame.draw.circle(s, (150, 100, 60), (480, 206), 26)
    pygame.draw.circle(s, (215, 170, 120), (492, 212), 12)
    pygame.draw.polygon(s, (245, 110, 170), [(465, 190), (495, 190), (480, 160)])
    t = pixel_font(20).render("ДОБРО ПОЖАЛОВАТЬ!", True, (255, 235, 130))
    s.blit(t, t.get_rect(center=(480, 262)))
    for bx, by, c in ((120, 230, (240, 80, 90)), (180, 260, (250, 215, 80)), (780, 240, (100, 160, 240)),
                      (840, 270, (110, 210, 150))):   # шарики
        pygame.draw.line(s, INK, (bx, by + 20), (bx, FLOOR), 2)
        pygame.draw.circle(s, INK, (bx, by), 22)
        pygame.draw.circle(s, c, (bx, by), 19)
        pygame.draw.circle(s, (255, 255, 255), (bx - 6, by - 7), 5)
    paving(s, (140, 56, 76), (120, 44, 64))


# ---------------------------------------------------------------- РАССВЕТ В ПАРКЕ (для катсцен)
def back_pend(s, variant=0):
    night_sky(s, wheel=False, day=True)
    ferris(s, 480, 250, 190, 0.0, day=True)   # колесо остановилось
    for lx in (60, 900):
        lamp_post(s, lx, (250, 240, 200))
    paving(s, (150, 140, 160), (126, 116, 140))


def build_pend(variant=0):
    return []


# ---------------------------------------------------------------- мебель
def draw_furniture_park(s, r, kind):
    if kind == "phorse":   # лошадка с карусели: на ней можно стоять
        box(s, r, (250, 190, 210))
        pygame.draw.rect(s, INK, (r.centerx - 2, r.bottom, 4, FLOOR - r.bottom))
        pygame.draw.rect(s, (250, 215, 90), (r.centerx - 1, r.bottom, 2, FLOOR - r.bottom))
        box(s, (r.right - 26, r.y - 28, 24, 30), (250, 190, 210), border=2)
        box(s, (r.right - 8, r.y - 22, 14, 12), (250, 190, 210), border=2)
        pygame.draw.rect(s, (110, 70, 140), (r.x + 6, r.y - 12, 34, 10))
    elif kind == "pbench":
        box(s, r, (150, 100, 60))
        box(s, (r.x, r.y - 24, r.w, 10), (130, 84, 50), border=2)
        for lx in (r.x + 10, r.right - 16):
            box(s, (lx, r.bottom, 6, FLOOR - r.bottom), (60, 60, 80), border=2)
    elif kind == "pcrate":
        box(s, r, (210, 130, 70))
        for lx in (r.x + 12, r.right - 20):
            box(s, (lx, r.bottom, 8, FLOOR - r.bottom), (160, 96, 50), border=2)
        pygame.draw.line(s, INK, (r.x + 4, r.y + 4), (r.right - 4, r.bottom - 4), 3)
    elif kind == "pcar":   # вагончик горок: можно запрыгнуть
        box(s, r, (90, 160, 240))
        pygame.draw.rect(s, (250, 220, 90), (r.x + 6, r.y + 3, r.w - 12, 3))
        for wx in (r.x + 24, r.right - 24):
            pygame.draw.circle(s, INK, (wx, r.bottom + 8), 11)
            pygame.draw.circle(s, (200, 205, 220), (wx, r.bottom + 8), 6)
        pygame.draw.rect(s, INK, (r.centerx - 2, r.bottom + 8, 4, FLOOR - r.bottom - 8))
    elif kind == "pcoffin":   # гроб стоит на подставке
        box(s, r, (90, 60, 50))
        pygame.draw.rect(s, (60, 40, 35), (r.x + 8, r.y + 3, r.w - 16, 4))
        for lx in (r.x + 10, r.right - 16):
            box(s, (lx, r.bottom, 6, FLOOR - r.bottom), (70, 50, 70), border=2)
        pygame.draw.rect(s, (240, 235, 225), (r.centerx - 3, r.y - 24, 6, 24))   # крест над гробом
        pygame.draw.rect(s, (240, 235, 225), (r.centerx - 10, r.y - 18, 20, 6))
    elif kind == "pstage":
        box(s, r, (240, 210, 90))
        for k in range(r.x + 8, r.right - 8, 24):
            pygame.draw.rect(s, (220, 60, 70), (k, r.y + 3, 12, r.h - 6))
        box(s, (r.x + 8, r.bottom, r.w - 16, FLOOR - r.bottom), (170, 70, 90), border=2)
    elif kind == "pbarrel":
        box(s, r, (170, 120, 70))
        pygame.draw.rect(s, INK, (r.x + 10, r.y + 3, 4, r.h - 6))
        for lx in (r.x + 8, r.right - 14):
            box(s, (lx, r.bottom, 6, FLOOR - r.bottom), (120, 85, 55), border=2)
    elif kind == "pbooth":   # билетная касса: на крыше можно стоять
        box(s, r, (230, 80, 100))
        pygame.draw.rect(s, (250, 235, 200), (r.x + 12, r.y + 3, 18, r.h - 6))
        box(s, (r.x + 10, r.bottom, r.w - 20, FLOOR - r.bottom), (250, 230, 190), border=2)
        pygame.draw.rect(s, INK, (r.x + 30, r.bottom + 22, r.w - 60, 36))
        pygame.draw.rect(s, (255, 240, 170), (r.x + 34, r.bottom + 26, r.w - 68, 28))
        t = pixel_font(14).render("БИЛЕТЫ", True, (60, 40, 110))
        s.blit(t, t.get_rect(center=(r.centerx, r.bottom + 14)))


THEMES_PARK = {
    "pgate": {"build": build_pgate, "back": back_pgate, "beams": [],
              "loot": {"pie": 24, "ball": 8, "jumprope": 6, "toygun": 8, "slipper": 6, "slingshot": 6}, "tint": 0},
    "pcarousel": {"build": build_pcarousel, "back": back_pcarousel, "beams": [],
                  "loot": {"pie": 28, "piebomb": 10, "ball": 8, "toygun": 8, "pony": 6, "cart": 6}, "tint": 0},
    "pcoaster": {"build": build_pcoaster, "back": back_pcoaster, "beams": [],
                 "loot": {"pie": 26, "cart": 10, "piebomb": 10, "foamgun": 8, "watergun": 8, "club": 6}, "tint": 0},
    "phouse": {"build": build_phouse, "back": back_phouse, "beams": [],
               "loot": {"pie": 30, "extinguisher": 8, "bell": 6, "piebomb": 10, "club": 8, "foamgun": 6}, "tint": 0},
    "ptent": {"build": build_ptent, "back": back_ptent, "beams": [],
              "loot": {"pie": 30, "piebomb": 12, "cart": 8, "watergun": 8, "foamgun": 8, "ball": 6}, "tint": 0},
    "pend": {"build": build_pend, "back": back_pend, "beams": [], "loot": {"pie": 1}, "tint": 0},
}
rooms.THEMES.update(THEMES_PARK)
