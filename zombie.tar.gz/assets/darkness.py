"""Тьма с кругом света: тоннели в поезде (глава 3). Вся комната накрывается темнотой, вырезаются круги света."""
import pygame

from settings import H, W

_masks = {}
_dark = None


def light_mask(r):
    """Круг света: в центре дыра в темноте, к краю плавно темнеет (кольцами, как пиксельный градиент)."""
    r = max(30, int(r // 10 * 10))
    if r not in _masks:
        m = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        m.fill((255, 255, 255, 255))  # за пределами круга темнота остаётся как есть
        steps = 22
        for i in range(steps, 0, -1):
            k = i / steps
            alpha = int(255 * min(1.0, (k ** 1.6)))
            pygame.draw.circle(m, (255, 255, 255, alpha), (r, r), int(r * k))
        _masks[r] = m
    return _masks[r]


def draw_darkness(s, alpha, lights):
    """Накрываем комнату тьмой и вырезаем кружки света. lights — список (x, y, радиус)."""
    global _dark
    if _dark is None:
        _dark = pygame.Surface((W, H), pygame.SRCALPHA)
    _dark.fill((2, 3, 14, alpha))
    for x, y, r in lights:
        m = light_mask(r)
        _dark.blit(m, (int(x) - m.get_width() // 2, int(y) - m.get_height() // 2), special_flags=pygame.BLEND_RGBA_MIN)
    s.blit(_dark, (0, 0))
