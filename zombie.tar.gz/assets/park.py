"""Глава 4 «Парк аттракционов»: ночной парк в Пусане. Идёшь по аттракционам к шатру зомби-талисмана.

Park — это тот же Train (волны врагов, тоннели, кнопка у выхода), только свои комнаты и своя кнопка:
  pgate      — ворота: первые высокие зомби
  pcarousel  — карусель: кнопка «Пуск» закручивает всех врагов (они замирают), приходят толстяки
  pcoaster   — горки: кнопка «Вагон» пускает вагончик, он сбивает всех на пути
  phouse     — дом страха: свет гаснет сам, кнопка «Свет» включает его на долго; здесь первый гигант
  ptent      — шатёр: зомби-талисман (босс) и мелкие на подмоге
Хочешь свой аттракцион? Добавь запись в PARK (волны, кнопка), комнату в rooms_park.py и сцену в cutscenes.py.
  waves  — список волн: сколько врагов каждого вида (zombie, runner, tall, fat, imp, giant), "hp" — прибавка здоровья
  button — что делает кнопка: "spin" (враги замирают), "car" (вагончик), "light" (свет и ослепление)
"""
import pygame

from rooms_park import BUTTON_ZONE
from settings import FLOOR, INK, W
from train import Train

CAR_SPEED = 1000        # скорость вагончика горок
CAR_DMG = 8             # сколько здоровья снимает каждому врагу
CAR_BOSS_DMG = 6
SPIN_STUN = 3.0         # на сколько секунд замирают враги от карусели
LIGHT_KEEP = 12.0       # на сколько секунд свет в доме страха включается насовсем

PARK = {
    "pgate": {"waves": [{"zombie": 4}, {"zombie": 4, "tall": 1}, {"zombie": 3, "tall": 2}],
              "tunnel": None, "lever": False, "objective": "Пройди через ворота парка",
              "intro": "Вход в парк: ворота распахнуты"},
    "pcarousel": {"waves": [{"zombie": 3, "fat": 1}, {"zombie": 4, "tall": 1, "fat": 1},
                            {"zombie": 3, "tall": 1, "fat": 1, "runner": 1}],
                  "tunnel": None, "lever": True, "button": "spin",
                  "btn": ("Карусель", "E — запустить карусель", "КАРУСЕЛЬ"),
                  "objective": "Пробейся через карусель", "intro": "Карусель крутится сама"},
    "pcoaster": {"waves": [{"zombie": 4, "runner": 2}, {"zombie": 3, "tall": 2, "fat": 1},
                           {"tall": 2, "runner": 2, "fat": 1}],
                 "tunnel": None, "lever": True, "button": "car",
                 "btn": ("Вагон", "E — пустить вагончик", "ВАГОНЧИК"),
                 "objective": "Пробейся мимо американских горок", "intro": "Американские горки: рельсы дрожат"},
    "phouse": {"waves": [{"imp": 5, "zombie": 2}, {"imp": 4, "tall": 2, "zombie": 1}, {"giant": 1, "imp": 2}],
               "tunnel": (14, 5), "lever": True, "button": "light",
               "btn": ("Свет", "E — включить свет", "СВЕТ"),
               "dark_msg": "Свет погас! Дом страха", "dark_hint": "Свет мигает",
               "objective": "Пройди дом страха", "intro": "Дом страха: тут кто-то огромный"},
    "ptent": {"waves": [{"zombie": 2, "tall": 1, "fat": 1}], "tunnel": None, "lever": False, "boss": True,
              "objective": "Останови колесо: победи талисмана", "intro": "Шатёр зомби-талисмана"},
}


class Park(Train):
    """Правила одного аттракциона."""
    CONFIG = PARK

    def __init__(self, game, rid):
        super().__init__(game, rid)
        self.car = None        # вагончик горок: {"x", "hit"}

    def spawn(self, x, kind, hp_bonus=0):
        super().spawn(x, kind, hp_bonus)
        if kind == "giant":
            self.g.msg = ["Гигант! У него на спине мелкий", 2.5]

    # ------------------------------------------------ кнопка аттракциона
    def pull_brake(self):
        """Кнопка E у стойки: у каждого аттракциона свой эффект (один раз на комнату)."""
        if not self.near_lever():
            return False
        g, kind = self.g, self.cfg.get("button")
        self.brake -= 1
        g.add_shake(6, 0.5)
        if kind == "spin":   # карусель закрутила всех: враги замирают и разлетаются в стороны
            for z in g.zombies:
                z.stun(SPIN_STUN)
                z.x = max(0.0, min(g.ww - z.w, z.x + (110 if z.x + z.w / 2 > W / 2 else -110)))
            if g.boss is not None:
                g.boss.stun_t = max(g.boss.stun_t, 1.5)
            g.fx.append({"type": "ring", "x": W / 2, "y": FLOOR - 60, "t": 0.0})
            g.msg = ["Карусель запущена! Все закружились", 2.0]
        elif kind == "car":   # вагончик пролетает слева направо
            self.car = {"x": -170.0, "hit": set()}
            g.msg = ["Вагончик пошёл!", 2.0]
        elif kind == "light":   # свет включён: темноты долго не будет, враги ослеплены
            self.dark_left = 0.0
            if self.tunnel_t is not None:
                self.tunnel_t = self.cfg["tunnel"][0] + LIGHT_KEEP
            for z in g.zombies:
                z.stun(2.5)
            g.msg = ["Свет включён! Враги ослеплены", 2.0]
        g.puff(W - 100, FLOOR - 60, 14, (250, 230, 150))
        return True

    # ------------------------------------------------ каждый кадр
    def update(self, dt, keys):
        super().update(dt, keys)
        car, g = self.car, self.g
        if car is None:
            return
        car["x"] += CAR_SPEED * dt
        rect = pygame.Rect(int(car["x"]), FLOOR - 74, 160, 74)
        for z in g.zombies:
            if id(z) not in car["hit"] and rect.colliderect(z.rect):
                car["hit"].add(id(z))
                z.hp -= CAR_DMG
                z.flash = 0.2
                z.x = min(g.ww - z.w, z.x + 70)
                g.spark(z.x + z.w / 2, z.y + z.h / 2, 1)
        b = g.boss
        if b is not None and b.state not in ("dying", "hide") and id(b) not in car["hit"] and rect.colliderect(b.rect):
            car["hit"].add(id(b))
            b.hp -= CAR_BOSS_DMG
            b.flash = 0.2
            b.stun_t = max(b.stun_t, 1.0)
        if car["x"] > W + 40:
            self.car = None

    # ------------------------------------------------ рисование
    def draw_front(self, s):
        car = self.car
        if car is None:
            return
        x, y = int(car["x"]), FLOOR - 74
        for k in range(4):   # полосы скорости
            pygame.draw.rect(s, (255, 255, 255), (x - 120 - k * 30, y + 14 + k * 14, 90, 4))
        pygame.draw.rect(s, INK, (x, y + 8, 160, 54))
        pygame.draw.rect(s, (230, 70, 80), (x + 4, y + 12, 152, 46))
        pygame.draw.rect(s, (250, 220, 90), (x + 4, y + 40, 152, 6))
        pygame.draw.polygon(s, INK, [(x + 160, y + 8), (x + 184, y + 40), (x + 160, y + 62)])
        pygame.draw.polygon(s, (230, 70, 80), [(x + 156, y + 14), (x + 176, y + 40), (x + 156, y + 56)])
        for k in range(3):   # визжащие пассажиры с поднятыми руками
            hx = x + 24 + k * 44
            pygame.draw.circle(s, INK, (hx, y + 2), 13)
            pygame.draw.circle(s, (250, 215, 180), (hx, y + 2), 10)
            pygame.draw.rect(s, INK, (hx - 3, y + 4, 6, 6))
            pygame.draw.line(s, INK, (hx - 12, y + 18), (hx - 18, y - 14), 4)
            pygame.draw.line(s, INK, (hx + 12, y + 18), (hx + 18, y - 14), 4)
        for wx in (x + 30, x + 130):
            pygame.draw.circle(s, INK, (wx, y + 64), 13)
            pygame.draw.circle(s, (200, 205, 220), (wx, y + 64), 7)

    def near_button(self):
        return self.brake > 0 and self.g.player.rect.colliderect(BUTTON_ZONE)
