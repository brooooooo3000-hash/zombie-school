"""Бесконечный режим: большая арена (3 экрана в ширину, камера идёт за героем) и волны врагов без конца.

Каждая волна больше и злее предыдущей, на каждой пятой — босс. Между волнами короткий отдых и награда.
Правила меняют модификаторы (modifiers.py), которые игрок выбирает перед стартом.
"""
import random

import pygame

from rooms import THEMES
from settings import FLOOR, H, W

TILES = 3                      # сколько экранов в ширину у арены
ARENA_W = W * TILES
THEME_POOL = ["class", "canteen", "gym", "toilet"]   # во дворе нет мебели, а на арене нужны места для прыжков
REST_TIME = 4.0                # отдых между волнами
BOSS_EVERY = 5                 # каждая такая волна — с боссом
WAVE_COINS = 5                 # монет за волну: 5 + 2 * номер
MAX_ENEMIES = 40               # за одну волну больше врагов не будет
SPAWN_EVERY = 0.7              # как часто выходит следующий враг
LOOT_CHANCE = 0.5              # шанс, что из убитого врага что-то выпадет
# что выпадает чаще всего: пирожки, линейки, бомбы и все пистолеты
LOOT = {"pie": 30, "ruler": 22, "piebomb": 16, "watergun": 10, "foamgun": 10, "slingshot": 10, "toygun": 10,
        "chalk": 3, "textbook": 3, "pointer": 3, "mop": 2, "club": 2, "chair": 2, "extinguisher": 2, "bell": 1}
WAVE_LOOT = 4                  # сколько вещей падает после каждой волны


def random_loot(mods):
    """Что выпадет: с «Вампиром» нет пирожков, с «Только кулаками» нет оружия."""
    table = {k: v for k, v in LOOT.items()
             if not (k == "pie" and mods.has("vampire")) and not (k != "pie" and mods.has("fists"))}
    return random.choices(list(table), list(table.values()))[0] if table else None


def build_arena(themes=None):
    """Склеивает три комнаты в одну длинную. Возвращает (мебель, картинка фона шириной с арену)."""
    themes = themes or random.sample(THEME_POOL, TILES)
    furniture = []
    bg = pygame.Surface((ARENA_W, H))
    for i, name in enumerate(themes):
        th = THEMES[name]
        tile = pygame.Surface((W, H))
        th["back"](tile, 0)
        bg.blit(tile, (i * W, 0))
        for rect, kind in th["build"](0):
            furniture.append((rect.move(i * W, 0), kind))
    return furniture, bg


def wave_size(wave, double=False):
    n = min(MAX_ENEMIES, 5 + 2 * wave)
    return min(MAX_ENEMIES * 2, n * 2) if double else n


def wave_kinds(wave):
    """Какие враги бывают в этой волне и как часто."""
    pool = {"zombie": 10}
    if wave >= 2:
        pool["worm"] = 4
    if wave >= 3:
        pool["chicken"] = 3
    if wave >= 4:
        pool["lamb"] = 3
    if wave >= 5:
        pool["cow"] = 2 + wave // 5
    return pool


class Endless:
    """Волны: сколько врагов осталось выпустить, отдых, рекорд."""

    def __init__(self, best=0):
        self.wave = 0
        self.queue = []         # кто ещё не вышел
        self.spawn_t = 0.0
        self.rest_t = 2.0       # пауза перед первой волной
        self.fighting = False
        self.kills = 0
        self.best = best
        self.new_record = False

    def alive_cap(self, wave, mods):
        cap = min(18, 7 + wave)
        return int(cap * 1.5) if mods is not None and mods.has("double") else cap

    def start_wave(self, g):
        self.wave += 1
        w = self.wave
        mods = g.mods
        kinds, weights = zip(*wave_kinds(w).items())
        n = wave_size(w, mods.has("double"))
        self.queue = [random.choices(kinds, weights)[0] for _ in range(n)]
        self.fighting, self.spawn_t = True, 0.0
        if w > self.best:
            self.best, self.new_record = w, True
        if w % BOSS_EVERY == 0:
            g.spawn_endless_boss(w // BOSS_EVERY)
            g.msg = [f"БОСС! Волна {w}", 3.0]
        else:
            g.msg = [f"Волна {w}", 2.0]

    def end_wave(self, g):
        self.fighting = False
        self.rest_t = REST_TIME
        w = self.wave
        g.earn(WAVE_COINS + 2 * w)
        p = g.player
        for _ in range(WAVE_LOOT):
            kind = random_loot(g.mods)
            if kind:
                g.add_loot(kind, random.randint(120, g.ww - 120), FLOOR)
        del g.pickups[:max(0, len(g.pickups) - 30)]   # старые вещи пропадают: на арене не больше 30
        g.msg = [f"Волна {w} пройдена!", 2.5]
        g.sparkle(p.x + p.w / 2, p.y + 10)

    def update(self, g, dt):
        if not self.fighting:
            self.rest_t -= dt
            if self.rest_t <= 0:
                self.start_wave(g)
            return
        self.spawn_t -= dt
        if self.queue and self.spawn_t <= 0 and len(g.zombies) < self.alive_cap(self.wave, g.mods):
            self.spawn_t = SPAWN_EVERY
            g.spawn_endless_enemy(self.queue.pop(), self.wave)
        if not self.queue and not g.zombies and g.boss is None:
            self.end_wave(g)

    @property
    def left(self):
        """Сколько врагов осталось выпустить."""
        return len(self.queue)


def spawn_x(g):
    """Где выходит новый враг: за краем экрана, по ту сторону, где есть место."""
    p = g.player
    side = random.choice((-1, 1))
    dist = random.uniform(540, 760)
    x = p.x + side * dist
    if not 20 <= x <= g.ww - 90:
        x = p.x - side * dist
    return max(20.0, min(g.ww - 90.0, x))


def speed_scale(wave):
    return min(1.5, 1 + 0.025 * wave)


def extra_hp(wave):
    return wave // 6

