"""Главное меню: играть, классы, скины, настройки. За монеты покупаются скины и классы.

Порядок: Играть → выбор главы → выбор сложности (Обычный / Хардкор) → игра. Ещё есть Скины и Настройки.
Меню — это экран игры (состояние "menu"). Управление: мышь/палец, либо стрелки + Enter, Esc — назад.
Что выбрано, запоминает prefs.py.
"""
import pygame

import classes
import i18n
import prefs
import touch as T
from classes import CLASS_KEYS, CLASSES, SKIN_PRICE
from pixelfont import pixel_font
from settings import H, INK, W
from sprites import PLAYER_FRAMES, SKINS, build

BG, GRID = (26, 34, 60), (36, 46, 78)
GOLD, WHITE, GREY = (255, 225, 120), (255, 255, 255), (125, 133, 158)
BTN, BTN_SEL, BTN_OFF = (44, 58, 100), (78, 100, 165), (34, 40, 62)

MODES = [
    ("normal", "Обычный", "Умер — комната начинается заново"),
    ("hardcore", "Хардкор", "Умер — вся игра сначала"),
]
SETTINGS = [  # (ключ в prefs, название, [(значение, подпись), ...])
    ("lang", "Язык", [("ru", "Русский"), ("en", "English"), ("ko", "한국어")]),
    ("shake", "Тряска экрана", [(True, "Вкл"), (False, "Выкл")]),
    ("light", "Свет и пылинки", [(True, "Вкл"), (False, "Выкл")]),
    ("buttons", "Кнопки на экране", [("auto", "Авто"), ("on", "Всегда"), ("off", "Нет")]),
    ("easy", "Лёгкие боссы", [("auto", "Авто"), ("on", "Да"), ("off", "Нет")]),
    ("opacity", "Прозрачность кнопок", [(0, "Сильная"), (1, "Средняя"), (2, "Слабая")]),
    ("fps", "Счётчик FPS", [(False, "Выкл"), (True, "Вкл")]),
]
OPACITY = {0: 55, 1: 85, 2: 140}   # прозрачность кнопок на экране (alpha)
SKIN_KEYS = list(SKINS)


def paste_text():
    """Текст из буфера обмена (то, что скопировал). Если не вышло, пусто."""
    try:
        pygame.scrap.init()
        raw = pygame.scrap.get_text() if hasattr(pygame.scrap, "get_text") else pygame.scrap.get(pygame.SCRAP_TEXT)
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", "ignore")
        return "".join(ch for ch in (raw or "").replace("\x00", "") if ch.isprintable())
    except Exception:
        return ""


def apply_prefs():
    """Применяет настройки, которые живут не в Game: язык, экранные кнопки и их прозрачность."""
    i18n.set_lang(prefs.get("lang"))
    T.ALPHA_IDLE = OPACITY[prefs.get("opacity")]
    T.ALPHA_HELD = min(255, T.ALPHA_IDLE + 105)
    mode = prefs.get("buttons")
    if mode == "on":
        T.touch.enabled = True
    elif mode == "off":
        T.touch.enabled = False
        T.touch.reset()


class Menu:
    def __init__(self, game):
        self.game = game
        self.screen = "main"      # main / skins / settings
        self.sel = 0
        self.in_progress = False  # можно ли «Продолжить»
        self.msg = None           # [текст, секунд]
        self.previews = {}
        self.chapter_pick = 1     # какую главу выбрал игрок
        self.typing = False       # вводим промокод
        self.input = ""

    def open(self, in_progress):
        self.screen, self.sel, self.in_progress, self.msg = "main", 0, in_progress, None

    # ---------- раскладка ----------
    def main_items(self):
        items = []
        if self.in_progress:
            items.append(("continue", "button", "Продолжить"))
        items.append(("play", "button", "Новая игра" if self.in_progress else "Играть"))
        items += [("classes", "button", "Классы"), ("skins", "button", "Скины"), ("settings", "button", "Настройки")]
        return items

    def main_rects(self):
        out, y = [], 150
        for iid, kind, label in self.main_items():
            out.append((iid, kind, label, [pygame.Rect(260, y, 440, 52)]))
            y += 66
        return out

    def cards(self):
        """Карточки выбора на экранах «глава» и «сложность»: (id, заголовок, подпись, открыта)."""
        if self.screen == "chapter":
            done = prefs.get("ch1_done")  # глава 2 открывается, когда пройдена глава 1
            return [("ch1", "Глава 1", "Зомби-школа", True),
                    ("ch2", "Глава 2", "Мегамаркет" if done else "Сначала пройди главу 1", done)]
        return [(m, name, desc, True) for m, name, desc in MODES]

    def card_rects(self):
        return [pygame.Rect(100, 140, 360, 250), pygame.Rect(500, 140, 360, 250)]

    def skin_rects(self):
        return [pygame.Rect(50 + (i % 4) * 220, 112 + (i // 4) * 172, 200, 160) for i in range(len(SKIN_KEYS))]

    def class_rects(self):
        return [pygame.Rect(40 + i * 300, 118, 280, 320) for i in range(len(CLASS_KEYS))]

    BACK = pygame.Rect(360, 468, 240, 46)
    LANG_BTN = pygame.Rect(16, 14, 190, 42)   # кнопка языка: слева вверху на всех экранах меню
    PROMO = pygame.Rect(650, 468, 260, 46)   # кнопка «Промокод» на экране классов

    def setting_rects(self):
        return [pygame.Rect(130, 100 + i * 48, 700, 42) for i in range(len(SETTINGS))]

    def count(self):
        if self.screen == "main":
            return len(self.main_items())
        if self.screen == "skins":
            return len(SKIN_KEYS) + 1
        if self.screen in ("chapter", "diff"):
            return 3
        if self.screen == "classes":
            return len(CLASS_KEYS) + 2
        return len(SETTINGS) + 1

    # ---------- действия ----------
    def pick_mode(self, mode):
        prefs.set("mode", mode)

    def pick_skin(self, i):
        key = SKIN_KEYS[i]
        if not classes.owns_skin(key):  # не куплен: покупаем, если хватает монет
            if classes.buy("skin", key) == "poor":
                self.msg = [f"Не хватает монет: нужно {SKIN_PRICE[key]}", 2.5]
                return
            self.msg = [f"Куплено: {SKINS[key][0]}!", 2.0]
        prefs.set("skin", key)
        if self.game.sprites is not None:
            self.game.sprites.set_skin(key)

    def pick_class(self, i):
        key = CLASS_KEYS[i]
        c = CLASSES[key]
        if not classes.owns_class(key):
            if classes.buy("class", key) == "poor":
                self.msg = [f"Не хватает монет: нужно {c['price']}", 2.5]
                return
            self.msg = [f"Куплено: {c['name']}!", 2.0]
        else:
            self.msg = [f"Выбран класс: {c['name']}", 1.5]
        prefs.set("klass", key)
        if self.in_progress:
            self.msg = [f"Класс {c['name']} будет в новой игре", 3.0]

    def ask_promo(self):
        """Просим ввести промокод: в браузере (телефон) — окошком, на компьютере — набираем прямо в игре."""
        import sys
        if sys.platform == "emscripten":
            try:
                import platform
                answer = platform.window.prompt("Введи промокод:", "")
                self.apply_promo(str(answer) if answer is not None else "")
                return
            except Exception:
                pass
        self.typing, self.input = True, ""

    def apply_promo(self, code):
        status, text = classes.redeem(code)
        if text:
            self.msg = [text, 3.5]

    def cycle_setting(self, i, step=1):
        key, _, options = SETTINGS[i]
        values = [v for v, _ in options]
        cur = prefs.get(key)
        j = (values.index(cur) + step) % len(values) if cur in values else 0
        prefs.set(key, values[j])
        apply_prefs()

    def activate(self, iid):
        g = self.game
        if iid == "continue":
            g.menu_continue()
        elif iid == "play":
            self.screen, self.sel = "chapter", 0
        elif iid == "classes":
            cur = classes.current_key()
            self.screen, self.sel = "classes", CLASS_KEYS.index(cur)
        elif iid == "skins":
            self.screen, self.sel = "skins", SKIN_KEYS.index(prefs.get("skin")) if prefs.get("skin") in SKIN_KEYS else 0
        elif iid == "settings":
            self.screen, self.sel = "settings", 0

    def pick_card(self, i):
        """Выбрали карточку на экране главы или сложности."""
        if self.screen == "chapter":
            if self.cards()[i][3]:
                self.chapter_pick = i + 1
                modes = [m for m, _, _ in MODES]
                cur = prefs.get("mode")
                self.screen, self.sel = "diff", modes.index(cur) if cur in modes else 0
            else:
                self.msg = ["Глава 2 откроется, когда ты пройдёшь главу 1", 3.0]
        else:  # сложность выбрана — начинаем игру
            self.pick_mode(MODES[i][0])
            self.game.new_game(self.chapter_pick)

    def back(self):
        if self.screen == "diff":
            self.screen, self.sel = "chapter", 0
        elif self.screen != "main":
            self.screen, self.sel = "main", 0
        elif self.in_progress:
            self.game.menu_continue()

    # ---------- ввод ----------
    def cycle_lang(self):
        """Следующий язык: русский -> English -> 한국어."""
        prefs.set("lang", i18n.next_lang(prefs.get("lang")))
        apply_prefs()

    def click(self, pos):
        if self.typing:  # клик в любом месте закрывает ввод промокода
            self.typing = False
            return
        if self.LANG_BTN.collidepoint(pos):  # язык можно сменить на любом экране меню
            self.cycle_lang()
            return
        if self.screen == "main":
            for n, (iid, _, _, rects) in enumerate(self.main_rects()):
                if rects[0].collidepoint(pos):
                    self.sel = n
                    self.activate(iid)
                    return
        elif self.screen in ("chapter", "diff"):
            for i, r in enumerate(self.card_rects()):
                if r.collidepoint(pos):
                    self.sel = i
                    self.pick_card(i)
                    return
            if self.BACK.collidepoint(pos):
                self.back()
        elif self.screen == "classes":
            for i, r in enumerate(self.class_rects()):
                if r.collidepoint(pos):
                    self.sel = i
                    self.pick_class(i)
                    return
            if self.PROMO.collidepoint(pos):
                self.sel = len(CLASS_KEYS) + 1
                self.ask_promo()
            elif self.BACK.collidepoint(pos):
                self.back()
        elif self.screen == "skins":
            for i, r in enumerate(self.skin_rects()):
                if r.collidepoint(pos):
                    self.sel = i
                    self.pick_skin(i)
                    return
            if self.BACK.collidepoint(pos):
                self.back()
        else:
            for i, r in enumerate(self.setting_rects()):
                if r.collidepoint(pos):
                    self.sel = i
                    self.cycle_setting(i)
                    return
            if self.BACK.collidepoint(pos):
                self.back()

    def hover(self, pos):
        if self.screen == "main":
            for n, (_, _, _, rects) in enumerate(self.main_rects()):
                if any(r.collidepoint(pos) for r in rects):
                    self.sel = n
        elif self.screen in ("chapter", "diff"):
            for i, r in enumerate(self.card_rects()):
                if r.collidepoint(pos):
                    self.sel = i
            if self.BACK.collidepoint(pos):
                self.sel = 2
        elif self.screen == "classes":
            for i, r in enumerate(self.class_rects()):
                if r.collidepoint(pos):
                    self.sel = i
            if self.BACK.collidepoint(pos):
                self.sel = len(CLASS_KEYS)
            if self.PROMO.collidepoint(pos):
                self.sel = len(CLASS_KEYS) + 1
        elif self.screen == "skins":
            for i, r in enumerate(self.skin_rects()):
                if r.collidepoint(pos):
                    self.sel = i
            if self.BACK.collidepoint(pos):
                self.sel = len(SKIN_KEYS)
        else:
            for i, r in enumerate(self.setting_rects()):
                if r.collidepoint(pos):
                    self.sel = i
            if self.BACK.collidepoint(pos):
                self.sel = len(SETTINGS)

    def key(self, key, char=""):
        if self.typing:  # набираем промокод
            if key == pygame.K_ESCAPE:
                self.typing = False
            elif key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self.typing = False
                self.apply_promo(self.input)
            elif key == pygame.K_BACKSPACE:
                self.input = self.input[:-1]
            elif key == pygame.K_v and pygame.key.get_mods() & pygame.KMOD_CTRL:  # Ctrl+V: вставить из буфера
                self.input = (self.input + paste_text())[:20]
            elif char and char.isprintable() and len(self.input) < 20:
                self.input += char
            return
        if key == pygame.K_ESCAPE:
            self.back()
            return
        if key == pygame.K_l:  # L — сменить язык
            self.cycle_lang()
            return
        n = self.count()
        enter = key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE)
        if self.screen == "main":
            items = self.main_items()
            if key == pygame.K_UP:
                self.sel = (self.sel - 1) % n
            elif key == pygame.K_DOWN:
                self.sel = (self.sel + 1) % n
            elif enter:
                self.activate(items[self.sel][0])
        elif self.screen in ("chapter", "diff"):
            if key == pygame.K_LEFT and self.sel < 2:
                self.sel = 0
            elif key == pygame.K_RIGHT and self.sel < 2:
                self.sel = 1
            elif key == pygame.K_DOWN:
                self.sel = 2
            elif key == pygame.K_UP and self.sel == 2:
                self.sel = 0
            elif enter:
                if self.sel == 2:
                    self.back()
                else:
                    self.pick_card(self.sel)
        elif self.screen == "classes":
            last = len(CLASS_KEYS)   # last — «Назад», last + 1 — «Промокод»
            if key == pygame.K_LEFT and self.sel < last:
                self.sel = (self.sel - 1) % last
            elif key == pygame.K_RIGHT and self.sel < last:
                self.sel = (self.sel + 1) % last
            elif key == pygame.K_RIGHT and self.sel == last:
                self.sel = last + 1
            elif key == pygame.K_LEFT and self.sel == last + 1:
                self.sel = last
            elif key == pygame.K_DOWN and self.sel < last:
                self.sel = last
            elif key == pygame.K_UP and self.sel >= last:
                self.sel = 0
            elif enter:
                if self.sel == last:
                    self.back()
                elif self.sel == last + 1:
                    self.ask_promo()
                else:
                    self.pick_class(self.sel)
        elif self.screen == "skins":
            cols = 4
            if key == pygame.K_LEFT and self.sel < len(SKIN_KEYS):
                self.sel = (self.sel - 1) % len(SKIN_KEYS)
            elif key == pygame.K_RIGHT and self.sel < len(SKIN_KEYS):
                self.sel = (self.sel + 1) % len(SKIN_KEYS)
            elif key == pygame.K_UP:
                self.sel = len(SKIN_KEYS) - cols if self.sel == len(SKIN_KEYS) else (
                    self.sel - cols if self.sel >= cols else self.sel)
            elif key == pygame.K_DOWN:
                self.sel = self.sel + cols if self.sel < len(SKIN_KEYS) - cols else len(SKIN_KEYS)
            elif enter:
                if self.sel == len(SKIN_KEYS):
                    self.back()
                else:
                    self.pick_skin(self.sel)
        else:
            if key == pygame.K_UP:
                self.sel = (self.sel - 1) % n
            elif key == pygame.K_DOWN:
                self.sel = (self.sel + 1) % n
            elif self.sel < len(SETTINGS) and key in (pygame.K_LEFT, pygame.K_RIGHT):
                self.cycle_setting(self.sel, 1 if key == pygame.K_RIGHT else -1)
            elif enter:
                if self.sel == len(SETTINGS):
                    self.back()
                else:
                    self.cycle_setting(self.sel)

    def update(self, dt):
        if self.msg:
            self.msg[1] -= dt
            if self.msg[1] <= 0:
                self.msg = None

    # ---------- рисование ----------
    def draw(self, s, font, big):
        s.fill(BG)
        for x in range(0, W, 40):
            pygame.draw.line(s, GRID, (x, 0), (x, H))
        for y in range(0, H, 40):
            pygame.draw.line(s, GRID, (0, y), (W, y))
        if self.screen == "main":
            self.draw_main(s, font, big)
        elif self.screen in ("chapter", "diff"):
            self.draw_cards(s, font)
        elif self.screen == "classes":
            self.draw_classes(s, font)
        elif self.screen == "skins":
            self.draw_skins(s, font)
        else:
            self.draw_settings(s, font)
        if self.screen in ("main", "classes", "skins"):
            self.draw_coins(s)
        self.draw_lang_button(s)
        if self.typing:
            self.draw_promo_box(s, font)
        if self.msg:
            t = font.render(self.msg[0], True, WHITE)
            box = t.get_rect(center=(W // 2, 430)).inflate(24, 12)
            pygame.draw.rect(s, INK, box, border_radius=8)
            s.blit(t, t.get_rect(center=box.center))

    @staticmethod
    def _button(s, rect, label, font, selected=False, locked=False, chosen=False):
        fill = BTN_OFF if locked else (BTN_SEL if selected else BTN)
        pygame.draw.rect(s, fill, rect, border_radius=10)
        border = GOLD if (selected or chosen) and not locked else (95, 105, 140)
        pygame.draw.rect(s, border, rect, 4 if chosen else 3, border_radius=10)
        t = font.render(label, True, GREY if locked else (GOLD if chosen else WHITE))
        s.blit(t, t.get_rect(center=rect.center))

    def title(self, s, text, size):
        f = pixel_font(size)
        sh = f.render(text, True, INK)
        t = f.render(text, True, (150, 230, 120))
        r = t.get_rect(midtop=(W // 2, 22))
        s.blit(sh, r.move(4, 4))
        s.blit(t, r)

    def draw_lang_button(self, s):
        """Кнопка языка со значком глобуса: нажимаешь — следующий язык (русский, English, 한국어)."""
        r = self.LANG_BTN
        self._button(s, r, "", pixel_font(20))
        cx, cy = r.x + 26, r.centery
        pygame.draw.circle(s, WHITE, (cx, cy), 12, 2)           # глобус
        pygame.draw.ellipse(s, WHITE, (cx - 6, cy - 12, 12, 24), 2)
        pygame.draw.line(s, WHITE, (cx - 12, cy), (cx + 12, cy), 2)
        t = pixel_font(20).render(dict(i18n.LANGS)[prefs.get("lang")], True, WHITE)
        s.blit(t, t.get_rect(midleft=(cx + 22, cy)))

    @staticmethod
    def coin(s, x, y, r=9):
        pygame.draw.circle(s, INK, (x, y), r + 2)
        pygame.draw.circle(s, (245, 205, 70), (x, y), r)
        pygame.draw.rect(s, (200, 150, 30), (x - 1, y - r // 2, 3, r))

    def draw_coins(self, s):
        """Сколько у тебя монет: справа вверху."""
        t = pixel_font(24).render(str(prefs.get("coins")), True, GOLD)
        r = t.get_rect(topright=(W - 20, 18))
        s.blit(t, r)
        self.coin(s, r.x - 18, r.centery)

    def price_tag(self, s, cx, y, price, can_pay, size=20):
        """Цена с монеткой."""
        t = pixel_font(size).render(str(price), True, GOLD if can_pay else (230, 110, 110))
        total = t.get_width() + 26
        x0 = cx - total // 2
        self.coin(s, x0 + 8, y, 8)
        s.blit(t, t.get_rect(midleft=(x0 + 24, y)))

    def draw_main(self, s, font, big):
        self.title(s, "ЗОМБИ-ШКОЛА", 64)

        for n, (iid, kind, label, rects) in enumerate(self.main_rects()):
            self._button(s, rects[0], label, font, selected=(n == self.sel))

    def draw_cards(self, s, font):
        chapter = self.screen == "chapter"
        self.title(s, "ВЫБЕРИ ГЛАВУ" if chapter else "ВЫБЕРИ СЛОЖНОСТЬ", 48)
        cur = prefs.get("mode")
        for i, (cid, name, sub, open_) in enumerate(self.cards()):
            r = self.card_rects()[i]
            sel = i == self.sel
            chosen = (not chapter) and cid == cur
            pygame.draw.rect(s, BTN_OFF if not open_ else (BTN_SEL if sel else BTN), r, border_radius=14)
            pygame.draw.rect(s, GOLD if ((sel or chosen) and open_) else (95, 105, 140), r, 5 if chosen else 3,
                             border_radius=14)
            color = GREY if not open_ else (GOLD if chosen else WHITE)
            t = pixel_font(48).render(name, True, color)
            s.blit(t, t.get_rect(center=(r.centerx, r.y + 85)))
            lines = [sub] if chapter else i18n.tr(sub).split(" — ")
            for k, line in enumerate(lines):
                t2 = pixel_font(24).render(line, True, GREY if not open_ else (200, 210, 235))
                s.blit(t2, t2.get_rect(center=(r.centerx, r.y + 150 + k * 34)))
            if not open_:
                lock = pixel_font(20).render("закрыта", True, GREY)
                s.blit(lock, lock.get_rect(center=(r.centerx, r.bottom - 30)))
        self._button(s, self.BACK, "Назад", font, selected=(self.sel == 2))

    def preview(self, key):
        if key not in self.previews:
            self.previews[key] = build(PLAYER_FRAMES["idle"], scale=7, recolor=SKINS[key][1])
        return self.previews[key]

    def draw_skins(self, s, font):
        self.title(s, "СКИНЫ", 48)
        cur = prefs.get("skin")
        for i, r in enumerate(self.skin_rects()):
            key = SKIN_KEYS[i]
            sel, chosen = (i == self.sel), (key == cur)
            pygame.draw.rect(s, BTN_SEL if sel else BTN, r, border_radius=10)
            pygame.draw.rect(s, GOLD if (sel or chosen) else (95, 105, 140), r, 4 if chosen else 3, border_radius=10)
            img = self.preview(key)
            owned = classes.owns_skin(key)
            if not owned:  # не куплен: картинка тусклая и видна цена
                img = img.copy()
                img.set_alpha(110)
            s.blit(img, img.get_rect(midbottom=(r.centerx, r.bottom - 38)))
            t = pixel_font(20).render(SKINS[key][0], True, GOLD if chosen else WHITE)
            s.blit(t, t.get_rect(center=(r.centerx, r.bottom - 18)))
            if not owned:
                self.price_tag(s, r.centerx, r.y + 18, SKIN_PRICE[key], prefs.get("coins") >= SKIN_PRICE[key])
        self._button(s, self.BACK, "Назад", font, selected=(self.sel == len(SKIN_KEYS)))

    def draw_promo_box(self, s, font):
        shade = pygame.Surface((W, H), pygame.SRCALPHA)
        shade.fill((0, 0, 10, 190))
        s.blit(shade, (0, 0))
        box = pygame.Rect(W // 2 - 280, 190, 560, 160)
        pygame.draw.rect(s, BTN, box, border_radius=14)
        pygame.draw.rect(s, GOLD, box, 4, border_radius=14)
        t = font.render("Введи промокод и нажми Enter", True, WHITE)
        s.blit(t, t.get_rect(center=(box.centerx, box.y + 34)))
        field = pygame.Rect(box.x + 40, box.y + 66, box.w - 80, 50)
        pygame.draw.rect(s, (20, 26, 48), field, border_radius=8)
        pygame.draw.rect(s, (95, 105, 140), field, 3, border_radius=8)
        cursor = "_" if (pygame.time.get_ticks() // 450) % 2 else ""
        text = pixel_font(32).render(self.input + cursor, True, GOLD)
        s.blit(text, text.get_rect(midleft=(field.x + 14, field.centery)))
        hint = pixel_font(16).render("Ctrl+V — вставить.  Esc или клик — отмена", True, GREY)
        s.blit(hint, hint.get_rect(center=(box.centerx, box.bottom - 20)))

    def draw_classes(self, s, font):
        self.title(s, "КЛАССЫ", 48)
        cur = classes.current_key()
        for i, r in enumerate(self.class_rects()):
            key = CLASS_KEYS[i]
            c = CLASSES[key]
            sel, chosen, owned = (i == self.sel), (key == cur), classes.owns_class(key)
            pygame.draw.rect(s, BTN_SEL if sel else (BTN if owned else BTN_OFF), r, border_radius=14)
            pygame.draw.rect(s, GOLD if (sel or chosen) else (95, 105, 140), r, 5 if chosen else 3, border_radius=14)
            t = pixel_font(32).render(c["name"], True, GOLD if chosen else (WHITE if owned else GREY))
            s.blit(t, t.get_rect(center=(r.centerx, r.y + 46)))
            for k, line in enumerate(c["desc"]):
                t2 = pixel_font(20).render(line, True, (200, 210, 235) if owned else GREY)
                s.blit(t2, t2.get_rect(center=(r.centerx, r.y + 120 + k * 36)))
            if chosen:
                st = pixel_font(24).render("Выбран", True, (150, 230, 120))
                s.blit(st, st.get_rect(center=(r.centerx, r.bottom - 32)))
            elif owned:
                st = pixel_font(24).render("Куплен", True, (200, 210, 235))
                s.blit(st, st.get_rect(center=(r.centerx, r.bottom - 32)))
            else:
                self.price_tag(s, r.centerx, r.bottom - 32, c["price"], prefs.get("coins") >= c["price"], 24)
        self._button(s, self.BACK, "Назад", font, selected=(self.sel == len(CLASS_KEYS)))
        self._button(s, self.PROMO, "Промокод", font, selected=(self.sel == len(CLASS_KEYS) + 1))

    def draw_settings(self, s, font):
        self.title(s, "НАСТРОЙКИ", 48)
        for i, r in enumerate(self.setting_rects()):
            key, label, options = SETTINGS[i]
            pygame.draw.rect(s, BTN_SEL if i == self.sel else BTN, r, border_radius=10)
            pygame.draw.rect(s, GOLD if i == self.sel else (95, 105, 140), r, 3, border_radius=10)
            t = font.render(label, True, WHITE)
            s.blit(t, t.get_rect(midleft=(r.x + 20, r.centery)))
            cur = prefs.get(key)
            text = next((txt for v, txt in options if v == cur), "?")
            v = font.render(text, True, GOLD)
            s.blit(v, v.get_rect(midright=(r.right - 20, r.centery)))
        self._button(s, self.BACK, "Назад", font, selected=(self.sel == len(SETTINGS)))
