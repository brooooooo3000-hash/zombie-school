"""Глава 2 «Блэкаут»: тьма с фонариком-телефоном, батарейка, «спрячься», «затаи дыхание», рассвет.

Класс Night живёт, пока ты в комнате главы 2. Он ведёт сюжет комнаты (что происходит и когда),
а Game вызывает его каждый кадр (update), рисует тьму (draw_dark) и интерфейс (draw_hud).
Телефон (self.phone) и наушники (self.headphones) живут в Game, чтобы переходить из комнаты в комнату.
"""
import math
import random

import pygame

import prefs
import touch as T
from pixelfont import pixel_font
from rooms2 import GIRL_POS
from settings import FLOOR, H, INK, W

LIGHT_R = 190                 # радиус света телефона, пока заряда больше 30%
PHONE_DRAIN = {"apt": 1.0, "stairs": 0.45, "lobby": 0.9, "shop": 0.7}   # сколько % заряда уходит за секунду
POWERBANK_GIVES = 40          # на сколько % заряжает пауэрбанк
HEADPHONES_SPEED = 50         # наушники: +50 к скорости
DAWN_LEN = 75                 # секунд до рассвета в магазине
SLIP_LIMIT = 1.5              # сколько секунд можно «выдохнуть» в событии «затаи дыхание»
BREATH_GRACE = 0.8            # в начале события есть время, чтобы среагировать

_masks = {}
_dark = None


def light_radius(phone):
    """Телефон садится — свет сжимается: от 190 до 70 пикселей."""
    if phone >= 30:
        return LIGHT_R
    return 70 + (LIGHT_R - 70) * max(0.0, phone) / 30


def light_mask(r):
    """Круг света: в центре дыра в темноте, к краю плавно темнеет (кольцами, как пиксельный градиент)."""
    r = max(30, int(r // 10 * 10))
    if r not in _masks:
        m = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        m.fill((255, 255, 255, 255))  # за пределами круга темнота остаётся как есть
        steps = 22
        for i in range(steps, 0, -1):
            k = i / steps
            alpha = int(255 * min(1.0, (k ** 1.6)))
            pygame.draw.circle(m, (255, 255, 255, alpha), (r, r), int(r * k))
        _masks[r] = m
    return _masks[r]


def draw_darkness(s, alpha, lights):
    """Накрываем комнату тьмой и вырезаем кружки света. lights — список (x, y, радиус)."""
    global _dark
    if _dark is None:
        _dark = pygame.Surface((W, H), pygame.SRCALPHA)
    _dark.fill((2, 3, 14, alpha))
    for x, y, r in lights:
        m = light_mask(r)
        _dark.blit(m, (int(x) - m.get_width() // 2, int(y) - m.get_height() // 2), special_flags=pygame.BLEND_RGBA_MIN)
    s.blit(_dark, (0, 0))


class Night:
    """Сюжет и правила одной ночной комнаты."""

    def __init__(self, game, rid):
        self.g, self.rid = game, rid
        self.t = 0.0
        self.stage = "start"
        self.objective = ""
        self.hidden = False
        self.event = None         # идущее событие: {"type": "hide" | "breath", ...}
        self.event_log = []       # что уже было (чтобы не повторять)
        self.spawn_q = []         # очередь зомби: [время, x]
        self.lights = []          # неподвижные источники света (x, y, радиус)
        self.npcs = []            # люди в комнате: {"kind", "x", "face", "line", "said", "light"}
        self.dawn = None
        self.ready = False        # можно ли выходить
        self.balcony_t = 0.0
        self.drain_k = 1.0        # множитель разряда телефона (хардкор быстрее, лёгкий режим медленнее)
        getattr(self, "init_" + rid)()

    # ------------------------------------------------ общее
    @property
    def theme(self):
        return self.g.room

    def hide_zones(self):
        return self.theme.get("hides", [])

    def near_hide(self):
        p = self.g.player
        return any(p.rect.colliderect(z) for z in self.hide_zones())

    def hide_zone(self):
        p = self.g.player
        return next((z for z in self.hide_zones() if p.rect.colliderect(z)), None)

    def calm(self):
        """Зомби тебя не замечают: ты спрятан или затаил дыхание."""
        if self.hidden:
            return True
        ev = self.event
        return bool(ev and ev["type"] == "breath" and ev["holding"])

    def toggle_hide(self):
        """Кнопка E: спрятаться / выйти. Возвращает True, если нажатие обработано."""
        if self.event and self.event["type"] == "breath":
            return True  # во время «затаи дыхание» кнопка E — это дыхание, она не прячет и не вытаскивает
        if self.hidden:
            self.hidden = False
            return True
        if self.near_hide():
            self.hidden = True
            p = self.g.player
            p.vx = 0
            z = self.hide_zone()
            p.x = z.centerx - p.w / 2
            self.g.msg = ["Ты спрятался. Тихо!", 1.5]
            return True
        return False

    def take_label(self):
        """Подпись на кнопке «взять» (на телефоне)."""
        if self.event and self.event["type"] == "breath":
            return "ЗАТАИТЬ"
        if self.hidden:
            return "ВЫЙТИ"
        if self.near_hide() and not self.g.weapon_item_near():
            return "ПРЯТАТЬ"
        return "ВЗЯТЬ"

    def spawn(self, x, guest=False):
        from game import Zombie
        z = Zombie(x)
        if guest:
            z.guest = True
            z.wander_t = 0.0
            z.wdir = 0
        self.g.zombies.append(z)
        return z

    def guests(self):
        return [z for z in self.g.zombies if getattr(z, "guest", False)]

    def aggro_guests(self, text="Они вас заметили!"):
        for z in self.guests():
            z.guest = False
        self.hidden = False
        self.g.msg = [text, 2.0]
        self.g.add_shake(4, 0.2)

    def send_guests_away(self):
        for z in self.guests():
            z.leaving = True
            z.leave_dir = 1 if z.x > W / 2 else -1

    def guest_step(self, z, dt):
        """Зомби-гость ходит по комнате и ищет. Спрятанного не видит; заметил — значит, ты попался."""
        p = self.g.player
        z.anim += 40 * dt
        if self.calm():
            z.wander_t -= dt
            if z.wander_t <= 0:
                z.wdir = random.choice((-1, 0, 1))
                z.wander_t = random.uniform(0.8, 2.0)
            z.x = max(120, min(W - 80, z.x + z.wdir * 38 * dt))
            if z.wdir:
                z.face = z.wdir
        else:
            z.face = 1 if p.x > z.x else -1
            z.x += z.face * 46 * dt
            if z.rect.colliderect(p.rect):
                self.fail_event()

    def fail_event(self):
        if self.event is None:
            return
        self.event = None
        self.aggro_guests()

    # ------------------------------------------------ события «спрячься» и «затаи дыхание»
    def start_hide_event(self, x_list):
        for x in x_list:
            self.spawn(x, guest=True)
        self.event = {"type": "hide", "t": 0.0, "deadline": 8.0, "hid_t": 0.0, "need": 6.0}
        self.objective = "Спрячься в шкаф: подойди и нажми E"
        self.g.msg = ["Спрячься! Они идут сюда", 2.5]

    def start_breath_event(self, x_list=(), dur=5.0):
        for x in x_list:
            self.spawn(x, guest=True)
        self.event = {"type": "breath", "t": 0.0, "dur": dur, "held": 0.0, "slip": 0.0, "holding": False}
        self.objective = "Затаи дыхание! Держи E (на телефоне держи кнопку)"
        self.g.msg = ["Они совсем рядом. Затаи дыхание!", 2.5]

    def update_event(self, dt, keys):
        ev = self.event
        if ev is None:
            return
        ev["t"] += dt
        if ev["type"] == "hide":
            if self.hidden:
                ev["hid_t"] += dt
                if ev["hid_t"] >= ev["need"]:
                    self.event = None
                    self.event_done("hide")
            elif ev["t"] >= ev["deadline"]:
                self.fail_event()
            for z in self.guests():
                if z.hp < 3:  # ударил гостя — выдал себя
                    self.fail_event()
                    break
        else:
            ev["holding"] = bool(keys[pygame.K_e])
            if ev["holding"]:
                ev["held"] += dt
                ev["slip"] = max(0.0, ev["slip"] - dt * 0.5)
            elif ev["t"] > BREATH_GRACE:
                ev["slip"] += dt
            if ev["slip"] > SLIP_LIMIT:
                self.fail_event()
            elif ev["held"] >= ev["dur"]:
                self.event = None
                self.event_done("breath")

    def event_done(self, kind):
        self.event_log.append(kind)
        if self.rid == "apt" and kind == "hide":
            self.start_breath_event(dur=5.0)
        elif self.rid == "apt" and kind == "breath":
            self.send_guests_away()
            self.stage = "leaving"
            self.t_stage = self.t
            self.g.msg = ["Прошли мимо! Можно выбираться", 2.5]
            self.hidden = False
        elif self.rid == "shop" and kind == "breath":
            self.send_guests_away()
            self.g.msg = ["Прошли мимо...", 2.0]

    # ------------------------------------------------ квартира
    def init_apt(self):
        self.stage = "intro"
        self.g.player.x = 420.0  # старт в середине комнаты: до балкона надо дойти самому
        self.objective = "Осмотрись: возьми вещи (E) и выйди на балкон (слева)"
        self.g.msg = ["Тьма. Свет отключили. Надо осмотреться", 3.0]

    def setup_loot_apt(self):
        g = self.g
        g.pickups = []
        g.add_loot("headphones", 190, FLOOR)
        g.add_loot("toygun", 340, 400)
        g.add_loot("powerbank", 810, 424)

    def update_apt(self, dt, keys):
        g, p = self.g, self.g.player
        from rooms2 import BALCONY_ZONE
        if self.stage == "intro":
            if p.rect.colliderect(BALCONY_ZONE):
                self.balcony_t += dt
            else:
                self.balcony_t = 0.0
            if self.balcony_t > 0.4:
                self.stage = "wave1"
                self.objective = "Отбейся: зомби поднимаются по лестнице"
                self.spawn_q = [[self.t + 6.0 + 1.6 * i, W - 60] for i in range(4)]
                g.play_scene("c2_balcony", ("resume",))
        elif self.stage == "wave1":
            if not self.spawn_q and not g.zombies:
                self.stage = "calm1"
                self.t_stage = self.t
                self.objective = "Тишина... Слышны шаги за дверью"
        elif self.stage == "calm1":
            if self.t - self.t_stage > 2.5:
                self.stage = "hide"
                self.start_hide_event([W - 70, W - 130, W - 190])
        elif self.stage in ("hide", "leaving"):
            # событие кончилось (прошли мимо или провалил и всех добил), зомби в комнате больше нет
            if self.event is None and not g.zombies and not self.spawn_q:
                self.stage = "free"
                self.objective = "Выбирайся из квартиры (вправо)"
                self.ready = True

    # ------------------------------------------------ лестница
    def init_stairs(self):
        self.stage = "calm"
        self.ready = True
        self.objective = "Спускайся по лестнице (вправо). Люди с фонариками — свои"
        self.g.msg = ["Этажи 30–20: здесь всё спокойно", 3.0]
        for kind, x, line in (
                ("neighbor1", 330, "Сосед: Ты живой?! Ниже десятого этажа уже не люди. Береги телефон."),
                ("neighbor2", 570, "Соседка: Возьми зарядку, свет телефона сейчас дороже золота."),
                ("neighbor3", 800, "Сосед: Лифт стоит. Идти только вниз. Удачи, парень.")):
            self.npcs.append({"kind": kind, "x": x, "face": -1, "line": line, "said": False})
            self.lights.append((x, FLOOR - 40, 110))

    def setup_loot_stairs(self):
        g = self.g
        g.pickups = []
        g.add_loot("pie", 250, 385)
        g.add_loot("pie", 760, FLOOR)

    def update_stairs(self, dt, keys):
        p = self.g.player
        for npc in self.npcs:
            if not npc["said"] and abs(p.x + p.w / 2 - npc["x"]) < 100:
                npc["said"] = True
                self.g.msg = [npc["line"], 4.5]
                if npc["kind"] == "neighbor2":
                    self.g.add_loot("powerbank", npc["x"] + 50, FLOOR)

    # ------------------------------------------------ подъезд
    def init_lobby(self):
        self.stage = "fight"
        self.objective = "Пробейся к выходу: внизу одни зомби"
        self.g.msg = ["Нулевой этаж: одни зомби", 3.0]
        for i in range(8):
            self.spawn(random.randint(420, W - 90))
        self.spawn_q = [[8.0 + 2.5 * i, W - 60] for i in range(3)]

    def update_lobby(self, dt, keys):
        if not self.g.zombies and not self.spawn_q:
            self.ready = True
            self.objective = "Путь свободен: выходи на улицу (вправо)"

    # ------------------------------------------------ магазин
    def init_shop(self):
        g = self.g
        self.stage = "quiet"
        length = DAWN_LEN * (0.75 if self.easy() else 1.0)
        self.dawn = {"t": 0.0, "len": length}
        self.objective = "Прячься с девочкой за прилавком до рассвета"
        g.msg = ["Девочка: Тише... они ходят снаружи", 3.5]
        self.lights.append((GIRL_POS[0] + 20, FLOOR - 40, 120))  # фонарик девочки
        self.breath_started = False
        self.siege_started = False
        self.trickle_t = 0.0

    @staticmethod
    def easy():
        from game import easy_on
        return easy_on()

    def setup_loot_shop(self):
        g = self.g
        g.pickups = []
        g.add_loot("powerbank", 220, 395)
        g.add_loot("toygun", 420, 335)
        g.add_loot("pie", 520, FLOOR)

    def update_shop(self, dt, keys):
        g = self.g
        d = self.dawn
        d["t"] += dt
        if not self.breath_started and self.t > 11:
            self.breath_started = True
            self.start_breath_event([W - 80, W - 150], dur=4.5)
        if not self.siege_started and self.t > 30 and self.event is None:
            self.siege_started = True
            self.stage = "siege"
            self.objective = "Отбивайся! Продержись до рассвета"
            self.spawn_q += [[self.t + 5.0 + 1.1 * i, (60 if i % 2 else W - 60)] for i in range(6)]
            self.spawn_q += [[self.t + 20.0 + 1.0 * i, (60 if i % 2 else W - 60)] for i in range(7)]
            g.play_scene("c2_siege", ("resume",))
        if self.siege_started and not self.spawn_q:
            self.trickle_t -= dt
            if self.trickle_t <= 0 and len(g.zombies) < 6:
                self.trickle_t = 6.0
                self.spawn(random.choice((60, W - 60)))
        if d["t"] >= d["len"]:
            self.dawn_comes()

    def dawn_comes(self):
        g = self.g
        for z in g.zombies:
            z.hp = 0  # на рассвете зомби рассыпаются
        g.puff(W / 2, FLOOR - 30, 16, (255, 220, 140))
        g.finish_room()

    # ------------------------------------------------ каждый кадр
    def update(self, dt, keys):
        g = self.g
        self.t += dt
        # заряд телефона
        k = 1.5 if prefs.get("mode") == "hardcore" else (0.7 if self.easy() else 1.0)
        before = g.phone
        g.phone = max(0.0, g.phone - PHONE_DRAIN[self.rid] * k * dt)
        if before > 0 and g.phone <= 0:
            g.msg = ["Телефон сел! Нужен пауэрбанк", 3.0]
        elif before > 20 >= g.phone > 0 and not getattr(self, "warned", False):
            self.warned = True
            g.msg = ["Телефон садится: ищи пауэрбанк", 2.5]
        # очередь зомби
        for item in list(self.spawn_q):
            if self.t >= item[0]:
                self.spawn(item[1])
                self.spawn_q.remove(item)
        # зомби-гости
        for z in list(g.zombies):
            if getattr(z, "leaving", False):
                z.x += z.leave_dir * 120 * dt
                z.anim += 120 * dt
                z.face = z.leave_dir
                if z.x < -60 or z.x > W + 60:
                    g.zombies.remove(z)
        self.update_event(dt, keys)
        getattr(self, "update_" + self.rid)(dt, keys)

    def exit_ready(self):
        return self.ready

    # ------------------------------------------------ рисование
    def player_light(self):
        g, p = self.g, self.g.player
        if self.hidden:
            return (p.x + p.w / 2, p.y + 30, 45)
        r = light_radius(g.phone)
        if g.phone < 15:  # мерцает перед тем, как сесть
            r *= 0.85 + 0.15 * math.sin(pygame.time.get_ticks() / 70)
        return (p.x + p.w / 2, p.y + 30, r)

    def draw_back(self, s):
        """Люди и девочка: рисуем до мебели (девочка прячется за прилавком)."""
        sp = self.g.sprites
        if self.rid == "shop":
            img = sp.humans["girl"]["idle"]
            s.blit(pygame.transform.flip(img, True, False), img.get_rect(midbottom=GIRL_POS))
        for npc in self.npcs:
            img = sp.humans[npc["kind"]]["idle"]
            if npc["face"] < 0:
                img = pygame.transform.flip(img, True, False)
            s.blit(img, img.get_rect(midbottom=(npc["x"], FLOOR)))

    def draw_hidden(self, s):
        """Спрятанный герой: из щели виднеются только глаза."""
        if not self.hidden:
            return
        z = self.hide_zone() or self.hide_zones()[0]
        for dx in (-8, 8):
            pygame.draw.rect(s, (255, 255, 255), (z.centerx + dx - 3, FLOOR - 92, 6, 8))

    def draw_dark(self, s):
        alpha = self.theme.get("dark", 230)
        lights = [self.player_light()] + self.lights
        draw_darkness(s, alpha, lights)

    def draw_hud(self, s, font):
        g = self.g
        small = pixel_font(20)
        # телефон: значок и полоска заряда
        ph = max(0.0, g.phone)
        color = (110, 220, 130) if ph > 30 else ((240, 180, 60) if ph > 15 else (240, 70, 70))
        if ph <= 15 and (pygame.time.get_ticks() // 300) % 2:
            color = (120, 40, 40)
        pygame.draw.rect(s, INK, (14, 58, 156, 34), border_radius=6)
        pygame.draw.rect(s, (40, 44, 60), (17, 61, 150, 28), border_radius=5)
        pygame.draw.rect(s, (220, 225, 235), (22, 64, 16, 22), border_radius=3)   # сам телефон
        pygame.draw.rect(s, (20, 24, 34), (24, 67, 12, 14))
        pygame.draw.rect(s, color, (46, 70, int(66 * ph / 100), 12))
        pygame.draw.rect(s, (230, 235, 245), (46, 70, 66, 12), 2)
        t = pixel_font(16).render(f"{int(ph)}%", True, (255, 255, 255))
        s.blit(t, t.get_rect(midleft=(118, 76)))
        # цель
        if self.objective:
            txt = small.render("Цель: " + self.objective, True, (255, 255, 255))
            box = txt.get_rect(midtop=(W // 2, 58)).inflate(22, 10)
            box.x = max(180, min(box.x, W - box.w - 150))
            back = pygame.Surface(box.size, pygame.SRCALPHA)
            back.fill((15, 15, 25, 190))
            s.blit(back, box)
            s.blit(txt, txt.get_rect(center=box.center))
        # рассвет
        if self.dawn:
            left = max(0.0, self.dawn["len"] - self.dawn["t"])
            bar = pygame.Rect(W // 2 - 200, 98, 400, 16)
            pygame.draw.rect(s, INK, bar.inflate(6, 6))
            pygame.draw.rect(s, (20, 26, 60), bar)
            k = 1 - left / self.dawn["len"]
            pygame.draw.rect(s, (255, 170, 70), (bar.x, bar.y, int(bar.w * k), bar.h))
            label = f"До рассвета: {int(left) + 1} с"
            sh = pixel_font(16).render(label, True, INK)
            t = pixel_font(16).render(label, True, (255, 255, 255))
            s.blit(sh, sh.get_rect(center=(bar.centerx + 1, bar.centery + 1)))
            s.blit(t, t.get_rect(center=bar.center))
        # событие «затаи дыхание»
        ev = self.event
        if ev and ev["type"] == "breath":
            bar = pygame.Rect(W // 2 - 150, 226, 300, 22)
            pygame.draw.rect(s, INK, bar.inflate(6, 6))
            pygame.draw.rect(s, (40, 40, 60), bar)
            pygame.draw.rect(s, (120, 200, 255), (bar.x, bar.y, int(bar.w * min(1.0, ev["held"] / ev["dur"])), bar.h))
            warn = ev["slip"] / SLIP_LIMIT
            if warn > 0.1:
                pygame.draw.rect(s, (240, 70, 70), (bar.x, bar.bottom + 4, int(bar.w * min(1.0, warn)), 6))
            t = font.render("ЗАТАИ ДЫХАНИЕ! Держи E", True, (255, 255, 255))
            s.blit(t, t.get_rect(center=(bar.centerx, bar.y - 20)))
        elif ev and ev["type"] == "hide" and not self.hidden:
            left = max(0.0, ev["deadline"] - ev["t"])
            t = font.render(f"СПРЯЧЬСЯ! {left:.0f} с", True, (255, 200, 120))
            s.blit(t, t.get_rect(center=(W // 2, 226)))
        # подсказки у шкафа
        p = self.g.player
        if self.hidden and not ev:
            t = small.render("E — выйти", True, (255, 255, 255))
            s.blit(t, t.get_rect(center=(W // 2, 440)))
        elif not self.hidden and self.near_hide() and not ev and not T.touch.enabled:
            t = small.render("E — спрятаться", True, (255, 255, 255))
            s.blit(t, t.get_rect(center=(p.x + p.w / 2, p.y - 20)))
