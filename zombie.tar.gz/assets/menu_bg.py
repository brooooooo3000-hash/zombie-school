"""Фон главного меню: ночная школа под луной, в окнах мелькает свет, летают летучие мыши,
а по низу экрана твой герой один раз пробегает направо, и следом вываливается орда врагов (как толпа из мема),
а потом герой бежит вместе с Чунгуком, Дундуком и Мингуком (они с поднятыми руками, обычные люди, не зомби), а орда гонится за ними.

Всё нарисовано квадратиками по 4 пикселя (как вся игра). Неподвижная часть рисуется один раз,
двигается только свет в окнах, мыши, облака и шествие. В настройках анимацию можно выключить.
"""
import math
import random

import pygame

from settings import H, W

S = 4                  # один «пиксель» фона = 4 пикселя экрана
GROUND = 124           # где начинается земля (в пикселях фона)
FEET = (GROUND + 3) * S   # на какой высоте стоят ноги бегущих
HERO_SPEED = 250       # скорость героя, пикселей экрана в секунду
HORDE = 44             # сколько врагов в орде
MOB_KINDS = {"zombie": 10, "worm": 3, "chicken": 4, "lamb": 3, "cow": 1}   # кто бежит в орде
MOB_SPEED = {"zombie": (0.7, 1.05), "worm": (0.7, 1.0), "chicken": (0.8, 1.1), "lamb": (0.7, 1.0),
             "cow": (0.45, 0.6)}   # во сколько раз быстрее или медленнее героя
BULLIES = ("bully1", "bully3", "bully2")   # Чунгук, Дундук, Мингук: в таком порядке бегут, Чунгук впереди
BULLY_SPEED = 1.2      # хулиганы бегут быстрее героя и орды, поэтому орда всё время у них за спиной
LANE = 18              # орда бежит в несколько рядов: ноги выше или ниже на столько пикселей
HOP = {"chicken": 30, "lamb": 24}   # кто скачет на бегу

SKY_TOP, SKY_LOW = (10, 12, 34), (62, 36, 80)
BODY, DARK, TRIM = (24, 26, 52), (14, 15, 34), (36, 38, 72)
WINDOW_OFF, WINDOW_ON = (28, 32, 66), (255, 208, 100)
DIM = (8, 10, 24, 170)   # затемнение на других экранах меню, чтобы текст читался


def px(s, x, y, w, h, color):
    pygame.draw.rect(s, color, (int(x) * S, int(y) * S, int(w) * S, int(h) * S))


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def disc(s, cx, cy, r, color):
    """Круг из квадратиков (пиксельный)."""
    for dy in range(-r, r + 1):
        hw = int(math.sqrt(max(0, r * r - dy * dy)))
        px(s, cx - hw, cy + dy, 2 * hw + 1, 1, color)


def window_spots():
    """Где окна у школы: (x, y). Двери и башню обходим."""
    spots = []
    for row, y in enumerate((77, 96)):
        for k in range(14):
            x = 16 + k * 15
            if row == 1 and 100 <= x <= 128:   # здесь дверь
                continue
            if row == 0 and 104 <= x <= 124:   # здесь башня
                continue
            spots.append((x, y))
    return spots


def build_sky():
    """Небо, звёзды, луна и дальние холмы: рисуется один раз."""
    rng = random.Random(5)
    s = pygame.Surface((W, H))
    for y in range(GROUND + 1):
        px(s, 0, y, W // S, 1, lerp(SKY_TOP, SKY_LOW, (y / GROUND) ** 1.5))
    for _ in range(70):
        x, y = rng.randint(0, 239), rng.randint(0, 80)
        c = rng.choice(((255, 255, 235), (190, 200, 255), (255, 230, 160)))
        px(s, x, y, 1, 1, c)
        if rng.random() < 0.12:   # яркие звёзды крестиком
            px(s, x - 1, y, 3, 1, c)
            px(s, x, y - 1, 1, 3, c)
    glow = pygame.Surface((W, H), pygame.SRCALPHA)
    for r, a in ((70, 10), (54, 14), (40, 20), (30, 26)):
        pygame.draw.circle(glow, (190, 205, 255, a), (188 * S, 26 * S), r * S // 2)
    s.blit(glow, (0, 0))
    disc(s, 188, 26, 13, (238, 234, 204))
    for dx, dy, r in ((-5, -4, 3), (4, 2, 2), (-2, 7, 2), (6, -7, 1)):   # кратеры
        disc(s, 188 + dx, 26 + dy, r, (208, 203, 170))
    for x in range(240):   # дальний лес: тёмная кромка
        h = 11 + int(4 * math.sin(x * 0.07) + 3 * math.sin(x * 0.19 + 1))
        px(s, x, GROUND - h, 1, h, (18, 20, 46))
    return s


def build_front():
    """Школа, земля и забор: прозрачная картинка поверх неба."""
    s = pygame.Surface((W, H), pygame.SRCALPHA)
    px(s, 8, 66, 224, 6, DARK)                 # крыша
    px(s, 10, 72, 220, GROUND - 72, BODY)      # стены
    for x in range(10, 230, 8):                # зубцы на крыше
        px(s, x, 64, 4, 2, DARK)
    px(s, 102, 40, 36, 32, BODY)               # башня с часами
    for i in range(10):
        w = 6 + i * 4
        px(s, 120 - w // 2, 30 + i, w, 1, DARK)
    px(s, 120, 16, 1, 16, TRIM)                # флаг
    px(s, 121, 16, 7, 3, (150, 40, 50))
    disc(s, 120, 52, 8, TRIM)                  # часы
    disc(s, 120, 52, 7, (214, 208, 172))
    px(s, 120, 47, 1, 6, DARK)
    px(s, 120, 52, 4, 1, DARK)
    for x, y in window_spots():                # окна (выключенные)
        px(s, x - 1, y - 1, 10, 13, TRIM)
        px(s, x, y, 8, 11, WINDOW_OFF)
        px(s, x + 4, y, 1, 11, TRIM)
    px(s, 108, 104, 24, GROUND - 104, DARK)    # дверь
    px(s, 110, 102, 20, 2, DARK)
    px(s, 104, GROUND - 3, 32, 3, TRIM)        # ступени
    px(s, 100, GROUND - 1, 40, 1, TRIM)
    px(s, 0, GROUND, W // S, H // S - GROUND, (9, 10, 20))   # земля
    rng = random.Random(9)
    for x in range(0, 240, 6):                 # забор
        px(s, x, 116, 2, 8, (12, 13, 28))
        px(s, x, 115, 1, 1, (12, 13, 28))
    px(s, 0, 119, 240, 1, (12, 13, 28))
    for _ in range(40):                        # травинки
        px(s, rng.randint(0, 239), GROUND + rng.randint(1, 2), 1, 1, (22, 36, 30))
    return s


def build_cloud(w, h, seed):
    rng = random.Random(seed)
    s = pygame.Surface((w * S, h * S), pygame.SRCALPHA)
    for _ in range(9):
        cw, ch = rng.randint(w // 4, w // 2), rng.randint(h // 2, h)
        x, y = rng.randint(0, w - cw), rng.randint(0, h - ch)
        pygame.draw.ellipse(s, (34, 30, 66, 150), (x * S, y * S, cw * S, ch * S))
    return s


class MenuBackground:
    def __init__(self):
        self.sky = build_sky()
        self.front = build_front()
        self.clouds = [[build_cloud(44, 9, 1), 30.0, 22, 6.0], [build_cloud(30, 7, 2), 150.0, 42, 4.0]]
        self.windows = [(x, y, random.random()) for x, y in window_spots()]
        self.bats = [[random.uniform(-20, 240), random.uniform(14, 60), random.uniform(14, 30), random.random() * 6]
                     for _ in range(3)]
        self.t = 0.0
        self.hero = {"x": -60.0, "v": HERO_SPEED, "on": True}   # on — герой сейчас на экране
        self.mobs = []
        self.phase = "hero"       # hero — герой бежит один, horde — вываливается орда, pause — тихо
        self.bullies = []         # трое хулиганов, бегут вперёд орды с поднятыми руками
        self.to_spawn = 0         # сколько врагов ещё выйдет
        self.spawn_t = 0.0
        self.pause = 0.0
        self.shadow = pygame.Surface((70, 14), pygame.SRCALPHA)
        pygame.draw.ellipse(self.shadow, (0, 0, 0, 90), self.shadow.get_rect())
        self.dim = pygame.Surface((W, H), pygame.SRCALPHA)
        self.dim.fill(DIM)

    # ---------- движение ----------
    def spawn_mobs(self, n):
        """Из-за левого края вываливается n врагов сразу: каждый бежит в своём ряду и с разной скоростью."""
        kinds, weights = zip(*MOB_KINDS.items())
        for _ in range(n):
            kind = random.choices(kinds, weights)[0]
            lo, hi = MOB_SPEED[kind]
            self.mobs.append({"kind": kind, "x": -40.0 - random.randint(0, 50), "lane": random.randint(-LANE, LANE),
                              "v": HERO_SPEED * random.uniform(lo, hi), "ph": random.random() * 6})

    def spawn_bullies(self):
        """Слева выбегает компания: герой первый, за ним Чунгук, Дундук и Мингук с поднятыми руками.
        Орда выкатывается следом за ними."""
        self.hero.update(x=-60.0, v=HERO_SPEED * BULLY_SPEED, on=True)
        for i, name in enumerate(BULLIES):
            self.bullies.append({"name": name, "x": -145.0 - i * 85, "v": HERO_SPEED * BULLY_SPEED, "ph": i * 1.7})

    def update(self, dt):
        self.t += dt
        for c in self.clouds:
            c[1] += c[3] * dt
            if c[1] > W // S + 10:
                c[1] = -50.0
        for b in self.bats:
            b[0] += b[2] * dt
            if b[0] > 250:
                b[0], b[1], b[2] = -12.0, random.uniform(14, 60), random.uniform(14, 30)
        for m in self.mobs:
            m["x"] += m["v"] * dt
        self.mobs = [m for m in self.mobs if m["x"] < W + 140]
        for b in self.bullies:
            b["x"] += b["v"] * dt
        self.bullies = [b for b in self.bullies if b["x"] < W + 140]
        h = self.hero
        if h["on"]:
            h["x"] += h["v"] * dt
            if h["x"] > W + 80:
                h["on"] = False
        if self.phase == "hero":
            if not h["on"]:   # герой убежал один: теперь он бежит с компанией, а из-за края вываливается орда
                self.phase, self.to_spawn, self.spawn_t = "horde", HORDE, 1.5   # орда выходит чуть позже компании
                self.spawn_bullies()
        elif self.phase == "horde":
            self.spawn_t -= dt
            while self.to_spawn > 0 and self.spawn_t <= 0:
                n = min(self.to_spawn, random.randint(1, 3))
                self.spawn_mobs(n)
                self.to_spawn -= n
                self.spawn_t += random.uniform(0.04, 0.2)
            if self.to_spawn == 0 and not self.mobs and not self.bullies and not h["on"]:
                self.phase, self.pause = "pause", 1.5
        else:
            self.pause -= dt
            if self.pause <= 0:
                self.phase = "hero"
                h.update(x=-60.0, v=HERO_SPEED, on=True)

    # ---------- рисование ----------
    def draw_windows(self, s, t):
        for i, (x, y, ph) in enumerate(self.windows):
            if i % 5 == 0:     # лампа мигает
                lit = (t * 0.45 + ph) % 1 < 0.5 and int(t * 14 + ph * 9) % 3 != 0
            else:
                lit = (t * 0.1 + ph) % 1 < 0.28
            if not lit:
                continue
            px(s, x, y, 8, 11, WINDOW_ON)
            px(s, x + 4, y, 1, 11, (200, 150, 70))
            if i % 6 == 2:     # в этом окне стоит зомби
                px(s, x + 2, y + 4, 4, 4, (70, 150, 70))
                px(s, x + 1, y + 8, 6, 3, (40, 70, 40))
                px(s, x + 1, y + 6, 1, 2, (70, 150, 70))
                px(s, x + 6, y + 6, 1, 2, (70, 150, 70))

    def draw_bats(self, s, t):
        for x, y, v, ph in self.bats:
            yy = y + 3 * math.sin(t * 2 + ph)
            c = (6, 6, 14)
            px(s, x, yy, 2, 2, c)
            if int(t * 9 + ph) % 2:
                px(s, x - 3, yy - 1, 3, 1, c)
                px(s, x + 2, yy - 1, 3, 1, c)
            else:
                px(s, x - 3, yy + 1, 3, 1, c)
                px(s, x + 2, yy + 1, 3, 1, c)

    def draw_procession(self, s, sp):
        if sp is None:
            return
        for m in sorted(self.mobs, key=lambda m: (m["lane"], m["x"])):   # дальние ряды рисуем первыми
            x, kind = m["x"], m["kind"]
            feet = FEET + m["lane"]
            hop = abs(math.sin(x * 0.07 + m["ph"])) * (10 + HOP.get(kind, 0))   # бегут вприпрыжку
            step = x + m["ph"] * 20
            if kind == "zombie":
                img = sp.zombie[f"walk{int(step / 18) % 4}"]
            else:
                img = sp.market[kind]["a" if int(step / 16) % 2 == 0 else "b"]
            s.blit(self.shadow, self.shadow.get_rect(center=(int(x), feet - 2)))
            s.blit(img, img.get_rect(midbottom=(int(x), feet + 4 - int(hop))))
        for b in self.bullies:   # хулиганы бегут впереди орды (рисуем ближним рядом)
            x = b["x"]
            img = sp.cheer[b["name"]][f"cheer{int(x / 40) % 4}"]
            hop = abs(math.sin(x * 0.09 + b["ph"])) * 8
            s.blit(self.shadow, self.shadow.get_rect(center=(int(x), FEET + LANE - 2)))
            s.blit(img, img.get_rect(midbottom=(int(x), FEET + LANE + 4 - int(hop))))
        if self.hero["on"]:   # герой: один — на своей дорожке, с компанией — впереди хулиганов
            hx = self.hero["x"]
            lane = LANE if self.phase == "horde" else 0
            img = sp.player[f"run{int(hx / 40) % 4}"]
            s.blit(self.shadow, self.shadow.get_rect(center=(int(hx), FEET + lane - 2)))
            s.blit(img, img.get_rect(midbottom=(int(hx), FEET + lane)))

    def draw(self, s, sp, animate=True, calm=False):
        """animate — крутить ли анимацию (настройка); calm — другой экран меню: фон тихий и затемнён."""
        live = animate and not calm
        t = self.t if animate else 7.0
        s.blit(self.sky, (0, 0))
        for img, x, y, _ in self.clouds:
            s.blit(img, (int(x) * S, y * S))
        s.blit(self.front, (0, 0))
        self.draw_windows(s, t)
        if live:
            self.draw_bats(s, t)
            self.draw_procession(s, sp)
        if calm:
            s.blit(self.dim, (0, 0))
